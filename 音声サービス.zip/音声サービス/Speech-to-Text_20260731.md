# AI 面试助手 PoC：当前设计说明

> 本文描述当前已实现的 PoC 基线，不是未来功能清单。模型名称是推荐的 Azure OpenAI 部署配置；实际环境变量应填写 Azure 资源中创建的 Deployment Name。

## 1. 产品范围

当前应用由三个页面组成：

| 页面 | 作用 | 当前可用能力 |
|---|---|---|
| AI履歴書アシスタント | 分析履历书与 JD | 上传或粘贴履历书、输入 JD、生成匹配度、关键词、改善建议和优化后履历书 |
| 模擬面接 | 面试练习 | 根据履历书/JD 生成题目、逐题回答、浏览器语音输入、计时和复盘 |
| 面接アシスタント | 实际面试辅助 | 浏览器实时字幕、停顿自动判题、翻译、三档回答建议、事实来源与待确认信息 |

当前 PoC 不包含 Azure AI Search、Embedding、RAG、说话人分离、Zoom/Teams 系统音频采集和服务端流式 ASR。

---

## 2. 当前架构

    浏览器（React / Vite）
      ├─ Web Speech Recognition：实时字幕、模拟面试的音声入力
      ├─ MediaRecorder：面试助手的手动 ASR 兜底
      └─ WebSocket / REST API
                ↓
    后端（FastAPI）
      ├─ 会话、履历书、补充资料、问答历史（SQLite / SQLAlchemy）
      ├─ 文件文本抽取
      ├─ Azure OpenAI
      └─ 可替换的 mock provider

前端不会访问 Azure OpenAI 密钥。所有模型调用均由后端完成。

---

## 3. 模型与环境变量

推荐的当前分工：

| 任务 | 环境变量 | 推荐部署 |
|---|---|---|
| 履历书分析及通用回退 | AZURE_OPENAI_DEPLOYMENT | gpt-4.1 |
| 浏览器录音的服务端转写兜底 | AZURE_OPENAI_ASR_DEPLOYMENT | gpt-4o-mini-transcribe |
| 问题清理、翻译、完整度/问题判定 | AZURE_OPENAI_QUESTION_DEPLOYMENT | gpt-4.1-mini |
| 详细回答 | AZURE_OPENAI_ANSWER_DEPLOYMENT | gpt-4.1 |

服务端 .env 示例：

    LLM_PROVIDER=azure
    AZURE_OPENAI_ENDPOINT=https://YOUR_RESOURCE.openai.azure.com/
    AZURE_OPENAI_API_KEY=YOUR_SECRET
    AZURE_OPENAI_API_VERSION=2024-12-01-preview

    AZURE_OPENAI_DEPLOYMENT=gpt-4.1
    AZURE_OPENAI_ASR_DEPLOYMENT=gpt-4o-mini-transcribe
    AZURE_OPENAI_QUESTION_DEPLOYMENT=gpt-4.1-mini
    AZURE_OPENAI_ANSWER_DEPLOYMENT=gpt-4.1

- QUESTION_DEPLOYMENT 不可指向已经不存在的 gpt-4o-mini 部署。
- Azure 的 deployment name 可能与模型名不同；环境变量应填部署名。
- AZURE_OPENAI_API_KEY 仅可存在于后端 .env，不可使用 VITE_ 等会暴露给前端的前缀。

---

## 4. 面接アシスタント：实时字幕到回答的流程

### 4.1 用户操作

1. 填写或选择履历书、JD、职位、面接言語和翻訳先。
2. 点击「面接を開始しましょう」创建会话；此时不会请求麦克风权限。
3. 进入面试页后点击「字幕を開始」；浏览器显示麦克风授权请求。
4. 面试官说话时显示最终字幕和临时字幕。
5. 停顿达到阈值后，系统自动显示翻译和回答候补；「質問を確定」可作为手动兜底。
6. 点击结束面试后，会话状态更新为 completed，并可在面接履歴查看已保存的问答。

### 4.2 浏览器字幕

字幕模块位于 frontend/src/lib/audio.ts，使用 window.SpeechRecognition 或 window.webkitSpeechRecognition。

它支持连续模式、临时识别和最终识别，并在识别意外结束时自动尝试重启。

| 面接言語 | Speech Recognition language |
|---|---|
| 日本語 | ja-JP |
| 中文（简体） | zh-CN |
| English | en-US |

建议使用 Chrome 或 Edge；浏览器需要在 localhost 或 HTTPS 环境下取得麦克风权限。

### 4.3 自动结束判定

自动提交不只依赖 final 事件，因为浏览器可能长期只返回 interim 文本。

当前参数：

    轮询间隔：250ms
    静音阈值：1200ms
    最短文本长度：8 个字符

处理逻辑：

    收到 interim 或 final 且文本非空
      ↓
    更新 lastSpeechAt
      ↓
    将 finalTranscript 与 interimTranscript 组合为当前问题
      ↓
    每 250ms 检查：
      text.length >= 8
      且 Date.now() - lastSpeechAt >= 1200ms
      且未在提交中
      且本段未提交
      ↓
    冻结问题文本、立即清空缓冲区、发送 assist.request

为避免重复请求，前端维护 isSubmitting 与 hasSubmittedCurrentUtterance。新一段语音到来后会重新允许自动提交。开发时可设置：

    VITE_INTERVIEW_DEBUG=true

以在浏览器 Console 中查看 [caption]、[silence]、[auto-submit] 与 API 阶段日志。

### 4.4 WebSocket 协议与两阶段响应

连接地址：

    ws(s)://<backend>/api/ws/interview-sessions/{sessionId}

前端发送的主要事件：

    session.start
    assist.request（包含 questionTextJa）
    audio.commit（手动 ASR 兜底，包含 audioBase64 和 mimeType）
    session.end

后端按以下顺序返回，翻译不会等待详细回答完成：

    transcript.final
    → translation.completed
    → analysis.completed
    → answer.quick.completed
    → answer.generating
    → answer.completed

如果不是完整面试问题，则返回 answer.skipped，原因是 NOT_COMPLETE_INTERVIEW_QUESTION。

前端状态：

    listening → question_detected → translating → generating_answer → completed
                                                   └→ error

### 4.5 问题分析阶段（gpt-4.1-mini）

输入为识别文本和翻译目标语言。输出包括：

- isInterviewQuestion
- isCompleteQuestion
- originalQuestion
- translatedQuestion
- keywords
- questionIntent

核心 Prompt 规则：

    - 清理明显的重复和无意义填充词，但不得改变原意。
    - 不得补充识别文本中没有的事实。
    - 寒暄、音频确认、闲聊、候选人自述：isInterviewQuestion=false。
    - 明显未说完：isCompleteQuestion=false。
    - 仅返回符合 schema 的 JSON。

### 4.6 三档回答阶段

只有 isInterviewQuestion=true 且 isCompleteQuestion=true 时才生成回答。

| 显示档位 | 模型 | 目的 | 预期长度 |
|---|---|---|---|
| クイック回答 | gpt-4.1-mini | 迅速给出口头提示 | 60–120 日文字符 |
| バランス回答 | gpt-4.1-mini | 速度与完整性平衡 | 180–280 日文字符 |
| 詳細回答 | gpt-4.1 | 更完整的口语化 STAR 草案 | 350–550 日文字符 |

快速与平衡回答先返回，详细回答在后台完成后再显示。每个阶段最多返回：

    answerOutline：3 条
    factsUsed：3 条
    missingInformation：3 条

回答上下文只包含当前选中的有效资料：履历书/职务经历书解析文本、当前会话的 JD、当前会话已上传的补充资料。

不会无条件发送空资料、重复资料或未选择资料。资料超长时后端按当前上下文长度限制截断；后续可替换为结构化摘要或 RAG。

### 4.7 事实约束

回答生成的固定结构包含：

    answerOutline
    quick
    balanced
    detailed
    factsUsed [{ documentName, fact }]
    missingInformation
    factCheckRequired

Prompt 必须遵守：

    - 只能使用履历书、职务经历书、JD、补充资料中明确存在的事实。
    - 禁止虚构公司、职位、项目、日期、人数、金额、比例、成果数值、技能、资格或经历。
    - 无法确认的信息必须写入 missingInformation。
    - missingInformation 非空时，factCheckRequired 必须为 true。
    - 回答适合口头面试，并优先采用 STAR 结构。
    - 仅返回 JSON，不附加说明文字。

前端将「使用的履历事实」与「需要确认的信息」分开显示；用户必须自行确认真实性。

---

## 5. 履历书、JD 与补充资料

### 5.1 履历书

支持上传或粘贴文本。后端从 PDF、DOC/DOCX、XLS/XLSX、TXT、MD 等文件提取文本，并保存 resumeId 与解析结果。文件上限为 10 MB。

AI履歴書アシスタント接受：履歴書情報、募集ポジション、JD・求人内容。分析结果包含总分、完整度、表达、量化、ATS、关键词匹配、问题点、改善建议、摘要改善案与优化后履历书。

### 5.2 JD 与补充资料

- JD 保存在面试会话的上下文中，并参与回答生成。
- 补充资料支持粘贴文本或上传文件；上传后先提取文本，再以 documentType=supplementary 保存到当前会话。
- 补充资料可用于公司介绍、准备笔记、希望强调的项目、避免提及的事项和自我介绍草案。
- factsUsed.documentName 标识资料来源，如履历书、职务经历书、JD 或补充资料。

### 5.3 导航切换后的草稿

面接アシスタント的设置使用当前浏览器标签页的 sessionStorage 保存。切换到其他导航栏后再返回会恢复：

    履历书选择/粘贴文本、面接言語、翻訳先、会话名称、公司、职位、JD

关闭该浏览器标签页后，草稿会清除。已上传的履历书通过 resumeId 重新读取详情。

---

## 6. 模擬面接

模拟面试是一个练习流程，不只是题目生成器：

    履历书 + JD + 目标职位 + 主题/难度/题数
      ↓
    生成并开始模擬面接セッション
      ↓
    当前问题、进度、难度、练习计时
      ↓
    文本或音声入力回答
      ↓
    保存并进入下一题 / 提前结束
      ↓
    振り返り：回答済み/未回答清单，可回到任意题修改

### 6.1 题目

后端基于目标职位、目标企业、履历书分析亮点/关键词/原始文本生成问题；用户选择的 Infra 主题可追加预定义的知识型问题。

### 6.2 音声入力

「あなたの回答」区域的「音声入力」使用浏览器 Speech Recognition：

- 第一次点击时请求麦克风权限。
- 识别文本实时写入回答框。
- 再次点击「音声入力を停止」结束。
- 识别语言跟随模擬面接的面接言語（日本語或 English）。
- 浏览器不支持时提示使用 Chrome 或 Edge。

当前语音输入只负责转文字；不会调用后端评分或自动提交。

---

## 7. 错误处理与排查

| 现象 | 处理 |
|---|---|
| 麦克风不弹授权 | 在 Chrome/Edge 的网站权限和系统隐私设置中允许麦克风；确认 localhost/HTTPS |
| 字幕有但没有翻译/回答 | 检查 WebSocket 是否已连接、assist.request 是否发送、浏览器 Console 的 debug 日志，以及后端 ASSIST_FAILED 日志 |
| Azure 返回 DeploymentNotFound | 检查部署名；尤其确认 QUESTION_DEPLOYMENT 对应真实 gpt-4.1-mini 部署 |
| 自动提交太快或太慢 | 调整 silenceMs（建议范围 800–1800ms）与最短文本长度（6–15） |
| 资料不足或回答疑似虚构 | 查看 missingInformation 和 factCheckRequired，并手工修正真实信息 |
| 浏览器不支持语音识别 | 使用最新版 Chrome 或 Edge；界面会显示可理解的错误 |

后端错误不会向前端暴露 API Key 或完整内部配置。日志应避免写入完整履历书、完整音频和授权头。

---

## 8. 本地运行与验证

    npm --prefix frontend run dev
    uv run --project backend uvicorn app.main:app --reload

构建与测试：

    npm --prefix frontend run build
    uv run --project backend pytest

基础手动检查：

1. 上传履历书并填写 JD。
2. 开始面接会话，再点击「字幕を開始」并允许麦克风。
3. 说出一个至少 8 个字符的完整问题，停顿约 1.2 秒。
4. 确认先显示翻译，再显示快速/平衡回答，最后显示详细回答。
5. 确认事实来源和待确认信息符合资料。
6. 切换导航再返回，确认面试设置恢复。
7. 在模擬面接中使用「音声入力」并确认文本进入回答框。

---

## 9. 后续方向（未实现）

1. Azure AI Speech 流式识别，用于提升浏览器字幕稳定性。
2. 结构化履历摘要或 RAG，只检索与问题相关的资料。
3. 说话人区分与会议音频主动共享。
4. 自动评估模拟面试回答，给出针对内容、结构、表达的反馈。
5. 会话级复盘报告与长期练习趋势。

