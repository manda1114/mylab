下面我帮你整理一版**更新后的、可以直接发给 Codex 的设计书**。  


1. 直接在/home/azureuser/ai-assistant仓库里搭项目骨架并开始修改以及新写代码，先和我确认开发设计文档。
2. 先做 mock provider，后接AWS环境，使用OpenAI Key
3. 是/home/azureuser/ai-assistant这份代码
4. 用户自己面试时开着辅助，实时性高，保留对话纪录。
5. 可以直接在/home/azureuser/ai-assistant中构建

- **前端：React**
- **后端：Python FastAPI**
- 其他整体方案不变
- **回答生成逻辑**改为：  
  **LLM 根据“面试语境 + 用户简历 + 当前问题 + 上下文”生成日语回答建议**
- 在**上传简历页面**增加一个**AI 简历分析区域**
- 这个 AI 简历分析区域需要**接入你现有的简历分析工具**

---

# 实时日语面试辅助 Web App 设计书（给 Codex）

## 1. 项目名称
**实时日语面试辅助 Web App**

---

## 2. 项目目标
开发一个网页 App，用于帮助用户在**日语面试场景**下完成以下任务：

1. 实时监听面试官的日语语音
2. 将日语语音快速转写为日文文本
3. 将日文内容实时翻译为中文
4. 分析面试官当前问题的含义与面试意图
5. 根据：
   - 面试语境
   - 用户简历
   - 当前问题
   - 对话上下文  
   生成适合当前场景的**日语回答建议**
6. 在用户上传简历的页面中，集成一个**AI 简历分析区域**
7. 该简历分析区域需要对接**我现有的简历分析工具**
8. 未来系统部署在 **AWS**

---

# 3. 技术栈要求

## 3.1 前端
- **React**
- TypeScript
- Vite（推荐）
- Tailwind CSS
- WebSocket
- Web Audio API / MediaRecorder / AudioWorklet
- 状态管理可用 Zustand 或 Redux Toolkit

## 3.2 后端
- **Python FastAPI**
- WebSocket
- SQLAlchemy
- Pydantic
- PostgreSQL
- Redis
- Docker

## 3.3 AI / 外部能力
- 语音识别（ASR）服务：支持流式日语识别
- LLM：用于翻译、问题分析、回答生成
- 简历分析工具：接入你现有的 AI 简历分析能力
- 对外部 AI 服务做统一封装，便于后续替换

---

# 4. 核心业务功能

## 4.1 实时语音识别
### 功能要求
- 浏览器从麦克风采集音频
- 将音频通过 WebSocket 实时发送给 FastAPI 后端
- 后端调用 ASR 服务，将日语语音实时转写为文本
- 支持：
  - interim transcript（中间识别结果）
  - final transcript（最终识别结果）

### 输出要求
- 前端实时显示日语转写内容
- 中间结果和最终结果视觉上区分显示

---

## 4.2 日语转中文翻译
### 功能要求
- 对最终识别出的日文句子进行中文翻译
- 翻译结果要自然、简洁、适合面试语境
- 尽量减少延迟

### 输出要求
- 每条 final transcript 下显示对应的中文翻译

---

## 4.3 面试问题分析
### 功能要求
系统需要对当前识别出的日语内容进行分析，判断：
1. 是否为面试官提出的问题
2. 属于哪类问题
3. 问题意图是什么
4. 回答时应包含哪些关键点

### 常见问题类型
- 自我介绍
- 志望动机
- 转职理由 / 离职理由
- 项目经验
- 技术能力
- 优势 / 弱点
- 职业规划
- 团队合作
- 困难经历 / 问题解决
- 入职时间
- 加班 / 出差 / 驻场
- 薪资
- 反问问题

### 输出要求
- 中文展示问题类型
- 中文展示问题解析
- 中文展示建议回答要点

---

## 4.4 日语回答建议生成
### 功能要求
LLM 需要根据以下输入生成适合当前面试场景的**日语回答建议**：

- **面试语境**
- **用户简历**
- **当前问题**
- **最近上下文**

### 回答生成要求
输出三种版本：
1. **简短版**
2. **标准版**
3. **正式礼貌版**

### 生成要求
- 必须符合日本企业面试语境
- 语言自然、礼貌、可信
- 尽量口语化但保持商务感
- 不要生成明显夸张或不符合简历事实的内容
- 内容必须与用户简历和上下文保持一致
- 对 IT 工程师 / 开发岗位面试优先优化

### 输出要求
- 日语回答建议
- 可附带中文解释
- 支持一键复制

---

## 4.5 简历上传与 AI 简历分析
这是你新增的重点功能。

### 功能要求
在“上传简历”页面增加一个**AI 简历分析区域**，并接入你现有的简历分析工具。

### 页面功能拆分
上传简历页面包括两个部分：

#### 区域 A：简历上传
- 支持上传 PDF / DOCX / TXT
- 解析简历文本
- 存储简历原文
- 支持预览提取后的文本内容

#### 区域 B：AI 简历分析
- 展示你现有简历分析工具的输出结果
- 支持点击“开始分析”
- 支持展示：
  - 简历摘要
  - 技能提取
  - 项目经历提取
  - 优势分析
  - 风险点 / 不足点
  - 适合岗位建议
  - 日语面试中可重点突出的经历
- 分析结果可保存
- 分析结果后续可以提供给回答生成模块使用

### 与现有简历分析工具的集成要求
请 Codex 按“可插拔集成”方式设计，不要把简历分析逻辑写死。

要求设计一个统一接口，例如：

```python
class ResumeAnalyzer:
    async def analyze(self, resume_text: str) -> dict:
        ...
```

如果你现有工具是：
- 一个 Python 模块
- 一个本地服务
- 一个 HTTP API
- 一个单独容器服务

则都要能通过适配器方式接入。

### 推荐适配器模式
```python
class ResumeAnalysisProvider(Protocol):
    async def analyze_resume(self, resume_text: str) -> dict:
        ...
```

实现多个 provider：
- `LocalResumeAnalyzerProvider`
- `HttpResumeAnalyzerProvider`
- `ExternalServiceResumeAnalyzerProvider`

这样后续你把你现有的工具插进去就非常方便。

---

# 5. 页面设计

## 5.1 页面 1：首页 / 入口页
- 项目说明
- 进入系统按钮
- 登录入口（未来可接 Cognito）
- 也可先支持访客模式

---

## 5.2 页面 2：简历上传与分析页
### 区域 A：上传区
- 上传文件按钮
- 支持 PDF / DOCX / TXT
- 文件上传状态显示
- 简历解析结果展示
- 手动编辑简历文本

### 区域 B：AI 简历分析区
- “开始 AI 分析”按钮
- 展示分析中状态
- 展示分析结果卡片，包括：
  - 简历摘要
  - 核心技能
  - 项目经历
  - 强项
  - 不足项
  - 面试重点建议
  - 适合日语面试突出的话题

### 区域 C：简历结构化信息
将简历提取为结构化字段，可供回答生成模块调用：
- 姓名
- 学历
- 工作年限
- 当前岗位
- 技术栈
- 项目经历
- 转职理由（可手动补充）
- 志望动机（可手动补充）
- 优势
- 弱点
- 日语自我介绍要点

---

## 5.3 页面 3：实时面试辅助主页面
页面布局建议分 4 栏或 4 区：

### 区域 A：控制区
- 开始监听
- 停止监听
- 麦克风状态
- WebSocket 连接状态
- 当前会话状态

### 区域 B：实时日语转写区
- 显示实时识别文本
- interim 文本浅色显示
- final 文本正常显示
- 按时间顺序排列

### 区域 C：翻译与问题分析区
对每条最终文本显示：
- 中文翻译
- 问题类型
- 问题解析
- 回答要点

### 区域 D：回答建议区
显示：
- 简短版日语回答
- 标准版日语回答
- 正式礼貌版日语回答
- 中文参考说明
- 一键复制
- 重新生成
- “更简短”
- “更自然”
- “更正式”

---

## 5.4 页面 4：历史记录页
- 查看历史面试记录
- 每条记录展示：
  - 日文原文
  - 中文翻译
  - 问题分析
  - 回答建议
- 支持按时间筛选
- 支持导出

---

# 6. 业务流程设计

## 6.1 简历上传与分析流程
1. 用户上传简历文件
2. 前端将文件发送给后端
3. 后端解析文件文本
4. 保存简历原文和结构化内容
5. 用户点击“AI 分析”
6. 后端调用现有简历分析工具
7. 返回分析结果给前端
8. 前端在 AI 简历分析区域展示结果
9. 分析结果写入数据库
10. 面试回答生成时读取：
   - 简历原文
   - 结构化简历信息
   - AI 简历分析结果

---

## 6.2 实时面试辅助流程
1. 用户进入主页面
2. 建立 WebSocket 连接
3. 开始麦克风采集
4. 前端按小片段发送音频流
5. 后端调用 ASR 获取实时日语文本
6. 前端显示 interim / final transcript
7. 对每条 final transcript：
   - 翻译成中文
   - 分析问题类型与意图
   - 结合面试语境 + 用户简历 + 当前问题 + 上下文生成回答建议
8. 后端将结果推送给前端
9. 前端展示分析与回答内容
10. 同步保存到当前面试会话

---

# 7. 数据模型设计

## 7.1 User
```ts
type User = {
  id: string
  email: string
  name?: string
  createdAt: string
  updatedAt: string
}
```

## 7.2 Resume
```ts
type Resume = {
  id: string
  userId: string
  fileName: string
  fileType: string
  rawText: string
  parsedText?: string
  createdAt: string
  updatedAt: string
}
```

## 7.3 ResumeAnalysis
```ts
type ResumeAnalysis = {
  id: string
  resumeId: string
  summary?: string
  skills?: string[]
  projects?: string[]
  strengths?: string[]
  weaknesses?: string[]
  interviewHighlights?: string[]
  suggestedTopics?: string[]
  rawAnalysisJson?: Record<string, any>
  createdAt: string
  updatedAt: string
}
```

## 7.4 StructuredResumeProfile
```ts
type StructuredResumeProfile = {
  id: string
  resumeId: string
  name?: string
  education?: string
  yearsOfExperience?: number
  currentRole?: string
  techStack?: string[]
  projectHistory?: string
  motivation?: string
  reasonForJobChange?: string
  strengths?: string
  weaknesses?: string
  selfIntroductionPoints?: string
  updatedAt: string
}
```

## 7.5 InterviewSession
```ts
type InterviewSession = {
  id: string
  userId: string
  resumeId?: string
  status: "active" | "completed"
  startedAt: string
  endedAt?: string
}
```

## 7.6 InterviewTurn
```ts
type InterviewTurn = {
  id: string
  sessionId: string
  japaneseText: string
  chineseTranslation?: string
  questionType?: string
  analysis?: string
  answerShort?: string
  answerStandard?: string
  answerPolite?: string
  createdAt: string
}
```

---

# 8. 前端技术要求

## 8.1 前端框架
- 使用 **React + TypeScript**
- 使用 **Vite** 初始化项目
- UI 使用 Tailwind CSS
- 状态管理使用 Zustand
- 网络请求使用 fetch 或 axios
- WebSocket 单独封装 hook 或 service

## 8.2 推荐前端目录结构
```txt
frontend/
  src/
    app/
    pages/
      HomePage.tsx
      ResumePage.tsx
      InterviewPage.tsx
      HistoryPage.tsx
    components/
      layout/
      resume/
      interview/
      common/
    hooks/
      useWebSocket.ts
      useAudioRecorder.ts
      useResumeUpload.ts
      useInterviewSession.ts
    services/
      api.ts
      ws.ts
      resume.ts
      interview.ts
    store/
      useAppStore.ts
      useInterviewStore.ts
      useResumeStore.ts
    types/
    utils/
    main.tsx
```

## 8.3 前端组件建议
### 简历页组件
- `ResumeUploadPanel`
- `ResumeTextPreview`
- `ResumeAnalysisPanel`
- `StructuredResumeEditor`

### 面试页组件
- `MicrophoneControl`
- `TranscriptPanel`
- `TranslationPanel`
- `QuestionAnalysisCard`
- `AnswerSuggestionPanel`

---

# 9. 后端技术要求

## 9.1 后端框架
- 使用 **Python FastAPI**
- 提供 REST API + WebSocket
- 数据库 ORM 使用 SQLAlchemy
- 配置管理使用 Pydantic Settings
- Redis 用于会话上下文缓存
- 所有外部 AI 服务封装为 service/provider

## 9.2 推荐后端目录结构
```txt
backend/
  app/
    main.py
    core/
      config.py
      security.py
    api/
      routes/
        resume.py
        analysis.py
        interview.py
        session.py
    websocket/
      interview_ws.py
    services/
      asr_service.py
      translation_service.py
      interview_analysis_service.py
      answer_generation_service.py
      resume_parser_service.py
      resume_analysis_service.py
      context_service.py
    providers/
      llm/
        base.py
        openai_provider.py
      resume_analysis/
        base.py
        local_provider.py
        http_provider.py
    models/
      user.py
      resume.py
      resume_analysis.py
      interview_session.py
      interview_turn.py
    schemas/
      resume.py
      interview.py
      analysis.py
    db/
      base.py
      session.py
      init_db.py
```

---

# 10. 简历分析工具集成设计

这是要重点告诉 Codex 的部分。

## 10.1 目标
系统已有一个“我做好的 AI 简历分析工具”，需要插入到本系统的上传简历页面中。

## 10.2 设计原则
- 不要将外部简历分析逻辑写死
- 使用 provider / adapter 模式
- 允许后续切换不同实现方式

## 10.3 抽象接口
```python
from typing import Protocol, Any

class ResumeAnalysisProvider(Protocol):
    async def analyze_resume(self, resume_text: str) -> dict[str, Any]:
        ...
```

## 10.4 实现方式
Codex 需要预留以下实现：

### 方式 1：调用本地 Python 模块
```python
class LocalResumeAnalyzerProvider:
    async def analyze_resume(self, resume_text: str) -> dict:
        # 调用你现有的 Python 分析函数
        ...
```

### 方式 2：调用 HTTP API
```python
class HttpResumeAnalyzerProvider:
    def __init__(self, base_url: str, api_key: str | None = None):
        ...

    async def analyze_resume(self, resume_text: str) -> dict:
        # 请求你的现有简历分析服务
        ...
```

### 方式 3：调用独立容器服务
适合后续拆成微服务

## 10.5 输出数据标准化
不管底层工具输出什么格式，系统内部应统一转换为标准结构：
```json
{
  "summary": "...",
  "skills": ["Java", "Python", "AWS"],
  "projects": ["项目A", "项目B"],
  "strengths": ["后端开发经验扎实"],
  "weaknesses": ["日语商务表达需提升"],
  "interviewHighlights": ["可重点强调 AWS 项目经验"],
  "suggestedTopics": ["转职动机", "日语团队协作经验"]
}
```

---

# 11. 回答生成逻辑设计

## 11.1 输入来源
回答生成模块必须综合以下信息：

1. **面试语境**
   - 当前是在日本企业求职面试
   - 岗位类型（例如后端工程师、全栈工程师、Java 开发等）
   - 当前对话轮次

2. **用户简历**
   - 原始简历文本
   - 结构化简历信息
   - AI 简历分析结果

3. **当前问题**
   - 面试官当前这句日语问题
   - 问题分类和意图分析

4. **上下文**
   - 最近几轮问答
   - 已经生成过的答案
   - 之前提过的经历和技术点

## 11.2 输出内容
```json
{
  "answerShort": "...",
  "answerStandard": "...",
  "answerPolite": "...",
  "answerExplanationZh": "..."
}
```

## 11.3 生成约束
- 不能脱离简历事实
- 优先使用简历中已有的项目经历和技能
- 回答要适合真实日语面试口语
- 简短版控制在 2~4 句
- 标准版控制在 4~8 句
- 正式版更礼貌但不要太冗长

---

# 12. API 设计

## 12.1 简历上传
### `POST /api/resumes/upload`
上传简历文件

返回：
```json
{
  "resumeId": "uuid",
  "fileName": "resume.pdf",
  "rawText": "..."
}
```

---

## 12.2 获取简历详情
### `GET /api/resumes/{resumeId}`

---

## 12.3 触发简历分析
### `POST /api/resumes/{resumeId}/analyze`
调用你现有的简历分析工具

返回：
```json
{
  "resumeId": "uuid",
  "analysis": {
    "summary": "...",
    "skills": ["Java", "Python"],
    "projects": ["项目A"],
    "strengths": ["..."],
    "weaknesses": ["..."],
    "interviewHighlights": ["..."],
    "suggestedTopics": ["..."]
  }
}
```

---

## 12.4 保存结构化简历信息
### `PUT /api/resumes/{resumeId}/profile`

---

## 12.5 创建面试会话
### `POST /api/interview/sessions`

---

## 12.6 获取历史记录
### `GET /api/interview/sessions/{sessionId}`

---

# 13. WebSocket 设计

## 13.1 连接地址
```txt
ws://localhost:8000/ws/interview/{sessionId}
```

生产环境：
```txt
wss://your-domain.com/ws/interview/{sessionId}
```

## 13.2 前端发送
- 音频二进制帧
- 控制消息 JSON

## 13.3 后端返回消息类型
- `interim_transcript`
- `final_transcript`
- `translation`
- `analysis`
- `answer_suggestion`
- `error`
- `session_status`

---

# 14. AWS 部署要求

## 14.1 部署目标
- 前端 React 静态资源部署到：
  - **S3 + CloudFront**
  或
  - **AWS Amplify Hosting**
- FastAPI 部署到：
  - **ECS Fargate**
- 使用：
  - **ALB** 支持 HTTP / HTTPS / WebSocket
  - **RDS PostgreSQL**
  - **ElastiCache Redis**
  - **S3**
  - **CloudWatch**
  - **Secrets Manager**
  - **Route 53**
  - **ACM**

## 14.2 容器化要求
- 前端和后端都提供 Dockerfile
- 提供 docker-compose 用于本地开发
- 配置通过环境变量管理

---

# 15. MVP 需求

## 必做
1. React 前端页面框架
2. FastAPI REST API
3. WebSocket 实时音频通道
4. 日语语音识别接入
5. 中文翻译
6. 问题分析
7. 基于“面试语境 + 用户简历 + 当前问题 + 上下文”的日语回答生成
8. 简历上传功能
9. AI 简历分析区域
10. 接入现有简历分析工具的 provider 接口
11. 历史记录保存

## 可后续再做
- 登录权限系统
- PDF 导出
- 多模型切换
- 移动端优化
- TTS 朗读回答
- 多语言支持

---

# 16. 给 Codex 的直接开发指令

你可以直接把下面这段发给 Codex：

```txt
请帮我开发一个“实时日语面试辅助 Web App”。

技术栈要求：
- 前端：React + TypeScript + Vite + Tailwind CSS
- 后端：Python FastAPI + WebSocket + SQLAlchemy
- 数据库：PostgreSQL
- 缓存：Redis
- 部署目标：AWS（S3/CloudFront 或 Amplify、ECS Fargate、ALB、RDS、ElastiCache、S3）

核心功能：
1. 浏览器采集麦克风音频，并通过 WebSocket 实时发送给 FastAPI 后端
2. 后端接收音频流并调用日语 ASR 服务，将语音转写成日文文本
3. 将日文翻译成中文
4. 分析面试官问题的类型、意图和回答要点
5. 使用 LLM 根据“面试语境 + 用户简历 + 当前问题 + 上下文”生成日语回答建议
6. 回答输出简短版、标准版、正式礼貌版
7. 支持简历上传（PDF/DOCX/TXT）
8. 上传简历页面要增加一个 AI 简历分析区域
9. AI 简历分析区域要接入我现有的简历分析工具
10. 现有简历分析工具的接入要使用 provider / adapter 模式，方便插拔和替换
11. 简历分析结果也要作为回答生成模块的输入之一
12. 支持面试历史记录保存与查看

页面需求：
- 首页
- 简历上传与分析页
- 实时面试辅助页
- 历史记录页

后端设计要求：
- 提供 REST API 和 WebSocket
- 抽象出以下服务层：
  - asr_service
  - translation_service
  - interview_analysis_service
  - answer_generation_service
  - resume_parser_service
  - resume_analysis_service
  - context_service
- 简历分析工具必须通过抽象接口接入，例如：
  - ResumeAnalysisProvider
  - LocalResumeAnalyzerProvider
  - HttpResumeAnalyzerProvider

请先输出：
1. 完整项目目录结构
2. 系统架构设计
3. 数据模型设计
4. REST API 设计
5. WebSocket 协议设计
6. 简历分析工具集成方案
7. MVP 开发步骤

然后再按模块逐步生成代码。

编码要求：
- 前端全部使用 TypeScript
- 后端使用 Python
- 所有敏感配置通过环境变量管理
- 代码结构清晰，方便未来 AWS 部署
- AI 服务必须做接口封装，不能和业务逻辑写死耦合
- 回答生成逻辑必须使用：面试语境 + 用户简历 + 当前问题 + 上下文
- 简历上传页必须包含 AI 简历分析区域
```

---

如果你愿意，我下一步可以直接继续帮你做下面两个版本之一：

### 版本 1
我把上面这份内容整理成**更正式的“系统设计书文档格式”**，像真正项目文档一样分章节。

### 版本 2
我直接帮你写成一份**超完整 Codex Prompt**，包括：
- 项目目录
- 前端组件清单
- FastAPI 路由
- 数据库表结构
- WebSocket 消息格式
- 简历分析 provider 接口代码骨架
- AWS 部署要求

如果你要效率最高，我建议下一步我直接给你：  
**“可以直接复制给 Codex 的完整版 Prompt（超详细版）”**。