from __future__ import annotations

import logging

from fastapi import APIRouter, File, HTTPException, UploadFile

from app.core.config import get_settings
from app.core.security import is_allowed_file
from app.models.responses import UploadResponse
from app.services.file_extractor import extract_text

logger = logging.getLogger(__name__)
router = APIRouter()


@router.post("/upload-resume", response_model=UploadResponse)
async def upload_resume(file: UploadFile = File(...)) -> UploadResponse:
    settings = get_settings()

    if not file.filename:
        raise HTTPException(status_code=400, detail="ファイル名がありません。")

    content_type = file.content_type or ""
    if not is_allowed_file(file.filename, content_type):
        raise HTTPException(
            status_code=415,
            detail="対応していないファイル形式です。PDF / DOCX / TXT のみ対応しています。",
        )

    content = await file.read()
    if len(content) > settings.max_upload_bytes:
        raise HTTPException(status_code=413, detail=f"ファイルサイズが上限（{settings.max_upload_bytes // (1024 * 1024)}MB）を超えています。")

    try:
        text = extract_text(content, file.filename)
    except Exception:
        logger.exception("File extraction failed")
        raise HTTPException(status_code=422, detail="ファイルのテキスト抽出に失敗しました。")

    return UploadResponse(success=True, extractedText=text)
