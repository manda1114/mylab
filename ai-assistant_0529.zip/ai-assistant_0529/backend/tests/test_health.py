from __future__ import annotations

from fastapi.testclient import TestClient

def test_root_shows_backend_info(client: TestClient) -> None:
    response = client.get("/")
    assert response.status_code == 200
    assert response.json() == {
        "name": "ResumePilot",
        "env": "local",
        "docs": "/docs",
        "health": "/api/health",
    }

def test_health_ok(client: TestClient) -> None:
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}
