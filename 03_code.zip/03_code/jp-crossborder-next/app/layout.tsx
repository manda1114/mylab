// app/layout.tsx
import "./globals.css";
import type { Metadata } from "next";
import { Noto_Sans_JP } from "next/font/google";
import React from "react";

const notoSansJp = Noto_Sans_JP({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
});

// 这里建议把域名写到环境变量里：NEXT_PUBLIC_SITE_URL
// 本地没有设置时会退回到 http://localhost:3000
const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: "越境EC向けコマースプラットフォーム",
  description:
    "越境EC向けマルチテナント型コマース・プラットフォーム。日本企業向けに安心・シンプルなUIを提供します。",
  openGraph: {
    title: "越境EC向けコマースプラットフォーム",
    description: "越境EC向けマルチテナント型コマース・プラットフォーム。",
    type: "website",
    url: "/", // metadataBase + "/" になる
    images: [
      // 相対パスでもOK（metadataBase があるので絶対URLに解決される）
      // 例: public/og-image.png を用意して "/og-image.png" と書く
      "/og-image.png",
      // 今の placeholder を使いたければそのままでもOK（すでに絶対URL）
      // "https://via.placeholder.com/1200x630.png?text=Cross-border+Commerce",
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "越境EC向けコマースプラットフォーム",
    description: "越境EC向けマルチテナント型コマース・プラットフォーム。",
    images: ["/og-image.png"],
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ja">
      <body className={`${notoSansJp.className} text-slate-900 antialiased`}>
        {children}
      </body>
    </html>
  );
}
