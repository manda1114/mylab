/** @type {import('tailwindcss').Config} */
const config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}"
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          DEFAULT: "#008060", // Shopify っぽい深緑
          dark: "#005c46",
          light: "#e6f4ef"
        }
      }
    }
  },
  plugins: []
};

export default config;
