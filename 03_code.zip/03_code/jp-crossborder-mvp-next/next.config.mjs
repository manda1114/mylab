/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  experimental: {
    appDir: true
  },
  images: {
    domains: ["your-s3-bucket.s3.amazonaws.com"]
  },
  i18n: {
    locales: ["ja", "en", "zh-CN"],
    defaultLocale: "ja"
  }
};

export default nextConfig;
