// app/(marketing)/page.tsx
import { Card } from "@/components/ui/card";

// いトップページ
export default function HomePage() {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      {/* ヒーローセクション */}
      <section className="mx-auto max-w-6xl px-4 pb-12 pt-10 md:flex md:items-center md:gap-10 md:pb-16 md:pt-16">
        {/* 左側：テキスト */}
        <div className="md:w-1/2">
          <p className="mb-3 text-xs font-semibold uppercase tracking-[0.2em] text-emerald-600">
            JAPAN × CHINA CROSS-BORDER
          </p>
          <h1 className="mb-4 text-3xl font-bold leading-tight md:text-4xl">
            日本の主婦・学生でも始められる
            <br />
            中日越境ECのオールインワンプラットフォーム
          </h1>
          <p className="mb-6 text-sm text-slate-700 md:text-base">
            選品、ショップ構築、翻訳、AIサポート、合規まで。
            中国サプライチェーンと日本の軽起業セラーをつなぎ、
            月数万円からの安定した副業収入づくりをサポートします。
          </p>
          <div className="mb-4 flex flex-wrap items-center gap-3">
            <a
              href="/auth/register"
              className="rounded-full bg-emerald-600 px-6 py-2 text-sm font-medium text-white shadow-sm hover:bg-emerald-700"
            >
              無料で始める
            </a>
            <a
              href="/services"
              className="rounded-full border border-slate-300 px-6 py-2 text-sm font-medium text-slate-800 hover:bg-slate-100"
            >
              サービスを見る
            </a>
          </div>
          <p className="text-xs text-slate-500">
            クレジットカード登録不要・オンライン説明会も無料でご案内しています。
          </p>
        </div>

        {/* 右側：ダッシュボードのイメージカード */}
        <div className="mt-10 w-full md:mt-0 md:w-1/2">
          <Card className="border-slate-200 bg-white p-4 shadow-md">
            <div className="mb-3 flex items-center justify-between">
              <div className="text-xs font-medium text-slate-600">
                売上ダッシュボード（イメージ）
              </div>
              <span className="rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] text-emerald-700">
                リアルタイム更新
              </span>
            </div>
            <div className="mb-4 grid gap-3 md:grid-cols-3">
              <div className="rounded-lg bg-slate-50 p-3">
                <div className="text-[10px] text-slate-500">
                  今月の売上
                </div>
                <div className="mt-1 text-lg font-semibold text-slate-900">
                  ¥ 285,400
                </div>
                <div className="mt-1 text-[10px] text-emerald-600">
                  前月比 +32%
                </div>
              </div>
              <div className="rounded-lg bg-slate-50 p-3">
                <div className="text-[10px] text-slate-500">
                  今月の注文数
                </div>
                <div className="mt-1 text-lg font-semibold text-slate-900">
                  128 件
                </div>
                <div className="mt-1 text-[10px] text-slate-500">
                  平均単価 ¥2,230
                </div>
              </div>
              <div className="rounded-lg bg-slate-50 p-3">
                <div className="text-[10px] text-slate-500">
                  AI 推奨商品
                </div>
                <div className="mt-1 text-xs text-slate-800">
                  収納グッズ / キッチン家電 / ベビー用品
                </div>
                <div className="mt-1 text-[10px] text-emerald-600">
                  日本×中国データから自動提案
                </div>
              </div>
            </div>
            <div className="h-28 rounded-lg bg-gradient-to-tr from-emerald-100 via-sky-100 to-violet-100">
              <div className="flex h-full items-center justify-center text-[10px] text-slate-500">
                売上推移グラフ（デモ）
              </div>
            </div>
          </Card>
        </div>
      </section>

      {/* 機能紹介セクション */}
      <section className="mx-auto max-w-6xl px-4 pb-16">
        <h2 className="mb-6 text-xl font-semibold">
          中日越境ECに必要な機能を、ひとつのプラットフォームで
        </h2>

        <div className="grid gap-4 md:grid-cols-3">
          <Card className="border-slate-200 bg-white">
            <div className="mb-2 text-sm font-semibold">
              選品プール × AI 选品
            </div>
            <p className="text-xs text-slate-700">
              中国サプライヤーと連携した選品プールから、日本市場向けに売れやすい商品候補をAIが提案。
              主婦・学生でも低リスクで始められます。
            </p>
          </Card>
          <Card className="border-slate-200 bg-white">
            <div className="mb-2 text-sm font-semibold">
              多言語ショップ構築
            </div>
            <p className="text-xs text-slate-700">
              日・英・中の多言語ショップを数クリックで構築。
              決済・配送テンプレートも用意し、越境ECの面倒な初期設定を簡略化します。
            </p>
          </Card>
          <Card className="border-slate-200 bg-white">
            <div className="mb-2 text-sm font-semibold">
              合規・税務のベースライン
            </div>
            <p className="text-xs text-slate-700">
              日本の消費税（JCT）や清関、知財に関する基本ガイドラインを標準装備。
              提携専門家への相談もスムーズに行えます。
            </p>
          </Card>
        </div>
      </section>

      {/* 一番下の CTA セクション */}
      <section className="border-t border-slate-200 bg-white">
        <div className="mx-auto flex max-w-6xl flex-col items-start justify-between gap-4 px-4 py-10 md:flex-row md:items-center">
          <div>
            <h3 className="mb-2 text-lg font-semibold text-slate-900">
              まずは小さく始めて、3ヶ月で月5万円の副収入を目指しましょう。
            </h3>
            <p className="text-xs text-slate-600 md:text-sm">
              無料アカウント登録で、基礎講座とテンプレートショップにすぐアクセスできます。
            </p>
          </div>
          <div className="flex flex-wrap gap-3">
            <a
              href="/auth/register"
              className="rounded-full bg-emerald-600 px-6 py-2 text-sm font-medium text-white shadow-sm hover:bg-emerald-700"
            >
              無料アカウントを作成
            </a>
            <a
              href="/contact"
              className="rounded-full border border-slate-300 px-6 py-2 text-sm font-medium text-slate-800 hover:bg-slate-100"
            >
              オンライン相談を予約
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
