// components/navbar.tsx
"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

// ナビゲーションバー
export default function Navbar() {
  const pathname = usePathname();
  const isActive = (href: string) => pathname === href;

  return (
    <header className="border-b bg-white/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3 md:py-4">
        {/* ロゴ部分 */}
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded bg-emerald-600 text-xs font-bold text-white">
            CB
          </div>
          <div className="text-sm font-semibold text-slate-900">
            CrossBorder Japan
          </div>
        </div>

        {/* ナビゲーションリンク */}
        <nav className="hidden items-center gap-6 text-sm text-slate-700 md:flex">
          <Link
            href="/"
            className={
              isActive("/") ? "text-emerald-600" : "hover:text-slate-900"
            }
          >
            ホーム
          </Link>
          <Link
            href="/company"
            className={
              isActive("/company")
                ? "text-emerald-600"
                : "hover:text-slate-900"
            }
          >
            会社情報
          </Link>
          <Link
            href="/services"
            className={
              isActive("/services")
                ? "text-emerald-600"
                : "hover:text-slate-900"
            }
          >
            サービス
          </Link>
          <Link
            href="/cases"
            className={
              isActive("/cases")
                ? "text-emerald-600"
                : "hover:text-slate-900"
            }
          >
            導入事例
          </Link>
          <Link
            href="/contact"
            className={
              isActive("/contact")
                ? "text-emerald-600"
                : "hover:text-slate-900"
            }
          >
            お問い合わせ
          </Link>
        </nav>

        {/* 右側のアクション */}
        <div className="flex items-center gap-3">
          <Link
            href="/auth/login"
            className="hidden text-sm text-slate-700 hover:text-slate-900 md:inline-block"
          >
            ログイン
          </Link>
          <Link
            href="/auth/register"
            className="rounded-full bg-emerald-600 px-4 py-1.5 text-sm font-medium text-white shadow-sm hover:bg-emerald-700 md:px-5"
          >
            無料で始める
          </Link>
        </div>
      </div>
    </header>
  );
}
