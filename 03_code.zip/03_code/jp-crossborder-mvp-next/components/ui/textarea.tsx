// components/ui/textarea.tsx
import { TextareaHTMLAttributes, forwardRef } from "react";
import clsx from "clsx";

interface TextareaProps
  extends TextareaHTMLAttributes<HTMLTextAreaElement> {}

// 共通テキストエリアコンポーネント
export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(
  function TextareaBase({ className, ...props }, ref) {
    return (
      <textarea
        ref={ref}
        className={clsx(
          "w-full rounded border border-gray-300 px-2 py-1 text-sm outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500",
          className
        )}
        {...props}
      />
    );
  }
);
