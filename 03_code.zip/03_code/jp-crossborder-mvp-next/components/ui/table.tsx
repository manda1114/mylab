// components/ui/table.tsx
import { ReactNode, HTMLAttributes } from "react";
import clsx from "clsx";

interface TableProps extends HTMLAttributes<HTMLTableElement> {
  children: ReactNode;
}

interface TableSectionProps
  extends HTMLAttributes<HTMLTableSectionElement> {
  children: ReactNode;
}

interface TableRowProps extends HTMLAttributes<HTMLTableRowElement> {
  children: ReactNode;
}

interface TableCellProps
  extends HTMLAttributes<HTMLTableCellElement> {
  children: ReactNode;
}

// 共通テーブルコンポーネント
export function Table({ className, children, ...props }: TableProps) {
  return (
    <table
      className={clsx("w-full text-left text-sm", className)}
      {...props}
    >
      {children}
    </table>
  );
}

export function TableHead({ children, ...props }: TableSectionProps) {
  return (
    <thead {...props}>
      {children}
    </thead>
  );
}

export function TableBody({ children, ...props }: TableSectionProps) {
  return (
    <tbody {...props}>
      {children}
    </tbody>
  );
}

export function TableRow({ className, children, ...props }: TableRowProps) {
  return (
    <tr
      className={clsx("border-b", className)}
      {...props}
    >
      {children}
    </tr>
  );
}

export function TableHeaderCell({
  className,
  children,
  ...props
}: TableCellProps) {
  return (
    <th
      className={clsx("bg-gray-50 py-2 text-xs font-semibold", className)}
      {...props}
    >
      {children}
    </th>
  );
}

export function TableCell({
  className,
  children,
  ...props
}: TableCellProps) {
  return (
    <td
      className={clsx("py-1 align-middle text-xs", className)}
      {...props}
    >
      {children}
    </td>
  );
}
