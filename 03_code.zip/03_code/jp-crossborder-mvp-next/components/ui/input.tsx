// components/ui/input.tsx
import { InputHTMLAttributes, forwardRef } from "react";
import clsx from "clsx";

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {}

// 共通入力フィールドコンポーネント
export const Input = forwardRef<HTMLInputElement, InputProps>(
  function InputBase({ className, ...props }, ref) {
    return (
      <input
        ref={ref}
        className={clsx(
          "w-full rounded border border-gray-300 px-2 py-1 text-sm outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500",
          className
        )}
        {...props}
      />
    );
  }
);
