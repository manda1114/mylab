// components/ui/select.tsx
import { SelectHTMLAttributes, forwardRef } from "react";
import clsx from "clsx";

interface SelectProps
  extends SelectHTMLAttributes<HTMLSelectElement> {}

// 共通セレクトボックスコンポーネント
export const Select = forwardRef<HTMLSelectElement, SelectProps>(
  function SelectBase({ className, children, ...props }, ref) {
    return (
      <select
        ref={ref}
        className={clsx(
          "w-full rounded border border-gray-300 px-2 py-1 text-sm outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500",
          className
        )}
        {...props}
      >
        {children}
      </select>
    );
  }
);
