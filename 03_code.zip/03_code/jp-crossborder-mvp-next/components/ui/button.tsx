// components/ui/button.tsx
import { ButtonHTMLAttributes, ReactNode } from "react";
import clsx from "clsx";

type ButtonVariant = "primary" | "secondary" | "outline";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  children: ReactNode;
}

// 共通ボタンコンポーネント
export function Button({
  variant = "primary",
  className,
  children,
  ...props
}: ButtonProps) {
  const base =
    "inline-flex items-center justify-center rounded text-sm font-medium transition-colors focus:outline-none disabled:cursor-not-allowed disabled:opacity-60";

  const variants: Record<ButtonVariant, string> = {
    primary: "bg-blue-600 text-white hover:bg-blue-700 px-4 py-2",
    secondary: "bg-gray-800 text-white hover:bg-gray-900 px-4 py-2",
    outline:
      "border border-gray-300 bg-white text-gray-800 hover:bg-gray-50 px-4 py-2"
  };

  return (
    <button
      className={clsx(base, variants[variant], className)}
      {...props}
    >
      {children}
    </button>
  );
}
