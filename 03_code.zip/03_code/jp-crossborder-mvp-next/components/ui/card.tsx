// components/ui/card.tsx
import { ReactNode } from "react";
import clsx from "clsx";

interface CardProps {
  children: ReactNode;
  className?: string;
}

// シンプルなカードコンポーネント
export function Card({ children, className }: CardProps) {
  return (
    <div
      className={clsx(
        "rounded border border-gray-200 bg-white p-4 shadow-sm",
        className
      )}
    >
      {children}
    </div>
  );
}
