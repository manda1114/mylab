// components/footer.tsx

// シンプルなフッターコンポーネント
export default function Footer() {
  return (
    <footer className="border-t bg-gray-100">
      <div className="mx-auto max-w-5xl px-4 py-4 text-xs text-gray-500">
        © {new Date().getFullYear()} CrossBorder Japan
      </div>
    </footer>
  );
}
