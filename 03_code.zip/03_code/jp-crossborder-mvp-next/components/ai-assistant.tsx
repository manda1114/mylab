// components/ai-assistant.tsx
"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

type Tab = "translate" | "advice";

// ダッシュボード右下の AI アシスタント
export default function AiAssistant() {
  const [open, setOpen] = useState(false);
  const [tab, setTab] = useState<Tab>("translate");
  const [input, setInput] = useState("");
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);

  const handleTranslate = async () => {
    setLoading(true);
    setResult("");
    const res = await fetch("/api/ai/translate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        text: input,
        sourceLang: "auto",
        targetLang: "ja"
      })
    });
    const data = await res.json();
    setResult(data.translatedText || "");
    setLoading(false);
  };

  const handleAdvice = async () => {
    setLoading(true);
    setResult("");
    const res = await fetch("/api/ai/product-advice", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        category: input,
        targetMarket: "Japan",
        priceRange: "low-mid",
        description: ""
      })
    });
    const data = await res.json();
    setResult(
      (data.tips || "") +
        "\n\n" +
        (data.suggestions || []).map((s: string) => "- " + s).join("\n")
    );
    setLoading(false);
  };

  const onSubmit = async () => {
    if (!input.trim()) return;
    if (tab === "translate") await handleTranslate();
    else await handleAdvice();
  };

  return (
    <>
      <Button
        type="button"
        variant="primary"
        className="fixed bottom-4 right-4 z-40 rounded-full px-4 py-2 shadow-lg"
        onClick={() => setOpen((v) => !v)}
      >
        AI アシスタント
      </Button>

      {open && (
        <div className="fixed bottom-16 right-4 z-40 w-80 rounded-lg border bg-white p-3 shadow-lg">
          <div className="mb-2 flex justify-between text-xs">
            <div className="space-x-2">
              <button
                onClick={() => setTab("translate")}
                className={
                  tab === "translate"
                    ? "font-bold text-blue-600"
                    : "text-gray-700"
                }
              >
                翻訳
              </button>
              <button
                onClick={() => setTab("advice")}
                className={
                  tab === "advice"
                    ? "font-bold text-blue-600"
                    : "text-gray-700"
                }
              >
                选品アドバイス
              </button>
            </div>
            <button
              onClick={() => setOpen(false)}
              className="text-gray-500"
            >
              ×
            </button>
          </div>

          <Textarea
            className="mb-2 h-24 text-xs"
            placeholder={
              tab === "translate"
                ? "翻訳したいテキストを入力..."
                : "商品ジャンルやターゲット顧客などを入力..."
            }
            value={input}
            onChange={(e) => setInput(e.target.value)}
          />

          <Button
            type="button"
            variant="primary"
            disabled={loading}
            className="mb-2 w-full text-xs"
            onClick={onSubmit}
          >
            {loading ? "処理中..." : "AI に聞く"}
          </Button>

          {result && (
            <pre className="max-h-40 overflow-auto rounded bg-gray-50 p-2 text-[11px]">
              {result}
            </pre>
          )}
        </div>
      )}
    </>
  );
}
