// app/(marketing)/cases/[id]/page.tsx
import { Card } from "@/components/ui/card";

interface Props {
  params: { id: string };
}

// 導入事例詳細ページ
export default function CaseDetailPage({ params }: Props) {
  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <Card>
        <h1 className="mb-4 text-2xl font-semibold">
          導入事例 #{params.id}
        </h1>
        <p className="text-sm text-gray-700">
          ここに事例の詳細情報を記載します。（MVPでは静的で可）
        </p>
      </Card>
    </div>
  );
}
