// app/(marketing)/cases/page.tsx
import { Card } from "@/components/ui/card";

// 導入事例一覧ページ
export default function CasesPage() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <Card>
        <h1 className="mb-4 text-2xl font-semibold">導入事例</h1>
        <p className="text-sm text-gray-700">
          ここに成功事例の一覧を掲載します。（MVPでは静的なダミーで可）
        </p>
      </Card>
    </div>
  );
}
