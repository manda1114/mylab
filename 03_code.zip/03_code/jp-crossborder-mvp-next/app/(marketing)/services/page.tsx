// app/(marketing)/services/page.tsx
import { Card } from "@/components/ui/card";

// サービス紹介ページ
export default function ServicesPage() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <Card>
        <h1 className="mb-4 text-2xl font-semibold">サービス内容</h1>
        <ul className="space-y-2 text-sm text-gray-700">
          <li>・中日連携の選品サポート</li>
          <li>・ショップ/独立サイト構築</li>
          <li>・AI翻訳/AI選品/AIレポート</li>
          <li>・税務/清関/知財などの合規サポート（提携専門家）</li>
        </ul>
      </Card>
    </div>
  );
}
