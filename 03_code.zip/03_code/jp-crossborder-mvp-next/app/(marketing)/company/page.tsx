// app/(marketing)/company/page.tsx
import { Card } from "@/components/ui/card";

// 会社情報ページ
export default function CompanyPage() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <Card>
        <h1 className="mb-4 text-2xl font-semibold">会社情報</h1>
        <p className="text-sm text-gray-700">
          ここに会社概要、沿革、ミッションなどを記載します。（ダミーテキスト）
        </p>
      </Card>
    </div>
  );
}
