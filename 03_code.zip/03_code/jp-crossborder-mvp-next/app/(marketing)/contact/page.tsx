// app/(marketing)/contact/page.tsx
"use client";

import { FormEvent, useState } from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";

// お問い合わせページ
export default function ContactPage() {
  const [status, setStatus] = useState<"idle" | "sending" | "done" | "error">(
    "idle"
  );

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const data = {
      name: (form.elements.namedItem("name") as HTMLInputElement).value,
      email: (form.elements.namedItem("email") as HTMLInputElement).value,
      subject: (form.elements.namedItem("subject") as HTMLInputElement).value,
      message: (form.elements.namedItem("message") as HTMLTextAreaElement)
        .value
    };
    setStatus("sending");
    const res = await fetch("/api/contact", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });
    if (res.ok) setStatus("done");
    else setStatus("error");
  };

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <h1 className="mb-4 text-2xl font-semibold">お問い合わせ</h1>
      <form onSubmit={handleSubmit} className="max-w-md space-y-3 text-sm">
        <div>
          <label className="mb-1 block text-xs text-gray-700">お名前</label>
          <Input name="name" required placeholder="山田 太郎" />
        </div>
        <div>
          <label className="mb-1 block text-xs text-gray-700">
            メールアドレス
          </label>
          <Input
            name="email"
            type="email"
            required
            placeholder="example@example.com"
          />
        </div>
        <div>
          <label className="mb-1 block text-xs text-gray-700">件名</label>
          <Input name="subject" placeholder="件名" />
        </div>
        <div>
          <label className="mb-1 block text-xs text-gray-700">
            お問い合わせ内容
          </label>
          <Textarea
            name="message"
            rows={4}
            required
            placeholder="お問い合わせ内容をご入力ください。"
          />
        </div>
        <Button
          type="submit"
          variant="primary"
          disabled={status === "sending"}
        >
          {status === "sending" ? "送信中..." : "送信"}
        </Button>
        {status === "done" && (
          <p className="text-xs text-green-600">
            送信しました。ありがとうございます。
          </p>
        )}
        {status === "error" && (
          <p className="text-xs text-red-600">
            エラーが発生しました。しばらくしてから再度お試しください。
          </p>
        )}
      </form>
    </div>
  );
}
