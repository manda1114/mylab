// app/(marketing)/layout.tsx
import type { ReactNode } from "react";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";

// マーケティング用レイアウト（共通ヘッダー／フッター）
export default function MarketingLayout({
  children
}: {
  children: ReactNode;
}) {
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">{children}</main>
      <Footer />
    </div>
  );
}
