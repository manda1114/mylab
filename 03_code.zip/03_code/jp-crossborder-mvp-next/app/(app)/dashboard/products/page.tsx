// app/(app)/dashboard/products/page.tsx
"use client";

import useSWR from "swr";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableHeaderCell,
  TableCell
} from "@/components/ui/table";

// API レスポンス取得用フェッチャー
const fetcher = (url: string) => fetch(url).then((r) => r.json());

// 商品一覧ページ
export default function ProductsPage() {
  const { data, isLoading, mutate } = useSWR("/api/products", fetcher);

  const handleRefresh = () => {
    mutate();
  };

  return (
    <div>
      <h1 className="mb-4 text-2xl font-semibold">商品管理</h1>

      <Card>
        <div className="mb-3 flex items-center justify-between">
          <div className="text-sm text-gray-700">
            登録済みの商品一覧を表示します。
          </div>
          <div className="flex items-center gap-2">
            {/* 将来的に新規作成ページへの遷移ボタンを追加 */}
            {/* <Button variant="primary">新規商品</Button> */}
            <Button variant="outline" onClick={handleRefresh}>
              更新
            </Button>
          </div>
        </div>

        {isLoading && <p className="text-sm">読み込み中...</p>}

        {!isLoading && (!data?.items || data.items.length === 0) && (
          <p className="text-sm text-gray-600">
            まだ商品が登録されていません。
          </p>
        )}

        {data?.items && data.items.length > 0 && (
          <div className="overflow-x-auto">
            <Table>
              <TableHead>
                <TableRow>
                  <TableHeaderCell className="pl-2">ID</TableHeaderCell>
                  <TableHeaderCell>SKU</TableHeaderCell>
                  <TableHeaderCell>価格</TableHeaderCell>
                  <TableHeaderCell>在庫</TableHeaderCell>
                  <TableHeaderCell>公開</TableHeaderCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {data.items.map((p: any) => (
                  <TableRow key={p.id}>
                    <TableCell className="pl-2">
                      {p.id.slice(0, 6)}
                    </TableCell>
                    <TableCell>{p.sku}</TableCell>
                    <TableCell>
                      {p.price} {p.currency}
                    </TableCell>
                    <TableCell>{p.stock}</TableCell>
                    <TableCell>
                      {p.isPublished ? "はい" : "いいえ"}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </Card>
    </div>
  );
}
