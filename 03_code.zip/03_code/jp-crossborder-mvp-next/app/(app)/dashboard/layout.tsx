// app/(app)/dashboard/layout.tsx
import Link from "next/link";
import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authConfig } from "@/lib/auth";
import AiAssistant from "@/components/ai-assistant";

export default async function DashboardLayout({
  children
}: {
  children: React.ReactNode;
}) {
  const session = await getServerSession(authConfig);
  if (!session) redirect("/auth/login");

  return (
    <div className="flex min-h-screen">
      <aside className="w-56 border-r bg-white">
        <div className="p-4 font-bold">マイショップ</div>
        <nav className="space-y-1 px-4 text-sm">
          <Link href="/dashboard">ダッシュボード</Link>
          <Link href="/dashboard/products">商品管理</Link>
          <Link href="/dashboard/orders">注文管理</Link>
          <Link href="/dashboard/finance">売上・財務</Link>
          <Link href="/dashboard/profile">プロフィール</Link>
        </nav>
      </aside>
      <main className="relative flex-1 bg-gray-50 p-6">
        {children}
        <AiAssistant />
      </main>
    </div>
  );
}
