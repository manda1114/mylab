// app/(app)/dashboard/page.tsx
"use client";

import useSWR from "swr";
import Link from "next/link";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

// API レスポンス取得用フェッチャー
const fetcher = (url: string) => fetch(url).then((r) => r.json());

export default function DashboardHome() {
  const { data: finance, isLoading: financeLoading } = useSWR(
    "/api/finance/summary",
    fetcher
  );
  const { data: orders, isLoading: ordersLoading } = useSWR(
    "/api/orders",
    fetcher
  );
  const { data: products, isLoading: productsLoading } = useSWR(
    "/api/products",
    fetcher
  );

  const orderCount = orders?.items?.length ?? 0;
  const productCount = products?.items?.length ?? 0;
  const totalSales = finance?.total ?? 0;
  const completedSales = finance?.completed ?? 0;

  return (
    <div>
      <h1 className="mb-4 text-2xl font-semibold">ダッシュボード</h1>

      {/* KPI カード行 */}
      <div className="mb-6 grid gap-4 md:grid-cols-3">
        <Card>
          <div className="text-xs text-gray-500">総売上（全期間）</div>
          <div className="mt-2 text-xl font-semibold">
            {financeLoading
              ? "..."
              : `${(totalSales as number)?.toLocaleString("ja-JP")} JPY`}
          </div>
          <div className="mt-1 text-xs text-gray-500">
            完了・入金済み：
            {financeLoading
              ? "..."
              : `${(completedSales as number)?.toLocaleString("ja-JP")} JPY`}
          </div>
          <div className="mt-3">
            <Link href="/dashboard/finance">
              <Button variant="outline" className="text-xs">
                詳細を見る
              </Button>
            </Link>
          </div>
        </Card>

        <Card>
          <div className="text-xs text-gray-500">注文数（全期間）</div>
          <div className="mt-2 text-xl font-semibold">
            {ordersLoading ? "..." : `${orderCount} 件`}
          </div>
          <div className="mt-1 text-xs text-gray-500">
            新着注文は「注文管理」画面で確認できます。
          </div>
          <div className="mt-3">
            <Link href="/dashboard/orders">
              <Button variant="outline" className="text-xs">
                注文管理へ
              </Button>
            </Link>
          </div>
        </Card>

        <Card>
          <div className="text-xs text-gray-500">登録商品数</div>
          <div className="mt-2 text-xl font-semibold">
            {productsLoading ? "..." : `${productCount} 件`}
          </div>
          <div className="mt-1 text-xs text-gray-500">
            商品の追加・編集は「商品管理」画面から行います。
          </div>
          <div className="mt-3">
            <Link href="/dashboard/products">
              <Button variant="outline" className="text-xs">
                商品管理へ
              </Button>
            </Link>
          </div>
        </Card>
      </div>

      {/* 補足情報カード */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <h2 className="mb-2 text-sm font-semibold">次のステップ</h2>
          <ul className="list-disc space-y-1 pl-5 text-xs text-gray-700">
            <li>商品を登録し、「公開」ステータスに設定する。</li>
            <li>/shop/[shopId] のショップページにアクセスして表示を確認する。</li>
            <li>AI アシスタントで商品説明の翻訳やアイデア出しを行う。</li>
          </ul>
        </Card>

        <Card>
          <h2 className="mb-2 text-sm font-semibold">クイックリンク</h2>
          <div className="flex flex-wrap gap-2 text-xs">
            <Link href="/dashboard/products">
              <Button variant="outline">商品管理</Button>
            </Link>
            <Link href="/dashboard/orders">
              <Button variant="outline">注文管理</Button>
            </Link>
            <Link href="/dashboard/finance">
              <Button variant="outline">売上・財務</Button>
            </Link>
            <Link href="/dashboard/profile">
              <Button variant="outline">プロフィール</Button>
            </Link>
          </div>
        </Card>
      </div>
    </div>
  );
}
