// app/(app)/dashboard/profile/page.tsx
"use client";

import { FormEvent, useEffect, useState } from "react";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Button } from "@/components/ui/button";

// プロフィール設定ページ
export default function ProfilePage() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [locale, setLocale] = useState("ja");
  const [message, setMessage] = useState("");

  useEffect(() => {
    const load = async () => {
      const res = await fetch("/api/profile");
      if (res.ok) {
        const data = await res.json();
        setEmail(data.email);
        setName(data.name);
        setLocale(data.locale || "ja");
      }
      setLoading(false);
    };
    load();
  }, []);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setMessage("");

    const res = await fetch("/api/profile", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, locale })
    });

    if (res.ok) {
      setMessage("更新しました。");
    } else {
      setMessage("更新に失敗しました。");
    }
    setSaving(false);
  };

  if (loading) return <p>読み込み中...</p>;

  return (
    <div>
      <h1 className="mb-4 text-2xl font-semibold">プロフィール</h1>
      <form onSubmit={onSubmit} className="max-w-md space-y-3 text-sm">
        <div>
          <label className="mb-1 block text-xs text-gray-600">
            メールアドレス
          </label>
          <Input type="email" value={email} disabled className="bg-gray-100" />
        </div>
        <div>
          <label className="mb-1 block text-xs text-gray-600">お名前</label>
          <Input
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </div>
        <div>
          <label className="mb-1 block text-xs text-gray-600">
            表示言語
          </label>
          <Select
            value={locale}
            onChange={(e) => setLocale(e.target.value)}
          >
            <option value="ja">日本語</option>
            <option value="en">English</option>
            <option value="zh-CN">简体中文</option>
          </Select>
        </div>
        <Button
          type="submit"
          variant="primary"
          disabled={saving}
        >
          {saving ? "保存中..." : "保存"}
        </Button>
        {message && (
          <p className="text-xs text-gray-700">{message}</p>
        )}
      </form>
    </div>
  );
}
