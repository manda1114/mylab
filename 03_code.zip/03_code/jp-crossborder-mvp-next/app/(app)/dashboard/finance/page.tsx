// app/(app)/dashboard/finance/page.tsx
"use client";

import { useState } from "react";
import useSWR from "swr";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

// 売上・財務サマリーページ
const fetcher = (url: string) => fetch(url).then((r) => r.json());

export default function FinancePage() {
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [url, setUrl] = useState("/api/finance/summary");

  const { data, isLoading } = useSWR(url, fetcher);

  const applyFilter = () => {
    const params = new URLSearchParams();
    if (from) params.set("from", from);
    if (to) params.set("to", to);
    const q = params.toString();
    setUrl(`/api/finance/summary${q ? `?${q}` : ""}`);
  };

  return (
    <div>
      <h1 className="mb-4 text-2xl font-semibold">売上・財務</h1>

      <div className="mb-4 flex items-end gap-2 text-sm">
        <div>
          <label className="mb-1 block text-xs text-gray-600">開始日</label>
          <Input
            type="date"
            value={from}
            onChange={(e) => setFrom(e.target.value)}
            className="w-auto"
          />
        </div>
        <div>
          <label className="mb-1 block text-xs text-gray-600">終了日</label>
          <Input
            type="date"
            value={to}
            onChange={(e) => setTo(e.target.value)}
            className="w-auto"
          />
        </div>
        <Button
          type="button"
          variant="primary"
          onClick={applyFilter}
        >
          集計
        </Button>
      </div>

      {isLoading && <p>集計中...</p>}

      {data && (
        <div className="space-y-2 text-sm">
          <p>
            対象期間の注文数：{" "}
            <span className="font-semibold">{data.count}</span> 件
          </p>
          <p>
            総売上（全ステータス）：{" "}
            <span className="font-semibold">
              {data.total?.toLocaleString?.("ja-JP") ?? data.total} JPY
            </span>
          </p>
          <p>
            完了・入金済み売上：{" "}
            <span className="font-semibold">
              {data.completed?.toLocaleString?.("ja-JP") ??
                data.completed}{" "}
              JPY
            </span>
          </p>
        </div>
      )}
    </div>
  );
}
