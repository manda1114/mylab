// app/(app)/dashboard/orders/page.tsx
"use client";

import useSWR from "swr";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableHeaderCell,
  TableCell
} from "@/components/ui/table";

// API レスポンス取得用フェッチャー
const fetcher = (url: string) => fetch(url).then((r) => r.json());

const STATUS_OPTIONS = [
  "pending",
  "paid",
  "shipped",
  "completed",
  "canceled"
];

// 注文一覧ページ
export default function OrdersPage() {
  const { data, isLoading, mutate } = useSWR("/api/orders", fetcher);

  const handleStatusChange = async (id: string, status: string) => {
    await fetch(`/api/orders/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status })
    });
    mutate();
  };

  const handleRefresh = () => {
    mutate();
  };

  return (
    <div>
      <h1 className="mb-4 text-2xl font-semibold">注文管理</h1>

      <Card>
        <div className="mb-3 flex items-center justify-between">
          <div className="text-sm text-gray-700">
            受注した注文の一覧とステータスを管理します。
          </div>
          <Button variant="outline" onClick={handleRefresh}>
            更新
          </Button>
        </div>

        {isLoading && <p className="text-sm">読み込み中...</p>}

        {!isLoading && (!data?.items || data.items.length === 0) && (
          <p className="text-sm text-gray-600">注文はまだありません。</p>
        )}

        {data?.items && data.items.length > 0 && (
          <div className="overflow-x-auto">
            <Table>
              <TableHead>
                <TableRow>
                  <TableHeaderCell className="pl-2">
                    注文ID
                  </TableHeaderCell>
                  <TableHeaderCell>日時</TableHeaderCell>
                  <TableHeaderCell>購入者</TableHeaderCell>
                  <TableHeaderCell>金額</TableHeaderCell>
                  <TableHeaderCell>ステータス</TableHeaderCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {data.items.map((o: any) => (
                  <TableRow key={o.id}>
                    <TableCell className="pl-2">
                      {o.id.slice(0, 8)}
                    </TableCell>
                    <TableCell>
                      {new Date(o.createdAt).toLocaleString("ja-JP")}
                    </TableCell>
                    <TableCell>{o.buyerName}</TableCell>
                    <TableCell>
                      {o.totalAmount} {o.currency}
                    </TableCell>
                    <TableCell>
                      <select
                        className="rounded border px-1 py-0.5 text-xs"
                        value={o.status}
                        onChange={(e) =>
                          handleStatusChange(o.id, e.target.value)
                        }
                      >
                        {STATUS_OPTIONS.map((s) => (
                          <option key={s} value={s}>
                            {s}
                          </option>
                        ))}
                      </select>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </Card>
    </div>
  );
}
