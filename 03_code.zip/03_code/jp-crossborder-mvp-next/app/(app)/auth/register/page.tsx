// app/(app)/auth/register/page.tsx
"use client";

import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Button } from "@/components/ui/button";

// 新規登録ページ
export default function RegisterPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [locale, setLocale] = useState("ja");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError("");
    setSaving(true);

    const res = await fetch("/api/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password, name, locale })
    });

    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(data.error || "登録に失敗しました。");
      setSaving(false);
      return;
    }

    router.push("/auth/login");
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-50">
      <form
        onSubmit={onSubmit}
        className="w-full max-w-sm rounded bg-white p-6 shadow"
      >
        <h1 className="mb-4 text-xl font-semibold">新規登録</h1>

        <div className="mb-2 text-sm">
          <label className="mb-1 block text-xs text-gray-700">お名前</label>
          <Input
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>

        <div className="mb-2 text-sm">
          <label className="mb-1 block text-xs text-gray-700">
            メールアドレス
          </label>
          <Input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>

        <div className="mb-2 text-sm">
          <label className="mb-1 block text-xs text-gray-700">
            表示言語
          </label>
          <Select
            value={locale}
            onChange={(e) => setLocale(e.target.value)}
          >
            <option value="ja">日本語</option>
            <option value="en">English</option>
            <option value="zh-CN">简体中文</option>
          </Select>
        </div>

        <div className="mb-4 text-sm">
          <label className="mb-1 block text-xs text-gray-700">
            パスワード
          </label>
          <Input
            type="password"
            value={password}
            minLength={6}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>

        {error && (
          <p className="mb-2 text-xs text-red-600">{error}</p>
        )}

        <Button
          type="submit"
          variant="primary"
          className="mb-3 w-full"
          disabled={saving}
        >
          {saving ? "登録中..." : "登録する"}
        </Button>

        <p className="text-xs text-gray-600">
          すでにアカウントをお持ちの方は{" "}
          <Link href="/auth/login" className="text-blue-600">
            ログイン
          </Link>
        </p>
      </form>
    </div>
  );
}
