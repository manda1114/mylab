// app/(app)/auth/login/page.tsx
"use client";

import { FormEvent, useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

// ログインページ
export default function LoginPage() {
  const router = useRouter();
  const search = useSearchParams();
  const callbackUrl = search.get("callbackUrl") || "/dashboard";

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError("");

    const res = await signIn("credentials", {
      redirect: false,
      email,
      password,
      callbackUrl
    });

    if (res?.error) {
      setError("メールアドレスまたはパスワードが正しくありません。");
      return;
    }

    router.push(callbackUrl);
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-50">
      <form
        onSubmit={onSubmit}
        className="w-full max-w-sm rounded bg-white p-6 shadow"
      >
        <h1 className="mb-4 text-xl font-semibold">ログイン</h1>

        <div className="mb-2 text-sm">
          <label className="mb-1 block text-xs text-gray-700">
            メールアドレス
          </label>
          <Input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>

        <div className="mb-4 text-sm">
          <label className="mb-1 block text-xs text-gray-700">
            パスワード
          </label>
          <Input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>

        {error && (
          <p className="mb-2 text-xs text-red-600">{error}</p>
        )}

        <Button type="submit" variant="primary" className="mb-3 w-full">
          ログイン
        </Button>

        <p className="text-xs text-gray-600">
          アカウントをお持ちでない方は{" "}
          <Link href="/auth/register" className="text-blue-600">
            新規登録
          </Link>
        </p>
      </form>
    </div>
  );
}
