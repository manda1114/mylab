// app/(app)/shop/[shopId]/page.tsx
import { notFound } from "next/navigation";
import Image from "next/image";
import { prisma } from "@/lib/prisma";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface Props {
  params: { shopId: string };
}

// 店舗トップページ（公開商品一覧）
export default async function ShopPage({ params }: Props) {
  const shop = await prisma.shop.findUnique({
    where: { id: params.shopId }
  });

  if (!shop) {
    notFound();
  }

  // 本番ではブラウザ言語やユーザー設定に応じて変更する想定
  const preferredLocale = shop.defaultLocale || "ja";

  const products = await prisma.product.findMany({
    where: {
      shopId: shop.id,
      isPublished: true
    },
    include: {
      translations: true
    },
    orderBy: { createdAt: "desc" }
  });

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <div className="mb-6">
        <h1 className="mb-1 text-2xl font-semibold">
          {shop.name}
        </h1>
        {shop.description && (
          <p className="text-sm text-gray-700">{shop.description}</p>
        )}
      </div>

      {products.length === 0 && (
        <p className="text-sm text-gray-600">
          現在、公開中の商品はありません。
        </p>
      )}

      {products.length > 0 && (
        <div className="grid gap-4 md:grid-cols-3">
          {products.map((p) => {
            const t =
              p.translations.find(
                (tr) => tr.locale === preferredLocale
              ) || p.translations[0];

            return (
              <Card key={p.id} className="flex flex-col">
                {p.imageUrl && (
                  <div className="relative mb-2 h-40 w-full overflow-hidden rounded">
                    <Image
                      src={p.imageUrl}
                      alt={t?.name ?? ""}
                      fill
                      className="object-cover"
                    />
                  </div>
                )}
                <div className="flex flex-1 flex-col">
                  <div className="mb-1 text-sm font-semibold">
                    {t?.name ?? "商品名未設定"}
                  </div>
                  <div className="mb-2 line-clamp-3 text-xs text-gray-600">
                    {t?.description}
                  </div>
                  <div className="mt-auto flex items-center justify-between pt-2 text-sm">
                    <span className="font-semibold">
                      {p.price.toString()} {p.currency}
                    </span>
                    <a href={`/shop/${shop.id}/product/${p.id}`}>
                      <Button variant="outline" className="text-xs">
                        詳細を見る
                      </Button>
                    </a>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
