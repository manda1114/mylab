// app/(app)/shop/[shopId]/product/[productId]/page.tsx
import { notFound } from "next/navigation";
import Image from "next/image";
import { prisma } from "@/lib/prisma";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TestOrderButton } from "./TestOrderButton";

interface Props {
  params: { shopId: string; productId: string };
}

// 商品詳細ページ（公開ビュー）
export default async function ProductDetailPage({ params }: Props) {
  const shop = await prisma.shop.findUnique({
    where: { id: params.shopId }
  });
  if (!shop) notFound();

  const product = await prisma.product.findFirst({
    where: {
      id: params.productId,
      shopId: shop.id,
      isPublished: true
    },
    include: {
      translations: true
    }
  });

  if (!product) {
    notFound();
  }

  const preferredLocale = shop.defaultLocale || "ja";
  const t =
    product.translations.find(
      (tr) => tr.locale === preferredLocale
    ) || product.translations[0];

  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      <Card className="grid gap-6 md:grid-cols-2">
        <div>
          {product.imageUrl ? (
            <div className="relative h-64 w-full overflow-hidden rounded">
              <Image
                src={product.imageUrl}
                alt={t?.name ?? ""}
                fill
                className="object-cover"
              />
            </div>
          ) : (
            <div className="flex h-64 items-center justify-center rounded bg-gray-100 text-xs text-gray-500">
              画像なし
            </div>
          )}
        </div>

        <div className="flex flex-col">
          <h1 className="mb-2 text-xl font-semibold">
            {t?.name ?? "商品名未設定"}
          </h1>
          <p className="mb-3 text-sm text-gray-700">
            {t?.description}
          </p>
          <div className="mb-2 text-lg font-semibold">
            {product.price.toString()} {product.currency}
          </div>
          <div className="mb-2 text-xs text-gray-600">
            在庫：{product.stock} 個
          </div>

          <div className="mt-4 space-y-2 text-xs text-gray-600">
            <p>
              ※ 本バージョンでは閲覧とテスト注文のみ可能です。実際の決済フローは今後のバージョンで追加予定です。
            </p>
          </div>

          {/* テスト注文ボタン（ログイン中の出店者向け） */}
          <TestOrderButton productId={product.id} />

          <div className="mt-6 flex gap-2">
            <a href={`/shop/${shop.id}`}>
              <Button variant="outline" className="text-xs">
                店舗トップに戻る
              </Button>
            </a>
          </div>
        </div>
      </Card>
    </div>
  );
}
