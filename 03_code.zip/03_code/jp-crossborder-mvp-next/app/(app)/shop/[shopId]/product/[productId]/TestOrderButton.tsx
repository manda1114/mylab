// app/(app)/shop/[shopId]/product/[productId]/TestOrderButton.tsx
"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";

interface Props {
  productId: string;
}

// テスト注文作成ボタン（ログイン中の出店者向け）
export function TestOrderButton({ productId }: Props) {
  const [status, setStatus] = useState<"idle" | "loading" | "done" | "error">(
    "idle"
  );

  const handleClick = async () => {
    setStatus("loading");

    // テスト用のダミー購入者情報と数量
    const body = {
      buyerName: "テスト購入者",
      buyerEmail: "test@example.com",
      items: [
        {
          productId,
          quantity: 1
        }
      ]
    };

    const res = await fetch("/api/orders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });

    if (res.ok) {
      setStatus("done");
    } else {
      setStatus("error");
    }
  };

  return (
    <div className="mt-4 space-y-1 text-xs">
      <Button
        type="button"
        variant="primary"
        disabled={status === "loading"}
        onClick={handleClick}
      >
        {status === "loading" ? "作成中..." : "テスト注文を作成"}
      </Button>
      {status === "done" && (
        <p className="text-green-600">テスト注文を作成しました。</p>
      )}
      {status === "error" && (
        <p className="text-red-600">
          テスト注文の作成に失敗しました。（ログイン状態などを確認してください）
        </p>
      )}
    </div>
  );
}
