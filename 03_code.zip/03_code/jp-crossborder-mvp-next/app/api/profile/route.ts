// app/api/profile/route.ts
import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authConfig } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

// ログインユーザーのプロフィール取得
export async function GET(req: NextRequest) {
  const session = await getServerSession(authConfig);
  if (!session) return new NextResponse("Unauthorized", { status: 401 });

  const userId = (session.user as any).id as string;
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { id: true, email: true, name: true, locale: true }
  });

  return NextResponse.json(user);
}

// ログインユーザーのプロフィール更新
export async function PUT(req: NextRequest) {
  const session = await getServerSession(authConfig);
  if (!session) return new NextResponse("Unauthorized", { status: 401 });

  const userId = (session.user as any).id as string;
  const { name, locale } = await req.json();

  const user = await prisma.user.update({
    where: { id: userId },
    data: {
      name,
      locale
    },
    select: { id: true, email: true, name: true, locale: true }
  });

  return NextResponse.json(user);
}
