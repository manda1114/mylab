// app/api/auth/[...nextauth]/route.ts
import { NextResponse } from "next/server";

// 一時的なダミー認証エンドポイント（本番用ではない）

export function GET() {
  return NextResponse.json(
    { error: "Auth is disabled in this build." },
    { status: 501 }
  );
}

export function POST() {
  return NextResponse.json(
    { error: "Auth is disabled in this build." },
    { status: 501 }
  );
}
