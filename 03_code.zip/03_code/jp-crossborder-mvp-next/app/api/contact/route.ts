// app/api/contact/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function POST(req: NextRequest) {
  const { name, email, subject, message } = await req.json();

  if (!name || !email || !message) {
    return NextResponse.json({ error: "Missing fields" }, { status: 400 });
  }

  await prisma.contactMessage.create({
    data: {
      name,
      email,
      subject,
      message
    }
  });

  return NextResponse.json({ success: true });
}
