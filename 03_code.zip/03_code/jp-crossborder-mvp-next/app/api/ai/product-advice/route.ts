// app/api/ai/product-advice/route.ts
import { NextRequest, NextResponse } from "next/server";
import OpenAI from "openai";
import { getServerSession } from "next-auth";
import { authConfig } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

export async function POST(req: NextRequest) {
  const session = await getServerSession(authConfig);
  if (!session) {
    return new NextResponse("Unauthorized", { status: 401 });
  }

  const { category, targetMarket, priceRange, description } =
    await req.json();

  const prompt = `
You are an expert in Japan cross-border e-commerce.

User's current plan:

- Category: ${category}
- Target market: ${targetMarket}
- Price range: ${priceRange}
- Description: ${description}

Please:
1) Suggest 3~5 concrete product directions suitable for Japanese market.
2) Explain briefly why.
3) Provide example Japanese product titles for 2 of them.
Please answer in Japanese.
`;

  const completion = await client.chat.completions.create({
    model: "gpt-4.1-mini",
    messages: [{ role: "user", content: prompt }]
  });

  const content =
    completion.choices[0]?.message?.content?.trim() || "";

  const userId = (session.user as any).id as string;
  await prisma.aiLog.create({
    data: {
      userId,
      type: "product-advice",
      request: JSON.stringify({ category, targetMarket })
    }
  });

  return NextResponse.json({
    suggestions: [],
    tips: content
  });
}
