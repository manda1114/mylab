// app/api/ai/translate/route.ts
import { NextRequest, NextResponse } from "next/server";
import OpenAI from "openai";
import { getServerSession } from "next-auth";
import { authConfig } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

export async function POST(req: NextRequest) {
  const session = await getServerSession(authConfig);
  if (!session) {
    return new NextResponse("Unauthorized", { status: 401 });
  }

  const { text, targetLang } = await req.json();
  if (!text || !targetLang) {
    return NextResponse.json(
      { error: "Missing text or targetLang" },
      { status: 400 }
    );
  }

  const prompt = `Translate the following text into ${targetLang}. Keep meaning and style.

Text:
${text}
`;

  const completion = await client.chat.completions.create({
    model: "gpt-4.1-mini",
    messages: [{ role: "user", content: prompt }]
  });

  const translated =
    completion.choices[0]?.message?.content?.trim() || "";

  const userId = (session.user as any).id as string;
  await prisma.aiLog.create({
    data: {
      userId,
      type: "translate",
      request: text
    }
  });

  return NextResponse.json({ translatedText: translated });
}
