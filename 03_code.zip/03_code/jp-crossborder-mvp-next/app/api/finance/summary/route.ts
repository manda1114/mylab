// app/api/finance/summary/route.ts
import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authConfig } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

// 売上集計 API（シンプル版）
export async function GET(req: NextRequest) {
  const session = await getServerSession(authConfig);
  if (!session) return new NextResponse("Unauthorized", { status: 401 });

  const userId = (session.user as any).id as string;
  const shop = await prisma.shop.findUnique({ where: { ownerId: userId } });
  if (!shop) return NextResponse.json({ total: 0, completed: 0, count: 0 });

  const url = new URL(req.url);
  const from = url.searchParams.get("from");
  const to = url.searchParams.get("to");

  const where: any = { shopId: shop.id };
  if (from || to) {
    where.createdAt = {};
    if (from) where.createdAt.gte = new Date(from);
    if (to) where.createdAt.lte = new Date(to);
  }

  const orders = await prisma.order.findMany({ where });

  const total = orders.reduce((sum, o) => sum + Number(o.totalAmount), 0);
  const completed = orders
    .filter((o) => o.status === "completed" || o.status === "paid")
    .reduce((sum, o) => sum + Number(o.totalAmount), 0);

  return NextResponse.json({
    total,
    completed,
    count: orders.length
  });
}
