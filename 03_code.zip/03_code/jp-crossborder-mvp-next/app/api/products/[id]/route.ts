// app/api/products/[id]/route.ts
import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authConfig } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

interface Params {
  params: { id: string };
}

// GET /api/products/[id]
// 単一商品の取得
export async function GET(req: NextRequest, { params }: Params) {
  const session = await getServerSession(authConfig);
  if (!session) return new NextResponse("Unauthorized", { status: 401 });

  const userId = (session.user as any).id as string;
  const shop = await prisma.shop.findUnique({ where: { ownerId: userId } });
  if (!shop) return new NextResponse("Not found", { status: 404 });

  const product = await prisma.product.findFirst({
    where: { id: params.id, shopId: shop.id },
    include: { translations: true }
  });

  if (!product) return new NextResponse("Not found", { status: 404 });

  return NextResponse.json(product);
}

// PUT /api/products/[id]
// 単一商品の更新
export async function PUT(req: NextRequest, { params }: Params) {
  const session = await getServerSession(authConfig);
  if (!session) return new NextResponse("Unauthorized", { status: 401 });

  const userId = (session.user as any).id as string;
  const shop = await prisma.shop.findUnique({ where: { ownerId: userId } });
  if (!shop) return new NextResponse("Forbidden", { status: 403 });

  const body = await req.json();
  const {
    sku,
    price,
    currency,
    stock,
    salesRegions,
    paymentMethods,
    isPublished,
    imageUrl,
    translations
  } = body;

  // 該当商品がログイン中ユーザーの店舗に属しているか確認
  const existing = await prisma.product.findFirst({
    where: { id: params.id, shopId: shop.id }
  });
  if (!existing) return new NextResponse("Not found", { status: 404 });

  const product = await prisma.product.update({
    where: { id: params.id },
    data: {
      sku,
      price,
      currency,
      stock,
      salesRegions,
      paymentMethods,
      isPublished,
      imageUrl,
      // シンプルのため、一度翻訳レコードを削除してから再作成
      translations: translations
        ? {
            deleteMany: {},
            create: translations
          }
        : undefined
    },
    include: { translations: true }
  });

  return NextResponse.json(product);
}

// DELETE /api/products/[id]
// シンプルに物理削除（必要であれば論理削除に変更）
export async function DELETE(req: NextRequest, { params }: Params) {
  const session = await getServerSession(authConfig);
  if (!session) return new NextResponse("Unauthorized", { status: 401 });

  const userId = (session.user as any).id as string;
  const shop = await prisma.shop.findUnique({ where: { ownerId: userId } });
  if (!shop) return new NextResponse("Forbidden", { status: 403 });

  const existing = await prisma.product.findFirst({
    where: { id: params.id, shopId: shop.id }
  });
  if (!existing) return new NextResponse("Not found", { status: 404 });

  await prisma.product.delete({ where: { id: params.id } });

  return new NextResponse(null, { status: 204 });
}
