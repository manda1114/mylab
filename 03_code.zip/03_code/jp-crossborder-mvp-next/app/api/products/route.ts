// app/api/products/route.ts
import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authConfig } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET(req: NextRequest) {
  const session = await getServerSession(authConfig);
  if (!session) return new NextResponse("Unauthorized", { status: 401 });

  const userId = (session.user as any).id as string;
  const shop = await prisma.shop.findUnique({ where: { ownerId: userId } });
  if (!shop) return NextResponse.json({ items: [] });

  const products = await prisma.product.findMany({
    where: { shopId: shop.id },
    include: {
      translations: true
    },
    orderBy: { createdAt: "desc" }
  });

  return NextResponse.json({ items: products });
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authConfig);
  if (!session) return new NextResponse("Unauthorized", { status: 401 });

  const userId = (session.user as any).id as string;
  let shop = await prisma.shop.findUnique({ where: { ownerId: userId } });
  if (!shop) {
    shop = await prisma.shop.create({
      data: {
        ownerId: userId,
        name: "My Shop",
        description: "",
        defaultLocale: "ja"
      }
    });
  }

  const body = await req.json();
  const {
    sku,
    price,
    currency,
    stock,
    salesRegions,
    paymentMethods,
    isPublished,
    imageUrl,
    translations
  } = body;

  const product = await prisma.product.create({
    data: {
      shopId: shop.id,
      sku,
      price,
      currency,
      stock,
      salesRegions,
      paymentMethods,
      isPublished,
      imageUrl,
      translations: {
        create: translations || []
      }
    },
    include: { translations: true }
  });

  return NextResponse.json(product, { status: 201 });
}
