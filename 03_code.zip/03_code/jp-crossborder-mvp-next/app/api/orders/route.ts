// app/api/orders/route.ts
import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authConfig } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

// GET /api/orders
// 注文一覧取得
export async function GET(req: NextRequest) {
  const session = await getServerSession(authConfig);
  if (!session) return new NextResponse("Unauthorized", { status: 401 });

  const userId = (session.user as any).id as string;
  const shop = await prisma.shop.findUnique({ where: { ownerId: userId } });
  if (!shop) return NextResponse.json({ items: [] });

  const orders = await prisma.order.findMany({
    where: { shopId: shop.id },
    include: { items: true },
    orderBy: { createdAt: "desc" }
  });

  return NextResponse.json({ items: orders });
}

// POST /api/orders
// MVP 用の簡易注文作成エンドポイント
export async function POST(req: NextRequest) {
  const session = await getServerSession(authConfig);
  if (!session) return new NextResponse("Unauthorized", { status: 401 });

  const userId = (session.user as any).id as string;
  const shop = await prisma.shop.findUnique({ where: { ownerId: userId } });
  if (!shop) return new NextResponse("Forbidden", { status: 403 });

  const { buyerName, buyerEmail, items } = await req.json();

  if (!buyerName || !buyerEmail || !Array.isArray(items) || !items.length) {
    return NextResponse.json(
      { error: "Invalid order data" },
      { status: 400 }
    );
  }

  // 金額を簡易計算
  let totalAmount = 0;
  const itemCreates = [];

  for (const it of items) {
    const product = await prisma.product.findFirst({
      where: { id: it.productId, shopId: shop.id }
    });
    if (!product) continue;
    const subtotal = Number(product.price) * it.quantity;
    totalAmount += subtotal;
    itemCreates.push({
      productId: product.id,
      quantity: it.quantity,
      unitPrice: product.price,
      subtotal
    });
  }

  const order = await prisma.order.create({
    data: {
      shopId: shop.id,
      buyerName,
      buyerEmail,
      totalAmount,
      currency: "JPY",
      status: "pending",
      items: { create: itemCreates }
    },
    include: { items: true }
  });

  return NextResponse.json(order, { status: 201 });
}
