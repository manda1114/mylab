// app/api/orders/[id]/route.ts
import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authConfig } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

interface Params {
  params: { id: string };
}

// GET /api/orders/[id]
// 単一注文の詳細取得
export async function GET(req: NextRequest, { params }: Params) {
  const session = await getServerSession(authConfig);
  if (!session) return new NextResponse("Unauthorized", { status: 401 });

  const userId = (session.user as any).id as string;
  const shop = await prisma.shop.findUnique({ where: { ownerId: userId } });
  if (!shop) return new NextResponse("Not found", { status: 404 });

  const order = await prisma.order.findFirst({
    where: { id: params.id, shopId: shop.id },
    include: { items: { include: { product: true } } }
  });

  if (!order) return new NextResponse("Not found", { status: 404 });

  return NextResponse.json(order);
}

// PUT /api/orders/[id]
// 注文ステータス更新
export async function PUT(req: NextRequest, { params }: Params) {
  const session = await getServerSession(authConfig);
  if (!session) return new NextResponse("Unauthorized", { status: 401 });

  const userId = (session.user as any).id as string;
  const shop = await prisma.shop.findUnique({ where: { ownerId: userId } });
  if (!shop) return new NextResponse("Forbidden", { status: 403 });

  const { status } = await req.json();
  if (!status) {
    return NextResponse.json({ error: "Missing status" }, { status: 400 });
  }

  const existing = await prisma.order.findFirst({
    where: { id: params.id, shopId: shop.id }
  });
  if (!existing) return new NextResponse("Not found", { status: 404 });

  const order = await prisma.order.update({
    where: { id: params.id },
    data: { status }
  });

  return NextResponse.json(order);
}
