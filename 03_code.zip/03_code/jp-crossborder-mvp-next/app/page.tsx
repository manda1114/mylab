// app/page.tsx
"use client";

import React, { useState } from "react";
import dynamic from "next/dynamic";

type MainTab = "company" | "dashboard" | "shop";
type CompanyTab = "home" | "company" | "services" | "cases" | "contact";
type DashTab = "overview" | "profile" | "products" | "orders" | "finance";
type AiTab = "translate" | "product";
type Lang = "ja" | "en" | "zh-CN";

const caseData: Record<number, { title: string; content: string }> = {
  1: {
    title: "日系化粧品ブランド A 社",
    content:
      "北米向けの新規越境ECとして、企業サイト・販売者ダッシュボード・商品公開サイトを一括導入しました。初期フェーズでは MVP として閲覧と簡易管理のみを実装し、その後段階的に決済連携を追加しています。",
  },
  2: {
    title: "食品メーカー B 社",
    content:
      "アジア複数国向けに多言語商品ページを展開。product_translations テーブルで商品名・説明文を管理し、各販売エリアごとに価格・在庫・支払い方法を制御しています。",
  },
  3: {
    title: "D2C ブランド C 社",
    content:
      "スピーディーなローンチを目的に、/shop/[shopId] の商品公開ページから先に構築。将来的にサブスクリプション機能やロイヤリティプログラムと連携できる拡張性を確保しています。",
  },
};

function HomePageInner() {
  const [mainTab, setMainTab] = useState<MainTab>("company");
  const [companyTab, setCompanyTab] = useState<CompanyTab>("home");
  const [dashTab, setDashTab] = useState<DashTab>("overview");
  const [aiOpen, setAiOpen] = useState(false);
  const [aiTab, setAiTab] = useState<AiTab>("translate");
  const [lang, setLang] = useState<Lang>("ja");
  const [selectedCaseId, setSelectedCaseId] = useState<number | null>(null);

  const handleLangClick = (value: Lang) => {
    setLang(value);
    alert(
      "このデモは静的HTMLベースを Next.js に移植したものです。実案件では Next.js の i18n / next-intl などで多言語対応を実装してください。"
    );
  };

  const currentCase = selectedCaseId ? caseData[selectedCaseId] : null;

  return (
    <div>
      {/* 背景装飾レイヤー */}
      <div className="fixed inset-0 -z-10 overflow-hidden">
        <div className="absolute -top-40 -right-24 h-72 w-72 rounded-full bg-blue-500/20 blur-3xl" />
        <div className="absolute top-10 left-10 h-40 w-40 rounded-full bg-sky-400/25 blur-3xl" />
        <div className="absolute bottom-[-120px] right-[-80px] h-80 w-80 rounded-full bg-indigo-500/25 blur-3xl" />
      </div>

      {/* 外枠コンテナ（ガラスパネル） */}
      <div className="glass-panel min-h-screen max-w-6xl mx-auto my-4 sm:my-6 lg:my-10 rounded-3xl border border-white/12 px-3 sm:px-6 lg:px-8 pb-8 pt-3 sm:pt-4 text-slate-50">
        {/* ヘッダー */}
        <header className="flex items-center justify-between gap-4 border-b border-white/10 pb-3 sm:pb-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-500 to-sky-400 shadow-soft">
              <span className="text-xs font-semibold tracking-tight text-white">
                EC
              </span>
            </div>
            <div>
              <p className="text-xs uppercase tracking-[0.22em] text-slate-300">
                Cross-border Commerce
              </p>
              <h1 className="text-sm sm:text-base font-semibold tracking-tight text-slate-50">
                越境EC向けコマースプラットフォーム
              </h1>
            </div>
          </div>

          <nav className="flex flex-col items-end gap-3 sm:flex-row sm:items-center sm:gap-4 text-[13px] sm:text-sm">
            {/* メインタブ */}
            <div className="flex rounded-full bg-white/5 p-1 shadow-soft ring-1 ring-white/10">
              <button
                onClick={() => setMainTab("company")}
                className={
                  "main-tab inline-flex items-center rounded-full px-3.5 py-1.5 text-xs sm:text-[13px] transition-colors " +
                  (mainTab === "company"
                    ? "bg-white text-slate-900"
                    : "text-slate-300/80 hover:bg-white/5")
                }
              >
                企業サイト
              </button>
              <button
                onClick={() => setMainTab("dashboard")}
                className={
                  "main-tab inline-flex items-center rounded-full px-3.5 py-1.5 text-xs sm:text-[13px] transition-colors " +
                  (mainTab === "dashboard"
                    ? "bg-white text-slate-900"
                    : "text-slate-300/80 hover:bg-white/5")
                }
              >
                販売者ダッシュボード
              </button>
              <button
                onClick={() => setMainTab("shop")}
                className={
                  "main-tab inline-flex items-center rounded-full px-3.5 py-1.5 text-xs sm:text-[13px] transition-colors " +
                  (mainTab === "shop"
                    ? "bg-white text-slate-900"
                    : "text-slate-300/80 hover:bg-white/5")
                }
              >
                商品公開サイト
              </button>
            </div>

            {/* 表示言語切り替え（デモ用） */}
            <div className="flex items-center gap-2 rounded-full bg-white/5 px-2 py-1 text-[11px] sm:text-xs ring-1 ring-white/10">
              <span className="text-slate-300/90">表示言語</span>
              <button
                onClick={() => handleLangClick("ja")}
                className={
                  "lang-btn rounded-full px-2.5 py-0.5 text-[11px] " +
                  (lang === "ja"
                    ? "bg-gradient-to-r from-blue-600 to-sky-400 font-medium text-white shadow-soft"
                    : "text-slate-200 hover:bg-white/5")
                }
              >
                日本語
              </button>
              <button
                onClick={() => handleLangClick("en")}
                className={
                  "lang-btn rounded-full px-2.5 py-0.5 text-[11px] " +
                  (lang === "en"
                    ? "bg-gradient-to-r from-blue-600 to-sky-400 font-medium text-white shadow-soft"
                    : "text-slate-200 hover:bg-white/5")
                }
              >
                英語
              </button>
              <button
                onClick={() => handleLangClick("zh-CN")}
                className={
                  "lang-btn rounded-full px-2.5 py-0.5 text-[11px] " +
                  (lang === "zh-CN"
                    ? "bg-gradient-to-r from-blue-600 to-sky-400 font-medium text-white shadow-soft"
                    : "text-slate-200 hover:bg-white/5")
                }
              >
                中国語
              </button>
            </div>
          </nav>
        </header>

        <main className="mt-6 sm:mt-7 lg:mt-8 space-y-8 sm:space-y-10">
          {/* ============================= */}
          {/* 3.1 企業サイト */}
          {/* ============================= */}
          {mainTab === "company" && (
            <section id="company-section" className="fade-in space-y-4">
              {/* サブナビ */}
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2 text-xs text-slate-300/90">
                  <span className="inline-flex h-5 w-5 items-center justify-center rounded-full bg-white/10 text-[10px]">
                    P
                  </span>
                  <span>公開サイト（企業向け情報）</span>
                </div>
                <div className="flex flex-wrap gap-1.5 text-[12px] sm:text-xs bg-white/5 rounded-full p-1 ring-1 ring-white/10">
                  {(
                    [
                      ["home", "ホーム"],
                      ["company", "会社案内"],
                      ["services", "サービス"],
                      ["cases", "導入事例"],
                      ["contact", "お問い合わせ"],
                    ] as [CompanyTab, string][]
                  ).map(([key, label]) => (
                    <button
                      key={key}
                      onClick={() => setCompanyTab(key)}
                      className={
                        "company-tab rounded-full px-3 py-1 " +
                        (companyTab === key
                          ? "bg-white text-[12px] font-medium text-slate-900 shadow-soft"
                          : "text-slate-100 hover:bg-white/5")
                      }
                    >
                      {label}
                    </button>
                  ))}
                </div>
              </div>

              {/* ホーム */}
              {companyTab === "home" && (
                <div
                  id="company-home"
                  className="company-page space-y-6 sm:space-y-8 fade-up"
                >
                  <section className="glass-card border-gradient rounded-3xl p-6 sm:p-8 lg:p-10">
                    <div className="grid gap-8 lg:grid-cols-[minmax(0,1.3fr)_minmax(0,1fr)] items-center">
                      <div className="space-y-4 sm:space-y-5">
                        <p className="text-[11px] uppercase tracking-[0.28em] text-blue-700/90">
                          CROSS-BORDER PLATFORM
                        </p>
                        <h2 className="text-2xl sm:text-3xl lg:text-4xl font-semibold tracking-tight text-slate-900 leading-tight">
                          日本企業のための
                          <br className="hidden sm:block" />
                          越境ECマルチチャネル基盤
                        </h2>
                        <p className="text-[13px] sm:text-sm text-slate-600 leading-relaxed">
                          企業公式サイト、販売者向けダッシュボード、消費者向けの商品公開サイトを
                          ワンストップで提供します。日本企業に馴染みやすい UI
                          と、越境に必要な
                          多言語・多通貨機能を標準搭載しています。
                        </p>
                        <div className="flex flex-wrap gap-3 pt-1.5 sm:pt-2">
                          <a
                            href="#company-contact-form"
                            className="inline-flex items-center justify-center gap-2 rounded-full bg-gradient-to-r from-blue-600 via-blue-500 to-sky-400 px-4 sm:px-5 py-2.5 text-xs sm:text-sm font-medium text-white shadow-soft hover:brightness-110 transition"
                          >
                            無料相談・お問い合わせ
                            <span className="text-[11px] opacity-90">→</span>
                          </a>
                          <button className="inline-flex items-center justify-center gap-2 rounded-full bg-white px-4 sm:px-5 py-2.5 text-xs sm:text-sm font-medium text-slate-800 shadow-card hover:bg-slate-50 transition">
                            サービス資料（PDF）を見る
                          </button>
                        </div>

                        <dl className="mt-4 grid grid-cols-2 gap-4 text-[11px] sm:text-xs text-slate-600">
                          <div className="rounded-2xl bg-slate-50/80 p-3">
                            <dt className="text-[11px] font-semibold text-slate-700 mb-1">
                              対応言語
                            </dt>
                            <dd>日本語 / 英語 / 中国語（簡体字）</dd>
                          </div>
                          <div className="rounded-2xl bg-slate-50/80 p-3">
                            <dt className="text-[11px] font-semibold text-slate-700 mb-1">
                              決済通貨
                            </dt>
                            <dd>日本円（JPY）、米ドル（USD）など</dd>
                          </div>
                          <div className="rounded-2xl bg-slate-50/80 p-3">
                            <dt className="text-[11px] font-semibold text-slate-700 mb-1">
                              導入企業規模
                            </dt>
                            <dd>中小企業〜上場企業まで</dd>
                          </div>
                          <div className="rounded-2xl bg-slate-50/80 p-3">
                            <dt className="text-[11px] font-semibold text-slate-700 mb-1">
                              平均導入期間
                            </dt>
                            <dd>約 6〜8 週間</dd>
                          </div>
                        </dl>
                      </div>

                      {/* 右側：機能サマリーカード */}
                      <div className="space-y-3 sm:space-y-4">
                        <div className="glass-card rounded-2xl p-3.5 sm:p-4 flex gap-3 items-start">
                          <div className="mt-0.5 flex h-8 w-8 items-center justify-center rounded-xl bg-blue-50 text-blue-600 text-xs font-semibold">
                            3.1
                          </div>
                          <div className="space-y-1">
                            <p className="text-[11px] tracking-wide text-blue-700/80">
                              企業サイト
                            </p>
                            <p className="text-[13px] font-semibold text-slate-900">
                              高速で信頼感のあるコーポレートサイト
                            </p>
                            <p className="text-[11px] text-slate-600">
                              Next.js + Tailwind による SSG / ISR
                              対応の企業サイトを構築し、 SEO
                              と多言語に最適化します。
                            </p>
                          </div>
                        </div>

                        <div className="glass-card rounded-2xl p-3.5 sm:p-4 flex gap-3 items-start">
                          <div className="mt-0.5 flex h-8 w-8 items-center justify-center rounded-xl bg-emerald-50 text-emerald-600 text-xs font-semibold">
                            3.2
                          </div>
                          <div className="space-y-1">
                            <p className="text-[11px] tracking-wide text-emerald-700/80">
                              販売者ダッシュボード
                            </p>
                            <p className="text-[13px] font-semibold text-slate-900">
                              商品・注文・財務を一元管理
                            </p>
                            <p className="text-[11px] text-slate-600">
                              next-auth
                              による安全な認証と、商品・注文・財務の管理機能を
                              シンプルな UI で提供します。
                            </p>
                          </div>
                        </div>

                        <div className="glass-card rounded-2xl p-3.5 sm:p-4 flex gap-3 items-start">
                          <div className="mt-0.5 flex h-8 w-8 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600 text-xs font-semibold">
                            3.3
                          </div>
                          <div className="space-y-1">
                            <p className="text-[11px] tracking-wide text-indigo-700/80">
                              商品公開サイト
                            </p>
                            <p className="text-[13px] font-semibold text-slate-900">
                              マルチテナントの「見せる」EC
                            </p>
                            <p className="text-[11px] text-slate-600">
                              /shop/[shopId]
                              形式で各店舗専用のページを自動生成し、
                              多言語の商品情報を消費者にわかりやすく表示します。
                            </p>
                          </div>
                        </div>

                        <div className="glass-card rounded-2xl p-3.5 sm:p-4 flex gap-3 items-start">
                          <div className="mt-0.5 flex h-8 w-8 items-center justify-center rounded-xl bg-rose-50 text-rose-600 text-xs font-semibold">
                            3.4
                          </div>
                          <div className="space-y-1">
                            <p className="text-[11px] tracking-wide text-rose-700/80">
                              AI アシスタント
                            </p>
                            <p className="text-[13px] font-semibold text-slate-900">
                              翻訳と商品提案を自動化
                            </p>
                            <p className="text-[11px] text-slate-600">
                              ダッシュボード右下のボタンから呼び出せる AI
                              アシスタントが、
                              翻訳や商品企画のたたき台作成をサポートします。
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </section>
                </div>
              )}

              {/* 会社案内 */}
              {companyTab === "company" && (
                <div
                  id="company-company"
                  className="company-page fade-up space-y-4"
                >
                  <section className="glass-card rounded-3xl p-6 sm:p-7 lg:p-8">
                    <h2 className="text-lg sm:text-xl font-semibold text-slate-900 mb-2">
                      会社概要
                    </h2>
                    <p className="text-[13px] sm:text-sm text-slate-600 leading-relaxed mb-6">
                      当社は、日本企業向けに越境EC・マルチテナント型コマースプラットフォームを提供するテクノロジーカンパニーです。
                      Next.js / React / TypeScript
                      を中心としたモダンスタックと、Tailwind CSS・shadcn/ui
                      を組み合わせることで、
                      シンプルで安心感のある管理画面と、拡張性の高いアーキテクチャを両立しています。
                    </p>
                    <div className="grid gap-5 md:grid-cols-3 text-sm">
                      <div className="rounded-2xl bg-slate-50/90 p-4">
                        <h3 className="text-[11px] font-semibold tracking-[0.18em] uppercase text-slate-400 mb-2">
                          Company
                        </h3>
                        <dl className="space-y-1 text-slate-700 text-[13px]">
                          <div className="flex justify-between">
                            <dt>会社名</dt>
                            <dd className="text-right font-medium">
                              Example Commerce 株式会社
                            </dd>
                          </div>
                          <div className="flex justify-between">
                            <dt>所在地</dt>
                            <dd className="text-right">東京都◯◯区</dd>
                          </div>
                          <div className="flex justify-between">
                            <dt>設立</dt>
                            <dd className="text-right">2024年</dd>
                          </div>
                        </dl>
                      </div>
                      <div className="rounded-2xl bg-slate-50/90 p-4">
                        <h3 className="text-[11px] font-semibold tracking-[0.18em] uppercase text-slate-400 mb-2">
                          Mission
                        </h3>
                        <p className="text-slate-700 text-[13px] leading-relaxed">
                          日本から世界へ。中小企業でも無理なく越境ECに取り組める基盤を提供し、
                          言語・通貨・決済の壁をテクノロジーで解消することを目指します。
                        </p>
                      </div>
                      <div className="rounded-2xl bg-slate-50/90 p-4">
                        <h3 className="text-[11px] font-semibold tracking-[0.18em] uppercase text-slate-400 mb-2">
                          Values
                        </h3>
                        <ul className="space-y-1.5 text-slate-700 text-[13px] list-disc list-inside">
                          <li>Simple：分かりやすいUIと導入プロセス</li>
                          <li>Transparent：料金とデータの透明性</li>
                          <li>Reliable：日本語による丁寧なサポート</li>
                        </ul>
                      </div>
                    </div>
                  </section>
                </div>
              )}

              {/* サービス */}
              {companyTab === "services" && (
                <div
                  id="company-services"
                  className="company-page fade-up space-y-4"
                >
                  <section className="glass-card rounded-3xl p-6 sm:p-7 lg:p-8">
                    <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-5">
                      <div>
                        <h2 className="text-lg sm:text-xl font-semibold text-slate-900 mb-1">
                          サービス概要
                        </h2>
                        <p className="text-[13px] sm:text-sm text-slate-600">
                          3つのモジュールを組み合わせることで、貴社のフェーズに合わせた段階的な導入が可能です。
                          MVP から本番運用までを一気通貫で支援します。
                        </p>
                      </div>
                      <p className="text-[11px] text-slate-500">
                        すべてのモジュールは Next.js
                        をベースにした一貫したアーキテクチャで構築されます。
                      </p>
                    </div>

                    <div className="grid gap-5 md:grid-cols-3 text-sm">
                      <div className="rounded-2xl border border-slate-100 bg-white/80 p-4 hover:shadow-card hover:-translate-y-0.5 transition">
                        <p className="text-[11px] font-semibold text-blue-700 mb-1">
                          モジュール 1
                        </p>
                        <h3 className="font-semibold text-slate-900 mb-1">
                          企業公式サイト構築
                        </h3>
                        <p className="text-slate-600 text-[13px] mb-2">
                          /, /company, /services, /cases, /contact
                          など、企業サイトとして必要なページを整備します。
                        </p>
                        <ul className="text-[12px] text-slate-600 space-y-1.5 list-disc list-inside">
                          <li>Next.js + Tailwind ベース</li>
                          <li>多言語対応（日本語・英語・中国語）</li>
                          <li>SEO最適化（Metadata API）</li>
                          <li>SSG / ISR による高速表示</li>
                        </ul>
                      </div>
                      <div className="rounded-2xl border border-slate-100 bg-white/80 p-4 hover:shadow-card hover:-translate-y-0.5 transition">
                        <p className="text-[11px] font-semibold text-emerald-700 mb-1">
                          モジュール 2
                        </p>
                        <h3 className="font-semibold text-slate-900 mb-1">
                          販売者ダッシュボード
                        </h3>
                        <p className="text-slate-600 text-[13px] mb-2">
                          /auth/login, /dashboard, /dashboard/products
                          など、運営に必要な画面をまとめて提供します。
                        </p>
                        <ul className="text-[12px] text-slate-600 space-y-1.5 list-disc list-inside">
                          <li>メール＋パスワード認証（next-auth）</li>
                          <li>商品・注文・財務の一元管理</li>
                          <li>AIアシスタントによる翻訳・商品提案</li>
                        </ul>
                      </div>
                      <div className="rounded-2xl border border-slate-100 bg-white/80 p-4 hover:shadow-card hover:-translate-y-0.5 transition">
                        <p className="text-[11px] font-semibold text-indigo-700 mb-1">
                          モジュール 3
                        </p>
                        <h3 className="font-semibold text-slate-900 mb-1">
                          商品公開サイト
                        </h3>
                        <p className="text-slate-600 text-[13px] mb-2">
                          /shop/[shopId], /shop/[shopId]/product/[productId]
                          形式で、マルチテナント構成を実現します。
                        </p>
                        <ul className="text-[12px] text-slate-600 space-y-1.5 list-disc list-inside">
                          <li>多言語の商品名・説明文の表示</li>
                          <li>価格・在庫・画像・販売エリアの表示</li>
                          <li>MVPでは「閲覧のみ」（決済は後続フェーズ）</li>
                        </ul>
                      </div>
                    </div>
                  </section>
                </div>
              )}

              {/* 導入事例 */}
              {companyTab === "cases" && (
                <div
                  id="company-cases"
                  className="company-page fade-up space-y-4"
                >
                  <section className="glass-card rounded-3xl p-6 sm:p-7 lg:p-8">
                    <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-5">
                      <div>
                        <h2 className="text-lg sm:text-xl font-semibold text-slate-900 mb-1">
                          導入事例
                        </h2>
                        <p className="text-[13px] sm:text-sm text-slate-600">
                          実際にご利用いただいている企業様の事例をご紹介します。
                        </p>
                      </div>
                      <div className="flex items-center gap-2 text-[11px] sm:text-xs">
                        <label className="text-slate-500">業種で絞り込み</label>
                        <select className="border border-slate-200 rounded-full px-3 py-1 bg-black text-[11px]">
                          <option>すべて</option>
                          <option>メーカー</option>
                          <option>D2Cブランド</option>
                          <option>卸売</option>
                        </select>
                      </div>
                    </div>

                    <div className="grid gap-4 md:grid-cols-3 text-sm">
                      {[1, 2, 3].map((id) => {
                        const is1 = id === 1;
                        const is2 = id === 2;
                        return (
                          <article
                            key={id}
                            onClick={() => setSelectedCaseId(id)}
                            className="case-card rounded-2xl border border-slate-100 bg-white/90 p-4 cursor-pointer hover:border-blue-300 hover:shadow-card hover:-translate-y-0.5 transition"
                          >
                            <p
                              className={
                                "text-[11px] mb-1 " +
                                (is1
                                  ? "text-blue-700"
                                  : is2
                                  ? "text-emerald-700"
                                  : "text-indigo-700")
                              }
                            >
                              事例 0{id}
                            </p>
                            <h3 className="font-semibold text-slate-900 mb-1">
                              {caseData[id].title}
                            </h3>
                            <p className="text-[12px] text-slate-600 mb-2">
                              {id === 1 &&
                                "北米向けに越境ECサイトを新規立ち上げ。多言語の商品ページとシンプルな商品管理により、運用負荷を抑えながら新市場への参入を実現しました。"}
                              {id === 2 &&
                                "アジア複数国向けに商品情報を多言語で配信。販売エリアごとの価格・在庫・支払い方法をダッシュボードから一括管理しています。"}
                              {id === 3 &&
                                "短期間でのローンチを最重視し、第1段階では商品公開サイトのみを構築。その後、販売者ダッシュボードや決済連携を段階的に追加しました。"}
                            </p>
                            <p className="text-[11px] text-slate-500">
                              {id === 1 &&
                                "導入モジュール：企業サイト / 販売者ダッシュボード / 商品公開サイト"}
                              {id === 2 &&
                                "導入モジュール：販売者ダッシュボード / 商品公開サイト"}
                              {id === 3 &&
                                "導入モジュール：企業サイト / 商品公開サイト（MVP）"}
                            </p>
                          </article>
                        );
                      })}
                    </div>

                    {currentCase && (
                      <div
                        id="case-detail"
                        className="mt-6 border-t border-slate-200 pt-4"
                      >
                        <h3 className="text-sm font-semibold text-slate-900 mb-2">
                          事例詳細
                        </h3>
                        <p className="text-[11px] text-slate-500 mb-3">
                          ※
                          上のカードをクリックすると、ここに簡易的な事例詳細（/cases/[id]）が表示されるイメージです。
                        </p>
                        <div
                          className="text-[13px] text-slate-700 space-y-1.5"
                          id="case-detail-content"
                        >
                          <h4 className="font-semibold">{currentCase.title}</h4>
                          <p className="mt-1">{currentCase.content}</p>
                        </div>
                      </div>
                    )}
                  </section>
                </div>
              )}

              {/* お問い合わせ */}
              {companyTab === "contact" && (
                <div
                  id="company-contact"
                  className="company-page fade-up space-y-4"
                >
                  <section
                    className="glass-card rounded-3xl p-6 sm:p-7 lg:p-8"
                    id="company-contact-form"
                  >
                    <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-5">
                      <div>
                        <h2 className="text-lg sm:text-xl font-semibold text-slate-900 mb-1">
                          お問い合わせ
                        </h2>
                        <p className="text-[13px] sm:text-sm text-slate-600">
                          サービスに関するご相談・お見積り・デモのご依頼などは、以下のフォームよりお気軽にお問い合わせください。
                        </p>
                      </div>
                      <p className="text-[11px] text-slate-500">
                        送信いただいた内容は、2営業日以内を目安にご返信いたします。
                      </p>
                    </div>

                    <form className="grid md:grid-cols-2 gap-5 text-[13px] sm:text-sm">
                      <div className="space-y-1 md:col-span-1">
                        <label className="block text-slate-700">
                          お名前 <span className="text-rose-500">*</span>
                        </label>
                        <input
                          type="text"
                          className="w-full border border-slate-200 rounded-xl px-3 py-2 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-blue-500/70 focus:border-blue-500"
                          placeholder="山田 太郎"
                          required
                        />
                      </div>
                      <div className="space-y-1 md:col-span-1">
                        <label className="block text-slate-700">
                          メールアドレス{" "}
                          <span className="text-rose-500">*</span>
                        </label>
                        <input
                          type="email"
                          className="w-full border border-slate-200 rounded-xl px-3 py-2 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-blue-500/70 focus:border-blue-500"
                          placeholder="taro@example.co.jp"
                          required
                        />
                      </div>
                      <div className="space-y-1 md:col-span-1">
                        <label className="block text-slate-700">会社名</label>
                        <input
                          type="text"
                          className="w-full border border-slate-200 rounded-xl px-3 py-2 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-blue-500/70 focus:border-blue-500"
                          placeholder="Example Commerce 株式会社"
                        />
                      </div>
                      <div className="space-y-1 md:col-span-1">
                        <label className="block text-slate-700">
                          ご希望の連絡言語
                        </label>
                        <select className="w-full border border-slate-200 rounded-xl px-3 py-2 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-blue-500/70 focus:border-blue-500">
                          <option>日本語での連絡を希望</option>
                          <option>英語での連絡を希望</option>
                          <option>中国語（簡体字）での連絡を希望</option>
                        </select>
                      </div>
                      <div className="space-y-1 md:col-span-2">
                        <label className="block text-slate-700">
                          お問い合わせ内容{" "}
                          <span className="text-rose-500">*</span>
                        </label>
                        <textarea
                          rows={5}
                          className="w-full border border-slate-200 rounded-xl px-3 py-2 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-blue-500/70 focus:border-blue-500"
                          placeholder="現在の課題や、実現したいことについて具体的にご記入ください。"
                          required
                        />
                      </div>
                      <div className="md:col-span-2 flex items-center justify-between text-[11px] text-slate-500">
                        <p>
                          ご入力いただいた情報は、お問い合わせ対応の目的以外では使用いたしません。
                        </p>
                        <button
                          type="submit"
                          className="inline-flex items-center justify-center rounded-full bg-gradient-to-r from-blue-600 to-sky-400 px-4 sm:px-5 py-2 text-xs sm:text-sm font-medium text-white shadow-soft hover:brightness-110 transition"
                        >
                          送信する
                        </button>
                      </div>
                    </form>
                  </section>
                </div>
              )}
            </section>
          )}

          {/* ============================= */}
          {/* 3.2 販売者ダッシュボード */}
          {/* ============================= */}
          {mainTab === "dashboard" && (
            <section id="dashboard-section" className="fade-in space-y-4">
              <div className="flex items-center justify-between gap-3 text-[12px] sm:text-xs text-slate-200">
                <span className="inline-flex items-center gap-2">
                  <span className="inline-flex h-5 w-5 items-center justify-center rounded-full bg-white/10 text-[10px]">
                    B
                  </span>
                  <span>販売者ダッシュボード</span>
                </span>
                <div className="flex items-center gap-3">
                  <span className="text-slate-300/90">
                    ログイン中：demo@shop.jp
                  </span>
                  <button className="text-slate-300 hover:text-white transition">
                    ログアウト
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-[230px_minmax(0,1fr)] gap-5 sm:gap-6">
                {/* サイドバー */}
                <aside className="glass-card rounded-3xl p-4 sm:p-5 text-xs sm:text-sm">
                  <h3 className="text-[11px] font-semibold text-slate-500 tracking-[0.2em] uppercase mb-3">
                    メニュー
                  </h3>
                  <nav className="space-y-1.5">
                    {(
                      [
                        ["overview", "概要ダッシュボード"],
                        ["profile", "プロフィール"],
                        ["products", "商品一覧"],
                        ["orders", "注文一覧"],
                        ["finance", "財務サマリー"],
                      ] as [DashTab, string][]
                    ).map(([key, label]) => (
                      <button
                        key={key}
                        onClick={() => setDashTab(key)}
                        className={
                          "dash-tab flex w-full items-center gap-2 rounded-xl px-3.5 py-2 text-xs " +
                          (dashTab === key
                            ? "bg-slate-900 text-white shadow-soft"
                            : "text-slate-700 hover:bg-slate-100")
                        }
                      >
                        {label}
                      </button>
                    ))}
                  </nav>
                  <div className="mt-5 border-t border-slate-200 pt-3 text-[11px] text-slate-500">
                    <p className="mb-1">表示言語の優先設定：</p>
                    <p className="font-medium text-slate-700">日本語（ja）</p>
                  </div>
                </aside>

                {/* コンテンツ */}
                <div className="space-y-5 sm:space-y-6">
                  {/* ログイン / 新規登録（簡易） */}
                  <section className="grid gap-4 sm:gap-5 md:grid-cols-2 text-[11px] sm:text-xs">
                    <div className="glass-card rounded-3xl p-4 sm:p-5">
                      <h3 className="text-sm font-semibold text-slate-900 mb-3">
                        /auth/login ログイン
                      </h3>
                      <form className="space-y-2.5">
                        <div>
                          <label className="block text-slate-700 mb-1">
                            メールアドレス
                          </label>
                          <input
                            type="email"
                            className="w-full border border-slate-200 rounded-xl px-3 py-1.5 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-blue-500/70 focus:border-blue-500"
                            placeholder="shop-owner@example.jp"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-700 mb-1">
                            パスワード
                          </label>
                          <input
                            type="password"
                            className="w-full border border-slate-200 rounded-xl px-3 py-1.5 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-blue-500/70 focus:border-blue-500"
                          />
                        </div>
                        <button
                          type="button"
                          className="mt-1 w-full inline-flex items-center justify-center rounded-full bg-slate-900 px-3 py-1.5 text-[11px] font-medium text-white shadow-soft"
                        >
                          ログイン
                        </button>
                      </form>
                    </div>
                    <div className="glass-card rounded-3xl p-4 sm:p-5">
                      <h3 className="text-sm font-semibold text-slate-900 mb-3">
                        /auth/register 新規登録
                      </h3>
                      <form className="space-y-2.5">
                        <div>
                          <label className="block text-slate-700 mb-1">
                            メールアドレス
                          </label>
                          <input
                            type="email"
                            className="w-full border border-slate-200 rounded-xl px-3 py-1.5 bg-slate-50"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-700 mb-1">
                            パスワード
                          </label>
                          <input
                            type="password"
                            className="w-full border border-slate-200 rounded-xl px-3 py-1.5 bg-slate-50"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-700 mb-1">
                            店舗名
                          </label>
                          <input
                            type="text"
                            className="w-full border border-slate-200 rounded-xl px-3 py-1.5 bg-slate-50"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-700 mb-1">
                            表示言語の優先設定
                          </label>
                          <select className="w-full border border-slate-200 rounded-xl px-3 py-1.5 bg-slate-50">
                            <option value="ja">日本語（優先）</option>
                            <option value="en">英語（優先）</option>
                            <option value="zh">中国語（簡体字）（優先）</option>
                          </select>
                        </div>
                        <button
                          type="button"
                          className="mt-1 w全 inline-flex items-center justify-center rounded-full bg-gradient-to-r from-blue-600 to-sky-400 px-3 py-1.5 text-[11px] font-medium text-white shadow-soft"
                        >
                          新規登録
                        </button>
                      </form>
                    </div>
                  </section>

                  {/* 概要ダッシュボード */}
                  {dashTab === "overview" && (
                    <section
                      id="dash-overview"
                      className="dash-page glass-card rounded-3xl p-5 sm:p-6 space-y-4 text-[11px]"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                        <div>
                          <h2 className="text-sm sm:text-base font-semibold text-slate-900 mb-1">
                            ダッシュボード
                          </h2>
                          <p className="text-[11px] text-slate-500">
                            売上や注文状況などの主な指標を確認できます。
                          </p>
                        </div>
                        <div className="flex items-center gap-2 text-[11px]">
                          <span className="text-slate-500">集計期間</span>
                          <select className="border border-slate-200 rounded-full px-3 py-1 bg-black">
                            <option>直近30日</option>
                            <option>今月</option>
                            <option>先月</option>
                          </select>
                        </div>
                      </div>

                      <div className="grid gap-3 md:grid-cols-4 text-[11px]">
                        <div className="rounded-2xl border border-slate-100 bg-white p-3.5">
                          <p className="text-slate-500 mb-1">総売上（JPY）</p>
                          <p className="text-xl font-semibold text-slate-900">
                            ¥1,280,000
                          </p>
                          <p className="mt-0.5 text-[10px] text-emerald-600">
                            前月比 +18.4%
                          </p>
                        </div>
                        <div className="rounded-2xl border border-slate-100 bg-white p-3.5">
                          <p className="text-slate-500 mb-1">注文数</p>
                          <p className="text-xl font-semibold text-slate-900">
                            324件
                          </p>
                          <p className="mt-0.5 text-[10px] text-emerald-600">
                            前月比 +12.1%
                          </p>
                        </div>
                        <div className="rounded-2xl border border-slate-100 bg-white p-3.5">
                          <p className="text-slate-500 mb-1">平均注文単価</p>
                          <p className="text-xl font-semibold text-slate-900">
                            ¥3,950
                          </p>
                          <p className="mt-0.5 text-[10px] text-slate-500">
                            全チャネル平均
                          </p>
                        </div>
                        <div className="rounded-2xl border border-slate-100 bg白 p-3.5">
                          <p className="text-slate-500 mb-1">未処理の注文</p>
                          <p className="text-xl font-semibold text-slate-900">
                            12件
                          </p>
                          <p className="mt-0.5 text-[10px] text-amber-600">
                            出荷処理が必要です
                          </p>
                        </div>
                      </div>
                    </section>
                  )}

                  {/* プロフィール */}
                  {dashTab === "profile" && (
                    <section
                      id="dash-profile"
                      className="dash-page glass-card rounded-3xl p-5 sm:p-6 text-[12px] sm:text-sm"
                    >
                      <h2 className="text-sm sm:text-base font-semibold text-slate-900 mb-3">
                        プロフィール設定
                      </h2>
                      <form className="grid gap-4 md:grid-cols-2">
                        <div>
                          <label className="block text-slate-700 mb-1">
                            店舗名
                          </label>
                          <input
                            type="text"
                            className="w-full border border-slate-200 rounded-xl px-3 py-2 bg-slate-50"
                            defaultValue="デモショップ東京"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-700 mb-1">
                            メールアドレス
                          </label>
                          <input
                            type="email"
                            className="w-full border border-slate-200 rounded-xl px-3 py-2 bg-slate-50"
                            defaultValue="demo@shop.jp"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-700 mb-1">
                            表示言語の優先設定
                          </label>
                          <select className="w-full border border-slate-200 rounded-xl px-3 py-2 bg-slate-50">
                            <option>日本語（ja）</option>
                            <option>英語（en）</option>
                            <option>中国語（簡体字）（zh）</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-slate-700 mb-1">
                            会社情報
                          </label>
                          <input
                            type="text"
                            className="w-full border border-slate-200 rounded-xl px-3 py-2 bg-slate-50"
                            placeholder="会社名・住所などを入力してください"
                          />
                        </div>
                        <div className="md:col-span-2 flex justify-end pt-1">
                          <button
                            type="button"
                            className="rounded-full bg-gradient-to-r from-blue-600 to-sky-400 px-4 sm:px-5 py-2 text-xs sm:text-sm font-medium text-white shadow-soft"
                          >
                            変更を保存する
                          </button>
                        </div>
                      </form>
                    </section>
                  )}

                  {/* 商品一覧 */}
                  {dashTab === "products" && (
                    <section
                      id="dash-products"
                      className="dash-page glass-card rounded-3xl p-5 sm:p-6 text-[11px] sm:text-xs"
                    >
                      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-4">
                        <div>
                          <h2 className="text-sm font-semibold text-slate-900">
                            商品一覧
                          </h2>
                          <p className="text-[11px] text-slate-500">
                            ログイン中の店舗に紐づく商品のみが表示されます。
                          </p>
                        </div>
                        <div className="flex flex-wrap items-center gap-2">
                          <input
                            type="text"
                            placeholder="商品名で検索"
                            className="border border-slate-200 rounded-full px-3 py-1 bg-white"
                          />
                          <select className="border border-slate-200 rounded-full px-3 py-1 bg-white">
                            <option>すべてのステータス</option>
                            <option>販売中（上架）</option>
                            <option>販売停止（下架）</option>
                          </select>
                          <button className="rounded-full bg-gradient-to-r from-blue-600 to-sky-400 px-3 py-1 text-[11px] font-medium text-white shadow-soft">
                            新規商品を追加
                          </button>
                        </div>
                      </div>

                      <div className="overflow-hidden rounded-2xl border border-slate-100 bg-white">
                        <table className="w-full text-left">
                          <thead className="bg-slate-50 text-[11px] text-slate-500 uppercase">
                            <tr>
                              <th className="px-3 py-2">商品名（日本語）</th>
                              <th className="px-3 py-2">SKU</th>
                              <th className="px-3 py-2">価格</th>
                              <th className="px-3 py-2">在庫</th>
                              <th className="px-3 py-2">販売エリア</th>
                              <th className="px-3 py-2">ステータス</th>
                              <th className="px-3 py-2 text-right">操作</th>
                            </tr>
                          </thead>
                          <tbody className="text-[11px] text-slate-700">
                            <tr className="border-t border-slate-100">
                              <td className="px-3 py-2 align-top">
                                <div className="font-medium">
                                  高保湿フェイスクリーム
                                </div>
                                <div className="mt-0.5 text-[10px] text-slate-400">
                                  他言語の商品名・説明文は「商品翻訳」機能から登録できます。
                                </div>
                              </td>
                              <td className="px-3 py-2 align-top">FC-001</td>
                              <td className="px-3 py-2 align-top">
                                ¥3,980 JPY
                              </td>
                              <td className="px-3 py-2 align-top">128</td>
                              <td className="px-3 py-2 align-top">
                                日本（JP）, 米国（US）
                              </td>
                              <td className="px-3 py-2 align-top">
                                <span className="inline-flex rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] text-emerald-700">
                                  販売中
                                </span>
                              </td>
                              <td className="px-3 py-2 text-right align-top">
                                <button className="rounded-full bg-slate-100 px-2 py-1 hover:bg-slate-200">
                                  編集
                                </button>
                              </td>
                            </tr>
                            <tr className="border-t border-slate-100">
                              <td className="px-3 py-2 align-top">
                                <div className="font-medium">
                                  クレンジングジェル
                                </div>
                                <div className="mt-0.5 text-[10px] text-slate-400">
                                  多言語情報は product_translations
                                  テーブルで管理します。
                                </div>
                              </td>
                              <td className="px-3 py-2 align-top">CL-023</td>
                              <td className="px-3 py-2 align-top">
                                ¥2,480 JPY
                              </td>
                              <td className="px-3 py-2 align-top">64</td>
                              <td className="px-3 py-2 align-top">
                                日本（JP）
                              </td>
                              <td className="px-3 py-2 align-top">
                                <span className="inline-flex rounded-full bg-slate-100 px-2 py-0.5 text-[10px] text-slate-700">
                                  販売停止
                                </span>
                              </td>
                              <td className="px-3 py-2 text-right align-top">
                                <button className="rounded-full bg-slate-100 px-2 py-1 hover:bg-slate-200">
                                  編集
                                </button>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                      <div className="mt-3 flex items-center justify-between text-[10px] text-slate-500">
                        <p>全 24 件中 1〜10 件を表示</p>
                        <div className="flex items-center gap-1">
                          <button className="rounded bg-slate-100 px-2 py-1">
                            前へ
                          </button>
                          <button className="rounded bg-slate-900 px-2 py-1 text-white">
                            1
                          </button>
                          <button className="rounded bg-slate-100 px-2 py-1">
                            2
                          </button>
                          <button className="rounded bg-slate-100 px-2 py-1">
                            次へ
                          </button>
                        </div>
                      </div>
                    </section>
                  )}

                  {/* 注文一覧 */}
                  {dashTab === "orders" && (
                    <section
                      id="dash-orders"
                      className="dash-page glass-card rounded-3xl p-5 sm:p-6 text-[11px] sm:text-xs"
                    >
                      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-4">
                        <div>
                          <h2 className="text-sm font-semibold text-slate-900">
                            注文一覧
                          </h2>
                          <p className="text-[11px] text-slate-500">
                            注文のステータスを一元管理できます。
                          </p>
                        </div>
                        <div className="flex flex-wrap items-center gap-2">
                          <select className="border border-slate-200 rounded-full px-3 py-1 bg-white">
                            <option>すべてのステータス</option>
                            <option>未決済（pending）</option>
                            <option>支払い済み（paid）</option>
                            <option>発送済み（shipped）</option>
                            <option>完了（completed）</option>
                            <option>キャンセル（canceled）</option>
                          </select>
                        </div>
                      </div>

                      <div className="overflow-hidden rounded-2xl border border-slate-100 bg-white">
                        <table className="w-full text-left">
                          <thead className="bg-slate-50 text-[11px] text-slate-500 uppercase">
                            <tr>
                              <th className="px-3 py-2">注文番号</th>
                              <th className="px-3 py-2">注文日時</th>
                              <th className="px-3 py-2">購入者</th>
                              <th className="px-3 py-2">金額</th>
                              <th className="px-3 py-2">ステータス</th>
                              <th className="px-3 py-2 text-right">操作</th>
                            </tr>
                          </thead>
                          <tbody className="text-[11px] text-slate-700">
                            <tr className="border-t border-slate-100">
                              <td className="px-3 py-2">ORD-20240201-001</td>
                              <td className="px-3 py-2">2024-02-01 10:24</td>
                              <td className="px-3 py-2">佐藤 花子</td>
                              <td className="px-3 py-2">¥12,840</td>
                              <td className="px-3 py-2">
                                <span className="inline-flex rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] text-emerald-700">
                                  支払い済み
                                </span>
                              </td>
                              <td className="px-3 py-2 text-right">
                                <button className="rounded-full bg-slate-100 px-2 py-1 hover:bg-slate-200">
                                  詳細
                                </button>
                              </td>
                            </tr>
                            <tr className="border-t border-slate-100">
                              <td className="px-3 py-2">ORD-20240201-002</td>
                              <td className="px-3 py-2">2024-02-01 11:05</td>
                              <td className="px-3 py-2">山本 太郎</td>
                              <td className="px-3 py-2">¥4,380</td>
                              <td className="px-3 py-2">
                                <span className="inline-flex rounded-full bg-amber-50 px-2 py-0.5 text-[10px] text-amber-700">
                                  未決済
                                </span>
                              </td>
                              <td className="px-3 py-2 text-right">
                                <button className="rounded-full bg-slate-100 px-2 py-1 hover:bg-slate-200">
                                  詳細
                                </button>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </section>
                  )}

                  {/* 財務サマリー */}
                  {dashTab === "finance" && (
                    <section
                      id="dash-finance"
                      className="dash-page glass-card rounded-3xl p-5 sm:p-6 text-[11px] sm:text-xs"
                    >
                      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-4">
                        <div>
                          <h2 className="text-sm font-semibold text-slate-900">
                            財務サマリー
                          </h2>
                          <p className="text-[11px] text-slate-500">
                            売上やステータス別の件数を簡易的に確認できます。
                          </p>
                        </div>
                        <button className="rounded-full border border-slate-200 bg-white px-3 py-1 hover:bg-slate-50">
                          CSVでダウンロード
                        </button>
                      </div>

                      <div className="grid gap-3 md:grid-cols-3 mb-4">
                        <div className="rounded-2xl border border-slate-100 bg-white p-3.5">
                          <p className="text-slate-500 mb-1">累計総売上</p>
                          <p className="text-lg font-semibold text-slate-900">
                            ¥8,420,000
                          </p>
                        </div>
                        <div className="rounded-2xl border border-slate-100 bg-white p-3.5">
                          <p className="text-slate-500 mb-1">期間内注文数</p>
                          <p className="text-lg font-semibold text-slate-900">
                            856件
                          </p>
                        </div>
                        <div className="rounded-2xl border border-slate-100 bg-white p-3.5">
                          <p className="text-slate-500 mb-1">期間内売上合計</p>
                          <p className="text-lg font-semibold text-slate-900">
                            ¥1,980,000
                          </p>
                        </div>
                      </div>

                      <div className="rounded-2xl border border-slate-100 bg-white p-4">
                        <h3 className="text-[11px] font-semibold text-slate-700 mb-2">
                          ステータス別内訳
                        </h3>
                        <div className="grid gap-3 md:grid-cols-5">
                          <div>
                            <p className="text-[11px] text-slate-500 mb-1">
                              完了（completed）
                            </p>
                            <p className="text-sm font-semibold text-emerald-700">
                              654 件
                            </p>
                          </div>
                          <div>
                            <p className="text-[11px] text-slate-500 mb-1">
                              支払い済み（paid）
                            </p>
                            <p className="text-sm font-semibold text-blue-700">
                              98 件
                            </p>
                          </div>
                          <div>
                            <p className="text-[11px] text-slate-500 mb-1">
                              発送済み（shipped）
                            </p>
                            <p className="text-sm font-semibold text-slate-700">
                              50 件
                            </p>
                          </div>
                          <div>
                            <p className="text-[11px] text-slate-500 mb-1">
                              未決済（pending）
                            </p>
                            <p className="text-sm font-semibold text-amber-700">
                              32 件
                            </p>
                          </div>
                          <div>
                            <p className="text-[11px] text-slate-500 mb-1">
                              キャンセル・返金
                            </p>
                            <p className="text-sm font-semibold text-rose-700">
                              22 件
                            </p>
                          </div>
                        </div>
                      </div>
                    </section>
                  )}
                </div>
              </div>
            </section>
          )}

          {/* ============================= */}
          {/* 3.3 商品公開サイト */}
          {/* ============================= */}
          {mainTab === "shop" && (
            <section id="shop-section" className="fade-in space-y-4">
              <div className="flex items-center justify-between gap-3 text-[12px] sm:text-xs text-slate-200">
                <span className="inline-flex items-center gap-2">
                  <span className="inline-flex h-5 w-5 items-center justify-center rounded-full bg-white/10 text-[10px]">
                    C
                  </span>
                  <span>商品公開サイト /shop/[shopId]</span>
                </span>
                <span className="text-slate-300/90">
                  ブラウザの言語設定を参考に表示言語を決定（未設定時は日本語）
                </span>
              </div>

              <section className="glass-card rounded-3xl p-5 sm:p-6 lg:p-7">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-5">
                  <div>
                    <p className="text-[11px] text-blue-700 mb-1">
                      ショップID：shop-123
                    </p>
                    <h2 className="text-lg sm:text-xl font-semibold text-slate-900">
                      デモショップ東京
                    </h2>
                    <p className="text-[11px] sm:text-xs text-slate-500">
                      こちらは /shop/[shopId]
                      の画面イメージです。MVP段階では「閲覧のみ」を実装し、注文・決済は後続フェーズで追加します。
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2 text-[11px] sm:text-xs">
                    <select className="border border-slate-200 rounded-full px-3 py-1 bg-black">
                      <option>すべてのカテゴリ</option>
                      <option>スキンケア</option>
                      <option>ヘアケア</option>
                    </select>
                    <select className="border border-slate-200 rounded-full px-3 py-1 bg-black">
                      <option>おすすめ順</option>
                      <option>価格が安い順</option>
                      <option>価格が高い順</option>
                    </select>
                  </div>
                </div>

                <div className="grid gap-4 md:grid-cols-3 text-sm">
                  <article className="overflow-hidden rounded-2xl border border-slate-100 bg-white hover:border-blue-300 hover:shadow-card hover:-translate-y-0.5 transition">
                    <div className="h-40 bg-gradient-to-br from-blue-100 via-sky-100 to-indigo-100 flex items-center justify-center text-[11px] text-blue-700">
                      商品画像（サンプル）
                    </div>
                    <div className="p-4 space-y-1">
                      <p className="text-[11px] text-slate-400">
                        商品詳細ページ：/shop/[shopId]/product/1
                      </p>
                      <h3 className="font-semibold text-slate-900">
                        高保湿フェイスクリーム
                      </h3>
                      <p className="text-[11px] text-slate-500">
                        英語・中国語など、閲覧ユーザーの言語に合わせた商品名・説明文を表示できます。
                      </p>
                      <p className="mt-1 text-sm font-semibold text-slate-900">
                        ¥3,980{" "}
                        <span className="text-[11px] text-slate-500">
                          （税込・JPY）
                        </span>
                      </p>
                      <p className="text-[11px] text-emerald-700">在庫あり</p>
                    </div>
                  </article>

                  <article className="overflow-hidden rounded-2xl border border-slate-100 bg-white hover:border-blue-300 hover:shadow-card hover:-translate-y-0.5 transition">
                    <div className="h-40 bg-gradient-to-br from-emerald-100 via-teal-100 to-sky-100 flex items-center justify-center text-[11px] text-emerald-700">
                      商品画像（サンプル）
                    </div>
                    <div className="p-4 space-y-1">
                      <p className="text-[11px] text-slate-400">
                        商品詳細ページ：/shop/[shopId]/product/2
                      </p>
                      <h3 className="font-semibold text-slate-900">
                        クレンジングジェル
                      </h3>
                      <p className="text-[11px] text-slate-500">
                        多言語の商品説明は管理画面から登録・更新できます。
                      </p>
                      <p className="mt-1 text-sm font-semibold text-slate-900">
                        ¥2,480{" "}
                        <span className="text-[11px] text-slate-500">
                          （税込・JPY）
                        </span>
                      </p>
                      <p className="text-[11px] text-amber-700">在庫わずか</p>
                    </div>
                  </article>

                  <article className="overflow-hidden rounded-2xl border border-slate-100 bg-white hover:border-blue-300 hover:shadow-card hover:-translate-y-0.5 transition">
                    <div className="h-40 bg-gradient-to-br from-rose-100 via-orange-100 to-amber-100 flex items-center justify-center text-[11px] text-rose-700">
                      商品画像（サンプル）
                    </div>
                    <div className="p-4 space-y-1">
                      <p className="text-[11px] text-slate-400">
                        商品詳細ページ：/shop/[shopId]/product/3
                      </p>
                      <h3 className="font-semibold text-slate-900">
                        UV プロテクトミルク
                      </h3>
                      <p className="text-[11px] text-slate-500">
                        在庫数・表示価格はダッシュボードからリアルタイムに更新されます。
                      </p>
                      <p className="mt-1 text-sm font-semibold text-slate-900">
                        ¥3,280{" "}
                        <span className="text-[11px] text-slate-500">
                          （税込・JPY）
                        </span>
                      </p>
                      <p className="text-[11px] text-slate-500">在庫：24</p>
                    </div>
                  </article>
                </div>
              </section>
            </section>
          )}
        </main>
      </div>

      {/* ======================= */}
      {/* 3.4 AI アシスタント */}
      {/* ======================= */}

      {/* 右下ボタン：ダッシュボード時のみ表示 */}
      {mainTab === "dashboard" && (
        <button
          id="ai-assistant-button"
          onClick={() => setAiOpen(true)}
          className="fixed bottom-5 right-5 z-30 inline-flex items-center gap-2 rounded-full bg-slate-900/95 px-4 py-2 text-[11px] font-medium text-white shadow-soft hover:bg-slate-900"
        >
          <span>AI アシスタント</span>
        </button>
      )}

      {/* モーダル */}
      {aiOpen && (
        <div
          id="ai-assistant-modal"
          className="fixed inset-0 z-40 flex items-end justify-end sm:items-center sm:justify-center bg-black/40"
          onClick={() => setAiOpen(false)}
        >
          <div
            className="glass-card w-full max-w-md rounded-t-3xl sm:rounded-3xl p-4 sm:p-5 shadow-soft"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-3">
              <div>
                <p className="text-[11px] text-slate-500">
                  ダッシュボード用 AI アシスタント
                </p>
                <h3 className="text-sm font-semibold text-slate-900">
                  AI アシスタント
                </h3>
              </div>
              <button
                id="ai-assistant-close"
                onClick={() => setAiOpen(false)}
                className="text-slate-400 hover:text-slate-700 text-xl leading-none"
              >
                &times;
              </button>
            </div>

            <div className="mb-3 flex gap-2 text-[11px]">
              <button
                onClick={() => setAiTab("translate")}
                className={
                  "ai-tab rounded-full px-3 py-1 text-[11px] font-medium " +
                  (aiTab === "translate"
                    ? "bg-slate-900 text-white"
                    : "text-slate-700 hover:bg-slate-100")
                }
              >
                AI翻訳モード
              </button>
              <button
                onClick={() => setAiTab("product")}
                className={
                  "ai-tab rounded-full px-3 py-1 text-[11px] " +
                  (aiTab === "product"
                    ? "bg-slate-900 text-white"
                    : "text-slate-700 hover:bg-slate-100")
                }
              >
                AI商品提案モード
              </button>
            </div>

            {/* AI翻訳モード */}
            {aiTab === "translate" && (
              <div
                id="ai-tab-translate"
                className="ai-page space-y-3 text-[11px]"
              >
                <div className="flex flex-wrap items-center gap-2">
                  <div>
                    <label className="block text-slate-600 mb-1">
                      翻訳元の言語
                    </label>
                    <select className="border border-slate-200 rounded-full px-3 py-1 bg-white">
                      <option>自動判定</option>
                      <option>日本語</option>
                      <option>英語</option>
                      <option>中国語（簡体字）</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">
                      翻訳先の言語
                    </label>
                    <select className="border border-slate-200 rounded-full px-3 py-1 bg-white">
                      <option>日本語（ja）</option>
                      <option>英語（en）</option>
                      <option>中国語（簡体字）（zh）</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-slate-600 mb-1">
                    翻訳したいテキスト
                  </label>
                  <textarea
                    rows={4}
                    className="w-full border border-slate-200 rounded-xl px-3 py-2 text-[11px] bg-slate-50"
                    placeholder="商品説明やキャンペーン文言などを入力してください。"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <button className="rounded-full bg-gradient-to-r from-blue-600 to-sky-400 px-3 py-1.5 text-[11px] font-medium text-white shadow-soft">
                    翻訳を実行
                  </button>
                  <button className="rounded-full border border-slate-200 px-3 py-1.5 text-[11px] text-slate-700">
                    結果をコピー
                  </button>
                </div>
                <div>
                  <p className="text-[11px] text-slate-500 mb-1">
                    翻訳結果（サンプル）
                  </p>
                  <div className="border border-dashed border-slate-300 rounded-xl px-3 py-2 text-[11px] text-slate-700 bg-white/70">
                    ここに翻訳結果が表示されます。実装時にはバックエンドの AI
                    API と連携して、実際の翻訳を取得してください。
                  </div>
                </div>
              </div>
            )}

            {/* AI商品提案モード */}
            {aiTab === "product" && (
              <div
                id="ai-tab-product"
                className="ai-page space-y-3 text-[11px]"
              >
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-slate-600 mb-1">
                      主な取扱カテゴリ
                    </label>
                    <input
                      type="text"
                      className="w-full border border-slate-200 rounded-xl px-3 py-1.5 text-[11px] bg-slate-50"
                      placeholder="例：スキンケア"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">
                      想定する顧客層
                    </label>
                    <input
                      type="text"
                      className="w-full border border-slate-200 rounded-xl px-3 py-1.5 text-[11px] bg-slate-50"
                      placeholder="例：20〜30代女性"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">
                      目安の価格帯
                    </label>
                    <input
                      type="text"
                      className="w-full border border-slate-200 rounded-xl px-3 py-1.5 text-[11px] bg-slate-50"
                      placeholder="例：¥2,000〜¥5,000"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">
                      販売エリア
                    </label>
                    <input
                      type="text"
                      className="w-full border border-slate-200 rounded-xl px-3 py-1.5 text-[11px] bg-slate-50"
                      placeholder='例："JP", "US" など'
                    />
                  </div>
                </div>
                <button className="rounded-full bg-gradient-to-r from-blue-600 to-sky-400 px-3 py-1.5 text-[11px] font-medium text-white shadow-soft">
                  AI商品提案を生成
                </button>
                <div>
                  <p className="text-[11px] text-slate-500 mb-1">
                    AIによる商品提案（サンプル）
                  </p>
                  <div className="border border-dashed border-slate-300 rounded-xl px-3 py-2 text-[11px] text-slate-700 bg-white/70 space-y-2">
                    <p className="font-semibold">おすすめの方向性：</p>
                    <ul className="list-disc list-inside">
                      <li>高保湿・低刺激のベーシックスキンケアライン</li>
                      <li>旅行用のトラベルサイズセット商品</li>
                    </ul>
                    <p className="font-semibold mt-1">
                      商品説明文サンプル（日本語）：
                    </p>
                    <p>
                      「忙しい毎日の中でも、肌本来のうるおいを守りたい方へ。
                      日本生まれの低刺激処方で、乾燥やつっぱり感をやさしくケアするスキンケアシリーズです。」
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
// 关键：导出时关闭 SSR，变成纯客户端渲染，避免 hydration mismatch
const HomePage = dynamic(() => Promise.resolve(HomePageInner), {
  ssr: false,
});

export default HomePage;
