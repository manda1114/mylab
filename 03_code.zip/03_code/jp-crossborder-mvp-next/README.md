|   .env
|   next.config.mjs
|   package.json
|   postcss.config.mjs
|   README.md
|   tailwind.config.mjs
|   tsconfig.json
|
+---app
|   |   layout.tsx
|   |
|   +---(app)
|   |   +---auth
|   |   |   +---login
|   |   |   |       page.tsx
|   |   |   |
|   |   |   \---register
|   |   |           page.tsx
|   |   |
|   |   +---dashboard
|   |   |   |   layout.tsx
|   |   |   |   page.tsx
|   |   |   |
|   |   |   +---finance
|   |   |   |       page.tsx
|   |   |   |
|   |   |   +---orders
|   |   |   |       page.tsx
|   |   |   |
|   |   |   +---products
|   |   |   |       page.tsx
|   |   |   |
|   |   |   \---profile
|   |   |           page.tsx
|   |   |
|   |   \---shop
|   |       \---[shopId]
|   |           |   page.tsx
|   |           |
|   |           \---product
|   |               \---[productId]
|   |                       page.tsx
|   |                       TestOrderButton.tsx
|   |
|   +---(marketing)
|   |   |   layout.tsx
|   |   |   page.tsx
|   |   |
|   |   +---cases
|   |   |   |   page.tsx
|   |   |   |
|   |   |   \---[id]
|   |   |           page.tsx
|   |   |
|   |   +---company
|   |   |       page.tsx
|   |   |
|   |   +---contact
|   |   |       page.tsx
|   |   |
|   |   \---services
|   |           page.tsx
|   |
|   \---api
|       +---ai
|       |   +---product-advice
|       |   |       route.ts
|       |   |
|       |   \---translate
|       |           route.ts
|       |
|       +---auth
|       |   +---register
|       |   |       route.ts
|       |   |
|       |   \---[...nextauth]
|       |           route.ts
|       |
|       +---contact
|       |       route.ts
|       |
|       +---finance
|       |   \---summary
|       |           route.ts
|       |
|       +---orders
|       |   |   route.ts
|       |   |
|       |   \---[id]
|       |           route.ts
|       |
|       +---products
|       |   |   route.ts
|       |   |
|       |   \---[id]
|       |           route.ts
|       |
|       \---profile
|               route.ts
|
+---components
|   |   ai-assistant.tsx
|   |   footer.tsx
|   |   navbar.tsx
|   |
|   \---ui
|           button.tsx
|           card.tsx
|           input.tsx
|           select.tsx
|           table.tsx
|           textarea.tsx
|
+---lib
|       auth.ts
|       prisma.ts
|
+---prisma
|       schema.prisma
|
+---public
|       黒襟鶲.png
|
\---styles
        globals.css