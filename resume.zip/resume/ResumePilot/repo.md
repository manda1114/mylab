resume-ai-assistant/
├─ frontend/
│  ├─ public/
│  ├─ src/
│  │  ├─ app/
│  │  │  ├─ router.tsx
│  │  │  ├─ providers.tsx
│  │  ├─ pages/
│  │  │  ├─ HomePage.tsx
│  │  │  ├─ ResumeInputPage.tsx
│  │  │  ├─ JdInputPage.tsx
│  │  │  └─ ResultPage.tsx
│  │  ├─ components/
│  │  │  ├─ ResumeUpload.tsx
│  │  │  ├─ ResumeTextInput.tsx
│  │  │  ├─ JdForm.tsx
│  │  │  ├─ ScoreCard.tsx
│  │  │  ├─ ProblemList.tsx
│  │  │  ├─ SuggestionList.tsx
│  │  │  ├─ RewritePreview.tsx
│  │  │  └─ LoadingSpinner.tsx
│  │  ├─ api/
│  │  │  ├─ client.ts
│  │  │  ├─ resume.ts
│  │  │  ├─ jd.ts
│  │  │  ├─ analysis.ts
│  │  │  └─ rewrite.ts
│  │  ├─ hooks/
│  │  │  ├─ useUploadResume.ts
│  │  │  ├─ useParseResume.ts
│  │  │  ├─ useCreateJd.ts
│  │  │  ├─ useAnalysis.ts
│  │  │  └─ useRewrite.ts
│  │  ├─ store/
│  │  │  └─ useSessionStore.ts
│  │  ├─ types/
│  │  │  ├─ resume.ts
│  │  │  ├─ jd.ts
│  │  │  └─ analysis.ts
│  │  ├─ styles/
│  │  │  └─ globals.css
│  │  ├─ App.tsx
│  │  └─ main.tsx
│  ├─ index.html
│  ├─ package.json
│  ├─ tsconfig.json
│  └─ vite.config.ts
│
├─ backend/
│  ├─ app/
│  │  ├─ main.py
│  │  ├─ api/
│  │  │  ├─ resume.py
│  │  │  ├─ jd.py
│  │  │  ├─ analysis.py
│  │  │  └─ rewrite.py
│  │  ├─ core/
│  │  │  ├─ config.py
│  │  │  ├─ database.py
│  │  │  ├─ llm.py
│  │  │  └─ security.py
│  │  ├─ models/
│  │  │  ├─ db_models.py
│  │  │  └─ schemas.py
│  │  ├─ services/
│  │  │  ├─ file_parser.py
│  │  │  ├─ resume_parser.py
│  │  │  ├─ jd_analyzer.py
│  │  │  ├─ scorer.py
│  │  │  ├─ rewriter.py
│  │  │  └─ result_service.py
│  │  ├─ utils/
│  │  │  ├─ id_generator.py
│  │  │  ├─ json_repair.py
│  │  │  ├─ keyword_matcher.py
│  │  │  └─ text_cleaner.py
│  │  └─ prompts/
│  │     ├─ resume_parse.txt
│  │     ├─ jd_parse.txt
│  │     ├─ diagnose.txt
│  │     └─ rewrite.txt
│  ├─ uploads/
│  ├─ requirements.txt
│  └─ .env
│
├─ README.md
└─ docker-compose.yml
