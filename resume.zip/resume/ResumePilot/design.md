# ResumePilot Web App Design

AI 履歴書最適化アシスタント Web アプリケーションの設計を示します。

---

## 1. システム概要

- 目的
  フロントエンドとバックエンドを備えた Web アプリケーションを新規開発し、
  履歴書と求人票（JD）のマッチング・スコアリング・改善提案・最適化後履歴書プレビューを提供する。

- デプロイ先
  - Azure App Service (Linux)
  - 付随サービスもすべて Azure を使用（OpenAI, Storage, Key Vault, Application Insights 等）

- 想定ユーザー
  - 日本国内の求職者（特に IT／エンジニア職）
  - キャリアアドバイザー／採用担当者

---

## 2. アーキテクチャ設計

### 2.1 全体構成

- フロントエンド
  - React ベースの SPA（Vite + React + TypeScript を想定）
  - 静的ビルド成果物を FastAPI アプリから配信、または Azure App Service 上で別構成として配信可能
- バックエンド
  - Python 3.11 + FastAPI
  - REST API でフロントエンドにサービス提供
- 外部サービス（すべて Azure）
  - Azure OpenAI Service：履歴書と JD の解析・生成タスク
  - Azure Storage (Blob)：履歴書ファイル一時保存（必要な場合）
  - Azure Key Vault：各種シークレットの保管
  - Azure Application Insights：ログ、メトリクス収集

### 2.2 コンポーネント構成（論理）

1. **Client (Browser / Frontend)**
   - UI 表示
   - ファイルアップロード
   - API 呼び出し (`/api/...`)

2. **Web App (Backend on Azure App Service)**
   - API エンドポイント
   - ファイル処理（Blob Storage 連携）
   - Azure OpenAI による解析・スコアリング
   - レスポンス整形（AnalysisResult）
   - 必要に応じてフロントエンド静的ファイル配信

3. **Azure Services**
   - Azure OpenAI：Chat Completion API
   - Blob Storage：ファイル保存（任意）
   - Key Vault：API キー等
   - Application Insights：トレース／ログ

---

## 3. 技術スタック

### 3.1 フロントエンド

- フレームワーク：React 18 + TypeScript
- ビルドツール：Vite
- UI
  - CSS：提供された HTML/CSS デザインをベースに移植
  - コンポーネントベースで再構成
- HTTP クライアント：ブラウザ標準 `fetch`（必要に応じて API ラッパを実装）

### 3.2 バックエンド

- ランタイム：Python 3.11
- フレームワーク：FastAPI
- ASGI サーバー：Uvicorn
- 主なライブラリ
  - `fastapi`：API フレームワーク
  - `uvicorn`：アプリ実行
  - `python-multipart`：multipart/form-data の処理
  - `pydantic` / `pydantic-settings`：設定・バリデーション
  - `pdfplumber` または `pypdf`：PDF テキスト抽出
  - `python-docx` または `docx2txt`：DOCX からテキスト抽出
  - `openai`：Azure OpenAI 呼び出し
  - `azure-storage-blob`：Blob Storage 利用時
  - `opencensus-ext-azure` または Azure Monitor / OpenTelemetry 関連ライブラリ：ログ・監視
  - `httpx`：必要に応じた HTTP 通信
  - `pytest`：テスト

---

## 4. フロントエンド詳細設計

### 4.1 画面構成

1. **MainScreen**
   - Topbar（ブランドロゴ、説明）
   - Hero セクション（サービス説明、デモ指標）
   - Dashboard
     - 左：入力パネル
     - 右：スコア・キーワード・課題・改善・プレビュー

### 4.2 主なコンポーネント

- `<App />`
  - ルートコンポーネント。`MainScreen` を表示。

- `<Layout />`
  - Topbar とコンテナレイアウト共通化。

- `<InputPanel />`
  - 履歴書アップロード（ドラッグ＆ドロップ）
  - 履歴書テキスト入力
  - 目標職種入力
  - 求人 JD 入力
  - 「分析開始」「デモ結果を反映」ボタン
  - ローディング表示、ステータスメッセージ表示

- `<ScorePanel />`
  - 総合点・完成度・表現品質・成果の定量化・ATS 対応度
  - プログレスバー表示

- `<KeywordMatchPanel />`
  - JD キーワードとの一致／不足／部分一致／追加キーワードのタグ表示

- `<SuggestionsPanel />`
  - 改善方向（改善提案）のリスト表示

- `<IssuesPanel />`
  - 課題診断のリスト表示

- `<SummaryImprovementPanel />`
  - 要約改善案（自己紹介の改善例）の表示

- `<ResumePreviewPanel />`
  - 最適化後の履歴書プレビュー
  - header（名前・ロール・連絡先）
  - 自己紹介
  - 職務経歴
  - プロジェクト経験
  - スキル

### 4.3 状態管理

- グローバル state（`useState` ベース）
  - `resumeText: string`
  - `jobTitle: string`
  - `jobDescription: string`
  - `analysisResult: AnalysisResult | null`
  - `isLoading: boolean`
  - `statusMessage: string | null`
- デモデータ
  - フロント側に固定サンプル `analysisResult` を用意し、「デモ結果を反映」でセット

### 4.4 API 呼び出し

- `POST /api/upload-resume`
  - ファイル選択時に呼び出し
  - `extractedText` を `resumeText` に反映

- `POST /api/analyze`
  - 「分析開始」クリック時に呼び出し
  - ボディに `resumeText`, `jobTitle`, `jobDescription` を送信
  - レスポンスの `AnalysisResult` を state に格納し、各パネルに反映

---

## 5. バックエンド詳細設計

### 5.1 ディレクトリ構成（例）

```text
backend/
  app/
    main.py                     // エントリポイント
    api/
      routes/
        health.py               // /api/health
        upload.py               // /api/upload-resume
        analyze.py              // /api/analyze
    core/
      config.py                 // 環境変数読み込み
      logging.py                // ログ設定
      security.py               // アップロード制限など
    models/
      requests.py               // Pydantic リクエストモデル
      responses.py              // Pydantic レスポンスモデル
    services/
      openai_service.py         // Azure OpenAI 呼び出し
      analysis_service.py       // 解析ロジック統合
      file_service.py           // Blob Storage、ローカル処理など
      resume_parser.py          // PDF/DOCX/TXT からのテキスト抽出
    utils/
      pii.py                    // PII マスキング補助
      text.py                   // テキスト整形補助
  tests/
    test_health.py
    test_upload.py
    test_analyze.py
  requirements.txt
  pyproject.toml
```

### 5.2 型定義（例：AnalysisResult）

```ts
export interface HeroScores {
  completeness: number;
  match: number;
  ats: number;
  quant: number;
}

export interface Scores {
  total: number;
  completeness: number;
  expression: number;
  quantification: number;
  ats: number;
  hero: HeroScores;
}

export type KeywordStatus = 'match' | 'partial' | 'missing' | 'extra';

export interface Keyword {
  label: string;
  status: KeywordStatus;
}

export interface Suggestion {
  title: string;
  detail: string;
}

export interface Issue {
  title: string;
  detail: string;
}

export interface SummaryImprovement {
  title: string;
  text: string;
}

export interface ExperienceItem {
  company: string;
  title: string;
  period: string;
  items: string[];
}

export interface ProjectItem {
  name: string;
  role: string;
  items: string[];
}

export interface OptimizedResume {
  name: string;
  role: string;
  contact: {
    phone: string;
    email: string;
    location: string;
  };
  sections: {
    summary: string;
    experiences: ExperienceItem[];
    projects: ProjectItem[];
    skills: string[];
  };
}

export interface AnalysisResult {
  scores: Scores;
  keywords: Keyword[];
  suggestions: Suggestion[];
  issues: Issue[];
  summaryImprovements: SummaryImprovement[];
  optimizedResume: OptimizedResume;
}
```

### 5.3 ルーティング仕様

#### 5.3.1 `POST /api/upload-resume`

- 概要：履歴書ファイルを受け取り、テキストを抽出して返却。
- リクエスト
  - Content-Type: `multipart/form-data`
  - フィールド：`file`
- レスポンス
  ```json
  {
    "success": true,
    "extractedText": "抽出されたテキスト...",
    "fileId": "optional-id-or-url"
  }
  ```

#### 5.3.2 `POST /api/analyze`

- 概要：履歴書テキストと JD をもとに Azure OpenAI で解析し、`AnalysisResult` を返す。
- リクエスト
  ```json
  {
    "resumeText": "string",
    "jobTitle": "string",
    "jobDescription": "string",
    "options": {
      "language": "ja"
    }
  }
  ```
- レスポンス
  - `AnalysisResult` 構造の JSON

#### 5.3.3 `GET /api/health`

- 概要：ヘルスチェック用
- レスポンス
  ```json
  { "status": "ok" }
  ```

---

## 6. ファイル処理設計

- 受信フォーマット：PDF / DOCX / TXT
- 実装方針
  - `upload-resume` で受信したファイルを一時ディレクトリに保存
  - 拡張子・MIME チェック
  - 拡張子ごとのテキスト抽出
    - PDF：`pdf-parse` 等
    - DOCX：`mammoth` 等
    - TXT：そのまま読み込み
  - 抽出テキストはメモリ上で扱い、必要に応じて Blob Storage へ保存（必須ではない）
- セキュリティ
  - 最大ファイルサイズ制限（例：5MB）
  - 拡張子・Content-Type のホワイトリスト
  - 不正なファイルは 400/415 を返却
  
初期リリースでは、Blob Storage への永続保存は行わず、サーバー上の一時ファイルのみで処理する実装も許容とする。将来的に履歴書履歴の保存が必要になった場合に Blob Storage 連携を拡張する。

---

## 7. AI 連携設計（Azure OpenAI）

### 7.1 呼び出しフロー

1. `/api/analyze` でリクエストを受信
2. `resumeText`, `jobTitle`, `jobDescription` を `aiService` に渡す
3. `aiService` 内で以下を実行：
   - system メッセージテンプレートの生成
   - user メッセージテンプレートに入力を埋め込み
   - Azure OpenAI Chat Completion API を呼び出し
   - 返却されたテキストを JSON としてパース
   - `AnalysisResult` 型にマッピング・バリデーション
4. 結果をクライアントに返す

### 7.2 モデル・パラメータ

- モデル：`gpt-4o` もしくは同等の Azure OpenAI モデル
- 推奨パラメータ（例）：
  - `temperature`: 0.4
  - `top_p`: 0.95
  - `max_tokens`: 1800〜2500（履歴書の長さに応じて調整）
- 呼び出し形式：Chat Completion（`messages: [ system, user ]`）

### 7.3 エラー処理方針

- LLM 呼び出し失敗（タイムアウト・429 等）
  - 429/503 の場合：1 回リトライ（指数バックオフ）
  - それでも失敗した場合：`500` を返し、ユーザーには汎用エラーメッセージ
- JSON パースエラー
  - 1 回だけプロンプトを少し厳格化して再試行
  - 2 回失敗した場合：`500` として返却

---

## 8. プロンプト設計

### 8.2 プロンプト設計（概要）

- system メッセージ：
  - 「あなたは日本語のキャリアアドバイザー兼採用担当者です。履歴書と求人票を分析し…」等のロール・目的を明示
  - 出力形式を **厳格な JSON** として指定し、`AnalysisResult` 構造を明文化
  - 日本語での応答、かつ不要な説明文・コメントを一切含めないことを明示
- user メッセージ：
  - `jobTitle`, `resumeText`, `jobDescription` を渡す
  - スコアリング、キーワード抽出、改善案生成、最適化後履歴書構成を指示

以下に、実際に使用するテンプレートと `AnalysisResult` の構造を定義する。

---

#### 8.2.1 system メッセージ テンプレート

```text
あなたは日本語のキャリアアドバイザー兼採用担当者です。
これから渡す「履歴書テキスト」と「求人票テキスト」を分析し、
候補者の職務経歴が求人にどれくらいマッチしているかを評価し、
スコアリング・キーワード一致・課題・改善提案・最適化後の履歴書案を生成してください。

必ず以下の制約を守ってください：

- 出力は **有効な JSON のみ** を返してください。
- JSON 以外のテキスト（説明文、コメント、マークダウン、余計な文字列）は一切出力してはいけません。
- JSON のキー名・構造は、後述の `AnalysisResult` スキーマに**完全に一致**させてください。
- 文字列はすべて日本語で記述してください（変数名・キー名は英語）。
- 数値フィールド（スコアなど）は 0〜100 の整数で返してください。
- 想定読者は日本の採用担当者および候補者であり、ビジネス日本語として自然な文章にしてください。

`AnalysisResult` の JSON スキーマ：

{
  "scores": {
    "total": number,              // 総合スコア（0〜100）
    "completeness": number,       // 履歴書の情報の網羅性
    "expression": number,         // 表現の分かりやすさ・読みやすさ
    "quantification": number,     // 成果の定量化度合い
    "ats": number,                // ATS への適合度（構造・キーワードなど）
    "hero": {
      "completeness": number,     // ヒーローパネル用・完成度
      "match": number,            // 目標職種とのマッチ度
      "ats": number,              // ヒーローパネル用・ATS
      "quant": number             // ヒーローパネル用・定量化
    }
  },
  "keywords": [
    {
      "label": string,            // キーワード例: "Java", "Spring Boot"
      "status": string            // "match" | "partial" | "missing" | "extra"
    }
  ],
  "suggestions": [
    {
      "title": string,            // 改善方向のタイトル
      "detail": string            // 具体的な改善内容
    }
  ],
  "issues": [
    {
      "title": string,            // 課題のタイトル
      "detail": string            // 課題の詳細説明
    }
  ],
  "summaryImprovements": [
    {
      "title": string,            // 例: "推奨改善例"
      "text": string              // 改善後の自己紹介文サンプル
    }
  ],
  "optimizedResume": {
    "name": string,               // 候補者名（履歴書から推定または空文字可）
    "role": string,               // 目標職種または現在のロール
    "contact": {
      "phone": string,            // 電話（分からない場合は空文字）
      "email": string,            // メールアドレス（分からない場合は空文字）
      "location": string          // 居住地（分からない場合は空文字）
    },
    "sections": {
      "summary": string,          // 自己紹介・サマリー
      "experiences": [
        {
          "company": string,
          "title": string,
          "period": string,       // 例: "2022.07 - 現在"
          "items": string[]       // 箇条書きの業務内容・成果
        }
      ],
      "projects": [
        {
          "name": string,
          "role": string,
          "items": string[]       // 箇条書きのプロジェクト内容・成果
        }
      ],
      "skills": string[]          // スキル一覧（例: ["Java", "Spring Boot", ...]）
    }
  }
}

重要：
- 上記 JSON スキーマに含まれないキーを追加してはいけません。
- すべての必須フィールドを埋めてください（不明な場合は空文字列 "" や空配列 [] を使用）。
- JSON はトップレベルが 1 つのオブジェクトである必要があります。
```

---

#### 8.2.2 user メッセージ テンプレート

バックエンドでは、`jobTitle`, `resumeText`, `jobDescription` を埋め込んで以下のテンプレートを送信する。

```text
以下の情報に基づいて、先に示した AnalysisResult スキーマに沿った JSON を生成してください。

【目標職種（jobTitle）】
{jobTitle}

【履歴書テキスト（resumeText）】
{resumeText}

【求人票テキスト（jobDescription）】
{jobDescription}

求める出力内容：
1. スコアリング
   - total, completeness, expression, quantification, ats を 0〜100 の整数で評価してください。
   - hero.completeness, hero.match, hero.ats, hero.quant も 0〜100 の整数で設定してください。
   - スコアは求人票とのマッチ度・履歴書の質を総合的に判断して付与してください。

2. キーワード抽出（keywords）
   - 求人票テキストから重要なスキル・経験・キーワードを抽出してください。
   - 各キーワードについて、履歴書にどの程度現れているかを判定し、
     "status" を以下のいずれかで指定してください：
     - "match": 履歴書に明確に記載があり、十分にアピールできている。
     - "partial": 間接的・一部のみ記載がある、もしくは関連する表現が弱い。
     - "missing": 求人票にはあるが、履歴書にはほとんど・全く記載がない。
     - "extra": 求人票にはないが、履歴書にありアピール材料となりうる。

3. 改善提案（suggestions）
   - 履歴書を求人票によりマッチさせるための改善提案を 3〜5 件程度作成してください。
   - 各提案は「title」「detail」で構成し、具体的な修正方針を記述してください。

4. 課題診断（issues）
   - 採用担当視点での懸念点・不足点を 2〜5 件程度抽出し、
     「title」「detail」で説明してください。

5. 要約改善案（summaryImprovements）
   - 自己紹介・サマリーの改善例を 1〜2 件作成してください。
   - 実際に履歴書にそのまま使える程度の自然な日本語で 200〜400 文字程度を目安としてください。

6. 最適化後履歴書（optimizedResume）
   - 求人票とのマッチ度を高める形で、セクションごとに整理された履歴書案を作成してください。
   - summary, experiences, projects, skills など、AnalysisResult のスキーマに沿って埋めてください。
   - experience.items や projects.items は、箇条書きで分かりやすく具体的に書いてください。
   - 数値目標（〜%改善、〜件/日、〜ms 短縮 など）は、履歴書・求人票の内容から推測できる範囲で無理のないレベルにとどめてください。

重要な注意：
- 出力は AnalysisResult 構造の JSON のみとし、それ以外の文字列を一切含めないでください。
- JSON 内の改行やインデントは自由ですが、必ずパース可能な形式にしてください。
```

---

#### 8.2.3 出力 JSON の具体例

開発時・テスト時に参照するサンプルとして、モデルに期待する出力の一例を設計段階で用意しておく。

```json
{
  "scores": {
    "total": 82,
    "completeness": 88,
    "expression": 79,
    "quantification": 68,
    "ats": 91,
    "hero": {
      "completeness": 88,
      "match": 82,
      "ats": 91,
      "quant": 68
    }
  },
  "keywords": [
    { "label": "Java", "status": "match" },
    { "label": "Spring Boot", "status": "match" },
    { "label": "MySQL", "status": "match" },
    { "label": "Redis", "status": "match" },
    { "label": "SQL最適化", "status": "partial" },
    { "label": "高負荷処理", "status": "partial" },
    { "label": "マイクロサービス", "status": "missing" },
    { "label": "障害調査", "status": "extra" }
  ],
  "suggestions": [
    {
      "title": "関連スキルの強調",
      "detail": "Java、Spring Boot、MySQL、Redis を職務要約やスキル欄の冒頭にまとめて記載し、求人票との一致を明確に示してください。"
    },
    {
      "title": "性能改善実績の定量化",
      "detail": "API 応答時間の改善率やピーク時の処理件数など、具体的な数値を追加してパフォーマンス改善の成果を示してください。"
    }
  ],
  "issues": [
    {
      "title": "成果の定量的な記載不足",
      "detail": "担当業務の列挙に留まっており、どの程度の改善・貢献をしたかが分かりづらい状態です。"
    }
  ],
  "summaryImprovements": [
    {
      "title": "推奨改善例",
      "text": "バックエンドエンジニアとして3年の実務経験を有し、Java／Spring Boot／MySQL／Redis を用いた業務システム開発に従事してきました。ユーザー管理・注文管理など基幹機能の API 設計・実装に携わり、高負荷環境での性能改善や障害対応も経験しています。関係部署との連携を通じて、品質と納期の両立を意識した開発を行ってきました。"
    }
  ],
  "optimizedResume": {
    "name": "山田 太郎",
    "role": "バックエンドエンジニア",
    "contact": {
      "phone": "090-1234-5678",
      "email": "yamada.taro@example.com",
      "location": "東京都"
    },
    "sections": {
      "summary": "バックエンドエンジニアとして3年の実務経験を有し、Java／Spring Boot／MySQL／Redis を用いた業務システム開発に従事してきました。基幹業務向け API 開発と性能改善、障害調査・再発防止策の立案を通じて、サービスの安定運用に貢献しています。",
      "experiences": [
        {
          "company": "XXテクノロジー",
          "title": "バックエンドエンジニア",
          "period": "2022.07 - 現在",
          "items": [
            "Spring Boot を用いたユーザー管理システムの設計・開発・保守を担当。認証・認可や例外処理、監査ログなどの共通機能を実装。",
            "高頻度アクセス API のクエリ最適化および Redis キャッシュ導入により、ピーク時レスポンスを最大 40% 改善。",
            "フロントエンド・QA・企画チームと連携し、要件定義からリリースまでのプロセスに継続的に参画。障害発生時の原因調査と再発防止策の実施を担当。"
          ]
        }
      ],
      "projects": [
        {
          "name": "ECサイト注文管理システム",
          "role": "バックエンド開発",
          "items": [
            "注文作成・照会・ステータス更新 API の設計・実装を担当し、既存システムとの連携仕様を調整。",
            "Redis を用いた注文情報キャッシュと DB インデックス最適化により、セール期間中のピークアクセスにも耐えられる性能を実現。",
            "障害対応フローの整備や監視項目の見直しを行い、重大インシデント件数の削減に貢献。"
          ]
        }
      ],
      "skills": [
        "Java",
        "Spring Boot",
        "MySQL",
        "Redis",
        "Git",
        "SQL最適化",
        "障害調査"
      ]
    }
  }
}
```

---

#### 8.2.4 バリデーション・再試行ポリシー（LLM 出力）

- バックエンド側では、LLM のレスポンスを受信後、以下を行う：
  - JSON パース（失敗した場合は 1 回まで再試行）。
  - 必須フィールド（`scores`, `optimizedResume.sections` など）の存在チェック。
  - スコアフィールドが 0〜100 の範囲内か確認し、範囲外の場合はクリップするか再試行を検討。
- 2 回目の呼び出しでも JSON パースに失敗した場合：
  - フロントエンドには「分析に失敗しました。しばらく時間をおいて再度お試しください。」といった汎用エラーを返す。
  - Application Insights に LLM 出力のサマリー（個人情報を含まない範囲で）とともにエラーを記録する。


## 9. 非機能設計

### 9.1 セキュリティ

- 通信は Azure App Service の HTTPS を前提とする。
- ファイルアップロードは最大 5MB、拡張子・Content-Type のホワイトリストチェックを実施。
- 履歴書テキスト・JD テキストなどの個人情報は DB に永続化しない。
- ログにはメールアドレス・電話番号などの個人情報を出力しない（マスクまたは省略）。

### 9.2 ロギング・モニタリング

- Azure Application Insights を利用し、以下をトレースする：
  - API リクエスト／レスポンスのステータス
  - LLM 呼び出し時間、エラー
  - ファイルアップロードのエラー
- LLM の生出力は、個人情報が含まれる可能性があるためそのままは保存せず、要約やエラー種別のみを記録する。

### 9.3 パフォーマンス・スケーラビリティ

- 1 リクエストあたり 5〜15 秒程度の応答時間を許容。
- バックエンドはステートレス設計とし、App Service のスケールアウトで負荷分散できる構成とする。


## 10. 設定・環境変数

Azure App Service / ローカル開発いずれでも、以下の環境変数を使用する。

- `AZURE_OPENAI_ENDPOINT`
- `AZURE_OPENAI_API_KEY`
- `AZURE_OPENAI_DEPLOYMENT_NAME`
- `AZURE_OPENAI_API_VERSION`（必要に応じて）
- `AZURE_STORAGE_CONNECTION_STRING`（Blob 利用時）
- `APPINSIGHTS_CONNECTION_STRING`（Application Insights 利用時）
- `NODE_ENV`（`development` | `production` など）

これらはローカルでは `.env`、本番では Azure App Service の Application Settings または Azure Key Vault 参照で管理する。


