もちろんです。  
以下に、**FastAPI + Vite + React を前提とした frontend / backend 構成版**として、元の requirements をそのまま使いやすい形で**書き換えた版**をまとめます。

必要に応じて、このまま **`requirements.md`** として使えるように、文書形式で整理しています。

---

# ResumePilot Web App Requirements  
## FastAPI + Vite + React 版

本プロジェクトでは、**FastAPI を用いたバックエンド**と、**Vite + React を用いたフロントエンド**で構成される Web アプリケーションを新規開発し、AI 履歴書最適化アシスタントを実現します。  
アプリケーションは **Azure App Service** 上にデプロイし、その他に必要なクラウドサービスもすべて Azure を利用します。

---

## 1. プロジェクト概要（Overview）

- プロダクト名：**ResumePilot**
- ターゲットユーザー：
  - 求職中の個人（特にエンジニア／IT職）
  - キャリアアドバイザー、HR
- 主な目的：
  1. 履歴書（PDF / DOCX / TXT またはテキスト貼り付け）をアップロード
  2. 求人 JD（Job Description）のテキストを入力
  3. AI が履歴書と JD を解析し、以下を返す：
     - スコアリング（総合点、完成度、表現品質、成果の定量化、ATS対応度）
     - JD とのキーワード一致状況
     - 課題診断（Issue）
     - 改善アイデアと要約改善案
     - 最適化後の履歴書プレビュー（文章案）

---

## 2. システム構成・技術スタック（Architecture / Tech Stack）

### 2.1 フロントエンド

- **Vite + React** による SPA（Single Page Application）構成
- 推奨技術：
  - React 18+
  - Vite 5+
  - TypeScript
  - CSS / SCSS / CSS Modules のいずれか
- UI は提供された HTML/CSS のデザインをベースに実装する
  - 見た目は可能な限り近づける
  - ただしコードは新規作成とする
- フロントエンドは API を通じて FastAPI バックエンドと通信する

### 2.2 バックエンド

- **Python 3.11 + FastAPI** による REST API 構成
- 推奨技術：
  - FastAPI
  - Uvicorn / Gunicorn
  - Pydantic
  - Python ライブラリによる PDF / DOCX / TXT テキスト抽出
- Azure OpenAI を呼び出し、履歴書解析・スコアリング・改善提案生成を行う
- ステートレスな API として設計する

### 2.3 デプロイ構成

- **Azure App Service (Linux)** を利用してデプロイする
- デプロイ方式は以下のいずれかとする：
  1. **単一 App Service 構成**
     - FastAPI が API を提供
     - Vite でビルドした React 静的ファイルを FastAPI から配信
  2. **フロント / バック分離構成**
     - React フロントエンドを Azure Static Web Apps または App Service に配置
     - FastAPI API を別 App Service に配置
- 初期 PoC / デモ段階では、**単一 App Service 上で FastAPI + React ビルド済みファイルを同居させる構成を推奨**する

---

## 3. Azure 使用サービス

1. **Azure App Service**
   - Web App (Linux)
   - ランタイム：
     - Python 3.11（FastAPI バックエンド）
   - 必要に応じて Node.js ビルド工程を CI/CD に含める

2. **Azure Storage（Blob Storage）**
   - 用途：
     - 一時的な履歴書ファイルのアップロード保存（PDF / DOCX / TXT）
   - PII を扱うため、短期間で自動削除する設計を想定

3. **Azure OpenAI Service**
   - 用途：
     - JD と履歴書テキストのマッチング・解析
     - スコアリングロジックの一部
     - 改善提案、要約改善案、最適化後履歴書文の生成

4. **（任意）Azure AI Document Intelligence**
   - 用途：
     - PDF / DOCX からのテキスト抽出の精度補強
   - 初期段階では Python ライブラリによる抽出でも可

5. **Azure Application Insights**
   - 用途：
     - API ログ、エラー、トレース、パフォーマンス監視

6. **Azure Key Vault**
   - 用途：
     - Azure OpenAI / Storage 接続情報 / 各種シークレットの管理

---

## 4. 機能要件（Functional Requirements）

---

## 4.1 フロントエンド要件（Vite + React）

### 4.1.1 トップページ / メイン画面

- React SPA として構築する
- 既存 HTML のセクション構成を踏襲する：
  - Topbar（ブランドロゴ・説明）
  - Hero セクション（サービス説明 + デモ指標）
  - メインダッシュボード
    - 左：入力フォーム
    - 右：分析結果表示

### 4.1.2 入力フォームエリア（左パネル）

1. **履歴書アップロード**
   - ドラッグ＆ドロップ / クリックでファイル選択
   - 対応フォーマット：PDF / DOCX / TXT
   - 選択済みファイル名を UI に表示
   - アップロード後、FastAPI の `/api/upload-resume` を呼び出す

2. **履歴書テキスト入力**
   - テキストエリアを用意
   - ユーザーが手入力 / 貼り付けできる
   - ファイルアップロード後、バックエンドで抽出されたテキストを自動反映する

3. **目標職種入力**
   - 単一のテキストフィールド
   - 例：バックエンドエンジニア

4. **求人 JD 入力**
   - 複数行のテキストエリア
   - JD を貼り付けて入力できる

5. **ボタン**
   - 「分析開始」
     - `/api/analyze` を呼び出す
     - ローディング表示を行う
     - 結果受信後、右パネルに反映する
   - 「デモ結果を反映」
     - フロントエンドの固定サンプルデータを画面に表示する
     - バックエンド呼び出し不要

### 4.1.3 ローディング表示

- 「分析結果を生成しています…」を表示
- アニメーションは既存 CSS デザインを参考に実装する
- API レスポンスを受け取るまで表示する

### 4.1.4 ステータスメッセージ

- 分析完了後に成功メッセージを表示
  - 例：「分析が完了しました。」
- エラー時にはユーザーフレンドリーなメッセージを表示
  - 例：「ファイルの読み取りに失敗しました。」
  - 例：「分析処理で問題が発生しました。時間をおいて再度お試しください。」

### 4.1.5 スコアパネル（右上）

- 表示項目：
  - 総合点
  - 完成度
  - 表現品質
  - 成果の定量化
  - ATS対応度
- 0〜100 の整数で表示
- プログレスバーはスコア値に応じて幅を変化させる

### 4.1.6 職種キーワード一致パネル

- JD から抽出されたキーワード一覧をタグで表示
- ステータス別の色分けを行う：
  - `match` → success
  - `partial` → warning
  - `missing` → danger
  - `extra` → primary

### 4.1.7 改善方向パネル

- 改善提案を 3〜5 件表示
- 1件ごとに以下を表示：
  - タイトル
  - 詳細説明

### 4.1.8 課題診断パネル

- 課題リストを表示
- 1件ごとに以下を表示：
  - タイトル
  - 詳細説明

### 4.1.9 要約改善案パネル

- LLM が生成した改善済み自己紹介を 1〜2 件表示
- 200〜400 文字程度の自然な日本語文とする

### 4.1.10 最適化後の履歴書プレビューパネル

- 以下を表示する：
  - ヘッダー（名前、希望ポジション、連絡先）
  - 自己紹介
  - 職務経歴
  - プロジェクト経験
  - スキル一覧
- FastAPI から返される構造化 JSON を React コンポーネントで描画する

### 4.1.11 レスポンシブ対応

- PC / タブレット / スマホに対応する
- 既存 CSS のブレークポイントを参考に再構成する

### 4.1.12 言語

- UI テキストは日本語を基本とする
- コード / コメントは英語でも可

---

## 4.2 バックエンド要件（FastAPI）

### 4.2.1 API 基本方針

- ベース URL：`/api`
- REST API として実装する
- JSON レスポンスを基本とする
- FastAPI の OpenAPI / Swagger UI を有効化してもよい
- バリデーションは Pydantic モデルで行う

---

### 4.2.2 ファイルアップロード API

- **Endpoint**：`POST /api/upload-resume`
- **機能**：
  - multipart/form-data で履歴書ファイルを受信
  - PDF / DOCX / TXT をサーバーサイドでテキスト抽出
  - 必要に応じて Azure Blob Storage に一時保存
- **リクエスト**
  - Form field: `file`
- **バリデーション**
  - 最大ファイルサイズ：1MB
  - 拡張子チェック：`.pdf`, `.docx`, `.txt`
  - Content-Type チェックを実施
- **レスポンス例**
```json
{
  "success": true,
  "extractedText": "ここに抽出された履歴書テキスト...",
  "fileId": "uuid-or-blob-url"
}
```

---

### 4.2.3 解析・スコアリング API

- **Endpoint**：`POST /api/analyze`
- **機能**：
  - 履歴書テキスト + 求人 JD + 目標職種を受け取る
  - Azure OpenAI を使って解析 / スコアリング / 提案生成を行う
  - 結果を構造化 JSON で返す

- **リクエスト Body 例**
```json
{
  "resumeText": "ユーザー貼り付けまたは抽出済み履歴書テキスト",
  "jobTitle": "バックエンドエンジニア",
  "jobDescription": "JDテキスト...",
  "options": {
    "language": "ja"
  }
}
```

- **レスポンス Body 例**
```json
{
  "scores": {
    "total": 82,
    "completeness": 88,
    "expression": 79,
    "quantification": 68,
    "ats": 91,
    "hero": {
      "completeness": 88,
      "match": 82,
      "ats": 91,
      "quant": 68
    }
  },
  "keywords": [
    { "label": "Java", "status": "match" },
    { "label": "Spring Boot", "status": "match" },
    { "label": "MySQL", "status": "match" },
    { "label": "Redis", "status": "match" },
    { "label": "SQL最適化", "status": "partial" },
    { "label": "高負荷処理", "status": "partial" },
    { "label": "マイクロサービス", "status": "missing" },
    { "label": "障害調査", "status": "extra" }
  ],
  "suggestions": [
    {
      "title": "関連スキルの強調",
      "detail": "Java、Spring Boot、MySQL、Redis をスキル欄や職務内容の上部に記載し..."
    }
  ],
  "issues": [
    {
      "title": "成果を示す定量データが不足しています",
      "detail": "現在の記述は『担当』『関与』に留まっており..."
    }
  ],
  "summaryImprovements": [
    {
      "title": "推奨改善例",
      "text": "バックエンドエンジニアとして3年の実務経験を有し..."
    }
  ],
  "optimizedResume": {
    "name": "山田 太郎",
    "role": "バックエンドエンジニア",
    "contact": {
      "phone": "090-1234-5678",
      "email": "yamada.taro@example.com",
      "location": "東京都"
    },
    "sections": {
      "summary": "バックエンドエンジニアとして3年の実務経験を有し...",
      "experiences": [
        {
          "company": "XXテクノロジー",
          "title": "バックエンドエンジニア",
          "period": "2022.07 - 現在",
          "items": [
            "Spring Boot を用いたユーザー管理システムの設計・開発・保守を担当...",
            "高頻度APIの性能改善およびキャッシュ最適化を実施..."
          ]
        }
      ],
      "projects": [
        {
          "name": "ECサイト注文管理システム",
          "role": "バックエンド開発",
          "items": [
            "注文作成・照会・ステータス管理APIの設計および実装を担当...",
            "キャッシュ最適化とAPI安定性向上に取り組み..."
          ]
        }
      ],
      "skills": [
        "Java",
        "Spring Boot",
        "MySQL",
        "Redis",
        "Git",
        "SQL最適化",
        "障害調査"
      ]
    }
  }
}
```

---

### 4.2.4 ヘルスチェック API

- **Endpoint**：`GET /api/health`
- **目的**：
  - App Service 上での稼働確認
  - ロードバランサ・監視用
- **レスポンス例**
```json
{ "status": "ok" }
```

---

### 4.2.5 FastAPI 実装要件

- ルーティングは責務ごとに分割する
  - 例：`upload.py`, `analyze.py`, `health.py`
- Pydantic で入出力スキーマを定義する
- 例外処理を共通化する
- Application Insights または標準 logging を統合する
- 開発環境では CORS を許可し、Vite dev server から API にアクセス可能にする
- 本番環境では React のビルド済み静的ファイルを FastAPI 側で配信してもよい

---

## 5. AI ロジック要件（Azure OpenAI 等）

### 入力

- 履歴書テキスト
- 求人 JD テキスト
- 目標職種

### 出力要件

1. **スコアリング**
   - 0〜100 の整数値
   - LLM 評価 + ルールベース補正で算出
   - 項目：
     - 総合点
     - 完成度
     - 表現品質
     - 成果の定量化
     - ATS対応度

2. **キーワード抽出**
   - JD から主要キーワード（スキル・経験・役割）を抽出
   - 履歴書との一致状況を分類
     - match
     - partial
     - missing
     - extra

3. **改善提案**
   - タイトル + 詳細説明の形式
   - 3〜5 件程度返す

4. **課題診断**
   - 不足点・懸念点を 2〜5 件返す

5. **要約改善案**
   - 日本語 200〜400 文字程度
   - 1〜2 件返す

6. **最適化後履歴書**
   - JSON 構造で返す
   - React フロントエンドでそのまま描画できる形式とする

### 実装上の方針

- Azure OpenAI のレスポンスは JSON 形式で安定出力させる
- 必要に応じてプロンプトでスキーマ制約を与える
- LLM の出力が不正な場合はバックエンドで補正 / パース失敗時リトライを行う
- ユーザー入力や PII をログに出力しない

---

## 6. 非機能要件（Non-functional Requirements）

### 6.1 セキュリティ

- HTTPS を強制する
- ファイルアップロードサイズ制限：最大 1MB
- 拡張子 / Content-Type チェックを実施する
- Azure OpenAI / Storage のキーは環境変数または Key Vault で管理する
- 個人情報は永続 DB に保存しない
- ログには氏名、電話番号、メールアドレス等の PII を含めない

### 6.2 パフォーマンス

- 1 回の解析リクエストの許容時間：5〜15 秒程度
- 初期は少数同時接続を想定
- FastAPI 側で非同期 I/O を活用できる設計とする

### 6.3 ロギング・モニタリング

- Application Insights に以下を記録する
  - API リクエスト / レスポンスステータス
  - エラー / 例外
  - Azure OpenAI 呼び出し時間
  - ファイル抽出処理時間
- フロントエンドの重大エラーも必要に応じて収集する

### 6.4 スケーラビリティ

- 初期は単一インスタンスで運用
- 将来的に App Service のスケールアウトが可能な構成とする
- バックエンドはステートレスであること

---

## 7. 開発・構成要件

### 7.1 開発環境

- フロントエンド：Vite 開発サーバー
- バックエンド：FastAPI + Uvicorn
- `.env` または Azure App Settings で以下を管理する

```env
AZURE_OPENAI_ENDPOINT=
AZURE_OPENAI_API_KEY=
AZURE_OPENAI_DEPLOYMENT_NAME=
AZURE_STORAGE_CONNECTION_STRING=
APPLICATIONINSIGHTS_CONNECTION_STRING=
FRONTEND_DIST_PATH=
```

### 7.2 フロントエンド / バックエンド連携

- 開発時：
  - React（Vite）: `http://localhost:5173`
  - FastAPI: `http://localhost:8000`
- Vite の proxy または API ベース URL 設定で `/api` を FastAPI に転送する
- 本番時：
  - React ビルド成果物を FastAPI から配信するか
  - フロント / API を別 App Service に分離する

### 7.3 ビルド & デプロイ

- フロントエンド：
  - `npm install`
  - `npm run build`
- バックエンド：
  - `pip install -r requirements.txt`
- 単一 App Service 構成の場合：
  - React のビルド済み `dist/` を FastAPI から配信する
- `kiro-cli` により生成されたプロジェクトを Azure App Service にデプロイできる構成とする

### 7.4 Docker サポート（任意）

- Docker / Docker Compose を用いたローカル起動をサポートしてもよい
- 例：
  - `frontend` コンテナ
  - `backend` コンテナ

---

### 7.5 テスト

- バックエンド：
  - `pytest` による API テストを実装する
  - 最低限、以下を含む：
    - happy path
    - error path
  - 対象例：
    - `GET /api/health` が正常に `200` を返す
    - `POST /api/upload-resume` に TXT ファイルを送信した場合、抽出テキストが返る
    - `POST /api/upload-resume` に未対応形式ファイルを送信した場合、`400` を返す
    - `POST /api/analyze` に必要項目が揃っている場合、期待する JSON 構造を返す
    - `POST /api/analyze` に空の履歴書テキストや JD を送信した場合、バリデーションエラーを返す

- フロントエンド：
  - `Vitest` + `React Testing Library` によるコンポーネントテストを実装する
  - 最低限、以下を含む：
    - 入力フォームの描画確認
    - ファイル選択時にファイル名が表示されること
    - 「分析開始」クリック時にローディング表示が出ること
    - API 成功時にスコアパネルや提案パネルへ結果が反映されること
    - API エラー時にユーザーフレンドリーなエラーメッセージが表示されること

- E2E テスト（任意）：
  - `Playwright` を用いて以下の主要導線を確認できると望ましい
    - トップ画面表示
    - 履歴書アップロード
    - JD 入力
    - 分析開始
    - 結果表示
    - デモ結果表示

---

### 7.6 想定ディレクトリ構成

```text
resume-pilot/
├─ backend/
│  ├─ app/
│  │  ├─ api/
│  │  │  ├─ routes/
│  │  │  │  ├─ health.py
│  │  │  │  ├─ upload.py
│  │  │  │  └─ analyze.py
│  │  │  └─ deps.py
│  │  ├─ core/
│  │  │  ├─ config.py
│  │  │  ├─ logging.py
│  │  │  └─ security.py
│  │  ├─ models/
│  │  │  ├─ request.py
│  │  │  └─ response.py
│  │  ├─ services/
│  │  │  ├─ openai_service.py
│  │  │  ├─ storage_service.py
│  │  │  ├─ document_parser.py
│  │  │  └─ scoring_service.py
│  │  ├─ utils/
│  │  │  └─ text_utils.py
│  │  └─ main.py
│  ├─ tests/
│  │  ├─ test_health.py
│  │  ├─ test_upload.py
│  │  └─ test_analyze.py
│  ├─ requirements.txt
│  └─ Dockerfile
│
├─ frontend/
│  ├─ src/
│  │  ├─ api/
│  │  │  └─ client.ts
│  │  ├─ components/
│  │  │  ├─ layout/
│  │  │  ├─ form/
│  │  │  ├─ panels/
│  │  │  └─ common/
│  │  ├─ pages/
│  │  │  └─ Home.tsx
│  │  ├─ hooks/
│  │  │  └─ useAnalyze.ts
│  │  ├─ types/
│  │  │  └─ api.ts
│  │  ├─ data/
│  │  │  └─ demoResult.ts
│  │  ├─ styles/
│  │  │  └─ global.css
│  │  ├─ App.tsx
│  │  └─ main.tsx
│  ├─ public/
│  ├─ tests/
│  ├─ package.json
│  ├─ vite.config.ts
│  └─ Dockerfile
│
├─ infra/
│  ├─ azure/
│  │  ├─ appservice.md
│  │  └─ appsettings.example.json
│
├─ .env.example
├─ docker-compose.yml
└─ README.md
```

---

### 7.7 フロントエンド実装要件（Vite + React）

1. **フレームワーク / 言語**
   - `React 18+`
   - `Vite`
   - `TypeScript`

2. **状態管理**
   - 初期段階では React 標準の `useState` / `useReducer` / `Context` ベースでも可
   - 必要に応じて `Zustand` 等の軽量 state management library を採用してもよい

3. **API 通信**
   - `fetch` または `axios` を利用
   - API ベース URL は `.env` で管理する
   - 例：
     - `VITE_API_BASE_URL=/api`

4. **UI 実装**
   - 提供された HTML/CSS を参考に、React コンポーネントとして再構築する
   - デザインは極力近づけるが、コードは新規実装とする
   - 再利用可能なコンポーネントに分割すること
     - `Topbar`
     - `HeroSection`
     - `ResumeUpload`
     - `ResumeTextArea`
     - `JobDescriptionInput`
     - `ScorePanel`
     - `KeywordPanel`
     - `SuggestionsPanel`
     - `IssuesPanel`
     - `SummaryPanel`
     - `OptimizedResumePreview`

5. **フォームバリデーション**
   - 分析開始前に以下をチェックする
     - 履歴書テキストが空でないこと
     - JD が空でないこと
     - 文字数が極端に短すぎないこと
   - エラーメッセージは日本語で分かりやすく表示する

6. **デモモード**
   - バックエンドに接続しなくても、固定 JSON を使って UI を動作確認できるようにする
   - デザイナーや非技術ユーザー向けの確認用途として活用可能

---

### 7.8 バックエンド実装要件（FastAPI）

1. **フレームワーク / 言語**
   - `Python 3.11`
   - `FastAPI`
   - `Uvicorn`

2. **API 設計**
   - REST API として実装する
   - エンドポイントは `/api` 配下に集約する
   - OpenAPI / Swagger UI を FastAPI 標準機能で利用可能とする
     - `/docs`
     - `/openapi.json`

3. **バリデーション**
   - `Pydantic` による request / response schema を定義する
   - 不正リクエストには `422` または `400` を返す

4. **ファイル処理**
   - アップロード時に以下を確認する
     - 拡張子
     - MIME type
     - ファイルサイズ
   - 抽出対応形式：
     - PDF
     - DOCX
     - TXT
   - 使用候補ライブラリ：
     - PDF: `pypdf`
     - DOCX: `python-docx`
     - TXT: Python 標準処理
   - 精度不足時は Azure AI Document Intelligence の利用を拡張可能にしておく

5. **AI 連携**
   - Azure OpenAI 呼び出しは service 層に切り出す
   - Prompt はハードコードしすぎず、保守しやすい形で管理する
   - JSON 出力を安定させるため、可能な限り structured output を利用する
   - LLM 応答が不正 JSON の場合は、サーバー側で再試行またはフォールバック処理を行う

6. **スコアリング補助ロジック**
   - LLM 任せにせず、簡易ルールベース評価を併用してよい
   - 例：
     - 数値表現（% / 件数 / 金額 / 期間）が少ない場合、quantification を減点
     - JD キーワードの含有率に応じて ATS / match を補正
     - セクション不足（summary, skills, experiences など）がある場合、completeness を補正

7. **例外処理**
   - ユーザー向けには過度に技術的でないエラー文言を返す
   - 内部ログには詳細スタックトレースを残す
   - PII をログに出力しないこと

---

### 7.9 環境変数・設定値

以下の設定値を `.env`、Azure App Settings、または Key Vault 経由で管理する。

```env
# Backend
APP_ENV=development
APP_NAME=ResumePilot API
APP_HOST=0.0.0.0
APP_PORT=8000
CORS_ORIGINS=http://localhost:5173

# Azure OpenAI
AZURE_OPENAI_ENDPOINT=
AZURE_OPENAI_API_KEY=
AZURE_OPENAI_DEPLOYMENT_NAME=
AZURE_OPENAI_API_VERSION=

# Azure Storage
AZURE_STORAGE_CONNECTION_STRING=
AZURE_STORAGE_CONTAINER_NAME=resumes-temp

# Application Insights
APPLICATIONINSIGHTS_CONNECTION_STRING=

# Optional
AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT=
AZURE_DOCUMENT_INTELLIGENCE_KEY=
```

フロントエンド用 `.env` 例：

```env
VITE_API_BASE_URL=http://localhost:8000/api
VITE_APP_NAME=ResumePilot
```

---

### 7.10 ビルド & デプロイ要件

1. **ローカル開発**
   - フロントエンド：
     - `npm install`
     - `npm run dev`
   - バックエンド：
     - `pip install -r requirements.txt`
     - `uvicorn app.main:app --reload --port 8000`

2. **本番ビルド**
   - フロントエンドは `vite build` により静的ファイルを生成する
   - 配置方法は以下のいずれかとする
     - **方式A：前後端分離**
       - React は Azure App Service（Static Web 配信構成）または別 Web App で配信
       - FastAPI は Azure App Service で API として配信
     - **方式B：同一 App Service**
       - React の build 結果を FastAPI 側から静的配信する
       - PoC ではこの方式でも可

3. **Azure App Service 配備**
   - Linux App Service を利用する
   - Python ランタイム対応構成とする
   - 起動コマンド例：
     ```bash
     gunicorn -k uvicorn.workers.UvicornWorker app.main:app
     ```

4. **CI/CD（任意）**
   - GitHub Actions により以下を自動化可能とする
     - テスト
     - フロントエンド build
     - バックエンド package
     - Azure App Service デプロイ

---

### 7.11 ロギング・監視

1. **アプリケーションログ**
   - FastAPI の request / response ログを記録する
   - エラーログを記録する
   - LLM 呼び出し時間を trace として記録する

2. **Application Insights**
   - API 成功率
   - レスポンスタイム
   - 例外件数
   - 外部依存呼び出し時間（Azure OpenAI など）
   を可視化する

3. **PII 保護**
   - 履歴書本文、氏名、電話番号、メールアドレス等をログへ出力しない
   - 必要な場合はマスキングして記録する

---

## 8. 制約・備考

- 提供された HTML/CSS は **デザイン参考** として扱い、**React コンポーネントとして新規実装**すること
- 初期リリースではユーザー認証は不要
- DB 永続化は行わず、**履歴書データおよび解析テキストは処理後に保持しない方針**とする
- 一時ファイルを Azure Blob Storage に保存する場合は、**短期間で削除される運用**を前提とし、将来的に **ライフサイクル管理ルール** を適用できる構成とする
- ログ出力時には、**氏名・電話番号・メールアドレス・履歴書本文・JD本文などの個人情報／機微情報を記録しない**
- Azure OpenAI への送信内容については、PoC 段階でも **最小限必要なテキストのみ送る設計** とし、不要なメタデータは含めない
- App Service 上では、**フロントエンドのビルド成果物を FastAPI から配信する構成**、または **フロントエンド／バックエンドを別 App Service とする構成** のいずれにも将来的に移行しやすいディレクトリ構成にする
- 初期段階では Azure AI Document Intelligence は任意とし、まずは Python ライブラリによる PDF / DOCX / TXT 抽出を優先する
- ファイル抽出精度や LLM 応答品質にはばらつきがあるため、UI 上で「参考結果」である旨の補足表示を行ってもよい
- 本要件は **PoC / デモ向けの初期版** を主対象とし、本番運用時には以下の拡張を別途検討する：
  - ユーザー認証・認可
  - 利用履歴管理
  - 履歴書バージョン管理
  - 管理者向けモニタリング画面
  - 非同期ジョブ化
  - レート制限
  - 監査ログ
  - PII マスキング強化

---

## 9. 推奨ディレクトリ構成（FastAPI + Vite + React）

```text
resume-pilot/
├─ backend/
│  ├─ app/
│  │  ├─ api/
│  │  │  ├─ routes/
│  │  │  │  ├─ health.py
│  │  │  │  ├─ upload.py
│  │  │  │  └─ analyze.py
│  │  │  └─ deps.py
│  │  ├─ core/
│  │  │  ├─ config.py
│  │  │  ├─ logging.py
│  │  │  └─ security.py
│  │  ├─ models/
│  │  │  ├─ requests.py
│  │  │  └─ responses.py
│  │  ├─ services/
│  │  │  ├─ file_extractor.py
│  │  │  ├─ blob_storage.py
│  │  │  ├─ openai_service.py
│  │  │  └─ analysis_service.py
│  │  ├─ utils/
│  │  │  ├─ pii.py
│  │  │  └─ text.py
│  │  └─ main.py
│  ├─ tests/
│  │  ├─ test_health.py
│  │  ├─ test_upload.py
│  │  └─ test_analyze.py
│  ├─ requirements.txt
│  └─ pyproject.toml
│
├─ frontend/
│  ├─ src/
│  │  ├─ api/
│  │  │  └─ client.ts
│  │  ├─ components/
│  │  │  ├─ layout/
│  │  │  ├─ forms/
│  │  │  ├─ dashboard/
│  │  │  └─ common/
│  │  ├─ pages/
│  │  │  └─ Home.tsx
│  │  ├─ types/
│  │  │  └─ api.ts
│  │  ├─ hooks/
│  │  │  └─ useAnalyze.ts
│  │  ├─ styles/
│  │  │  └─ globals.css
│  │  ├─ App.tsx
│  │  └─ main.tsx
│  ├─ public/
│  ├─ package.json
│  ├─ tsconfig.json
│  └─ vite.config.ts
│
├─ deployment/
│  ├─ startup.sh
│  └─ azure-appservice.md
│
├─ .env.example
├─ .gitignore
├─ README.md
└─ Dockerfile
```

---

## 10. 実装方針メモ

### 10.1 フロントエンド実装方針
- **React + Vite + TypeScript** を推奨
- 画面は基本的に **1ページ構成のダッシュボード** とし、入力と結果を同一画面で完結させる
- 状態管理は初期段階では `useState` / `useReducer` / `React Query` 程度の軽量構成で十分
- API 通信は `fetch` または `axios`
- デモ結果表示はフロントエンド内の固定 JSON で実装可能
- 既存 HTML/CSS はレイアウト参考とし、コンポーネント分割を行う

### 10.2 バックエンド実装方針
- **FastAPI** により REST API を実装
- Pydantic モデルでリクエスト／レスポンスのバリデーションを行う
- `/api/upload-resume` でファイル受信とテキスト抽出
- `/api/analyze` で Azure OpenAI を呼び出し、構造化 JSON を返す
- OpenAI 応答の JSON フォーマット崩れに備えて、**パース失敗時のフォールバック処理** を実装する
- 分析ロジックは以下のハイブリッド構成を推奨：
  - ルールベース：文字数、定量表現、見出し有無、キーワード出現数
  - LLM ベース：改善提案、課題診断、要約改善、最適化履歴書生成

### 10.3 Azure 連携方針
- **Azure App Service (Linux)** 上で FastAPI を起動
- フロントエンドは Vite build 後の `dist` を配信対象とする
- 一時ファイル保存が必要な場合のみ **Azure Blob Storage** を使用
- **Application Insights** を有効化し、主要 API の成功率・応答時間・例外を可視化
- 機密情報は **App Settings** または **Key Vault** から取得する

---

## 11. 今後の拡張候補

- ログイン機能（Azure AD B2C / Entra External ID 等）
- 履歴書の複数バージョン保存
- JD ごとの比較分析
- 分析履歴一覧
- 多言語対応（日本語 / 英語）
- Word / PDF エクスポート
- ストリーミングレスポンスによる段階表示
- バックグラウンドジョブ化（Celery / Azure Functions / Queue 連携）
- 管理画面および運用ダッシュボード
- AI 出力のフィードバック学習用仕組み

---