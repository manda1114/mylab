可以，下面我把你的方案**改成「FastAPI + Vite + React 的前后端分离形式」**，并尽量保持原方案的可执行性。

我会直接按**“修改后的方案书”**来写，你可以拿这个继续细化成开发文档。

---

# AI 简历优化助手 MVP 方案（FastAPI + Vite + React 版）

下面是一份**适合直接开工的前后端分离 MVP 方案**，技术栈调整为：

- **Frontend**：Vite + React
- **Backend**：FastAPI
- **UI 展示语言**：日语
- **后续可部署到 Azure**

---

# 一、MVP 目标定义

先聚焦最小可用版本，不要一开始做太复杂。  
本 MVP 只解决以下 4 个核心问题：

## MVP 功能范围

### 1. 上传或粘贴简历
- 支持 PDF / DOCX / TXT
- 支持直接粘贴文本

### 2. 输入目标岗位 JD
- 用户粘贴职位描述
- 或输入岗位名称 + 职责要求

### 3. 输出简历分析结果
- 简历结构化解析
- 核心问题识别
- 岗位匹配分析
- 简历评分

### 4. 生成优化版本
- 输出整体优化版
- 支持按模块改写：
  - 自我介绍 / 自己PR
  - 工作经历
  - 项目经历
  - 技能说明

---

# 二、MVP 用户流程

```text
[Frontend: Vite + React]
用户上传简历 / 粘贴简历文本
        ↓
调用 Backend 上传接口
        ↓
[Backend: FastAPI]
提取纯文本
        ↓
LLM + 规则完成结构化解析
        ↓
用户输入目标岗位 JD
        ↓
系统提取 JD 关键词与要求
        ↓
系统计算匹配度 + 简历评分
        ↓
LLM 生成优化建议与改写结果
        ↓
[Frontend 展示（日语 UI）]
- スコア
- 問題点一覧
- 改善提案
- 最適化済み履歴書プレビュー
```

---

# 三、推荐技术栈

## 1. Frontend
- **Vite**
- **React**
- **TypeScript**
- **Tailwind CSS**
- **React Router**
- **Axios**
- 可选：
  - **Zustand**（轻量状态管理）
  - **React Hook Form**（表单处理）

### 选择理由
- Vite 启动快、构建快，适合 MVP
- React 生态成熟，适合文件上传、表单、结果展示页
- TypeScript 有助于与后端 API 类型对齐
- 前后端分离更利于后续部署和扩展

---

## 2. Backend
- **Python**
- **FastAPI**
- **Pydantic**
- **SQLAlchemy**
- **Uvicorn**

### 选择理由
- FastAPI 非常适合：
  - 文件上传
  - 文本解析
  - 调用 LLM
  - 自动生成 OpenAPI 文档
- Pydantic 适合做 JSON 输出校验，减少 LLM 返回异常

---

## 3. 文件解析
- PDF：`pdfplumber` / `PyMuPDF`
- DOCX：`python-docx`
- TXT：直接读取
- 可选 OCR：`PaddleOCR`

---

## 4. 数据库
MVP 建议：
- **SQLite**（本地开发）
- 或 **PostgreSQL**（上线）

---

## 5. 缓存 / 异步
MVP 初期可先不加  
后续可加：
- Redis
- Celery / RQ

---

## 6. 大模型
建议先只接一个模型，减少复杂度：
- OpenAI
- Claude
- Azure OpenAI（后续上 Azure 时更自然）

---

## 7. UI 语言
- **网站前端展示语言：日语**
- 后端内部数据可继续用英文 key，方便开发

---

# 四、系统架构设计（前后端分离）

```text
[Frontend - Vite + React]
  ├─ 履歴書アップロード画面
  ├─ JD入力画面
  ├─ 分析結果表示画面
  ├─ 改善後履歴書プレビュー画面
  └─ API Client（Axios）

            ↓ HTTP / JSON / multipart/form-data

[Backend - FastAPI]
  ├─ Resume Upload API
  ├─ Resume Parse API
  ├─ JD Analyze API
  ├─ Resume Score API
  ├─ Rewrite API
  └─ Result History API

[Storage / DB]
  ├─ SQLite / PostgreSQL（结构化数据）
  ├─ Local Storage / Azure Blob Storage（原始文件）
  └─ Azure OpenAI / OpenAI API（LLM）
```

---

# 五、前端模块设计（新增）

相比原方案，这里需要补充前端模块设计，因为现在是 **Vite + React** 的独立 frontend。

## 1. 页面结构建议

### 页面 1：简历上传页
功能：
- 文件上传
- 或文本粘贴
- 上传后显示提取结果预览

### 页面 2：JD 输入页
功能：
- 输入岗位名称
- 粘贴 JD 文本
- 提交进行分析

### 页面 3：分析结果页
功能：
- 展示总分
- 各维度评分
- 问题列表
- 改进建议
- JD 匹配关键词

### 页面 4：优化结果页
功能：
- 展示优化后的简历内容
- 支持按模块切换
- 支持复制 / 导出

---

## 2. React 组件建议

```text
src/
├─ pages/
│  ├─ UploadPage.tsx
│  ├─ JdPage.tsx
│  ├─ AnalysisPage.tsx
│  └─ RewritePage.tsx
├─ components/
│  ├─ Layout.tsx
│  ├─ FileUploader.tsx
│  ├─ TextInputCard.tsx
│  ├─ ScoreCard.tsx
│  ├─ ProblemsList.tsx
│  ├─ SuggestionList.tsx
│  ├─ ResumePreview.tsx
│  └─ LoadingSpinner.tsx
├─ services/
│  └─ api.ts
├─ store/
│  └─ useResumeStore.ts
├─ types/
│  └─ api.ts
└─ utils/
   └─ format.ts
```

---

## 3. 前端状态建议

建议在前端缓存以下数据：
- `resumeId`
- `jdId`
- `analysisId`
- `rewriteId`
- `rawText`
- `parsedResume`
- `parsedJd`
- `analysisResult`
- `rewriteResult`

MVP 可以先用：
- `useState`
- 或 `Zustand`

---

# 六、MVP 核心模块拆分

---

## 1. Resume Parser（简历解析模块）

### 输入
- PDF / DOCX / TXT / 纯文本

### 输出
- 原始文本
- 简历结构化 JSON

### 职责
- 文本提取
- 段落清洗
- 标题识别
- 结构化抽取

---

## 2. JD Analyzer（岗位分析模块）

### 输入
- JD 文本

### 输出
- 岗位名
- 核心技能
- 软技能
- 学历要求
- 工作年限
- 关键词列表

---

## 3. Resume Scorer（评分模块）

### 输入
- 结构化简历
- JD 分析结果

### 输出
- 总分
- 各维度评分
- 问题列表
- 改进建议

### 评分维度
- 完整度
- 表达质量
- 成果量化
- 岗位匹配度
- ATS 友好度

---

## 4. Rewriter（改写模块）

### 输入
- 原始简历结构
- JD 分析
- 问题列表

### 输出
- 优化版简历文本
- 分段改写建议
- 不同风格版本（后续可扩展）

---

# 七、数据库设计

数据库表结构可以沿用原方案，基本无需变化。

## 1. resumes 表

```sql
CREATE TABLE resumes (
    id TEXT PRIMARY KEY,
    user_id TEXT,
    file_name TEXT,
    file_type TEXT,
    raw_text TEXT,
    parsed_json TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## 2. job_descriptions 表

```sql
CREATE TABLE job_descriptions (
    id TEXT PRIMARY KEY,
    resume_id TEXT,
    title TEXT,
    raw_text TEXT,
    parsed_json TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## 3. analysis_results 表

```sql
CREATE TABLE analysis_results (
    id TEXT PRIMARY KEY,
    resume_id TEXT,
    jd_id TEXT,
    total_score INTEGER,
    completeness_score INTEGER,
    expression_score INTEGER,
    quantification_score INTEGER,
    match_score INTEGER,
    ats_score INTEGER,
    problems_json TEXT,
    suggestions_json TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## 4. rewrites 表

```sql
CREATE TABLE rewrites (
    id TEXT PRIMARY KEY,
    resume_id TEXT,
    jd_id TEXT,
    rewrite_type TEXT,
    content TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

# 八、统一数据结构设计

前后端分离后，**统一 API 数据结构**更重要。  
建议前后端都基于同一套 schema 设计。

---

## 1. 简历结构化 JSON 示例

```json
{
  "basic_info": {
    "name": "张三",
    "phone": "13800000000",
    "email": "test@test.com",
    "location": "上海"
  },
  "summary": "3年后端开发经验，熟悉Java、Spring Boot、MySQL。",
  "education": [
    {
      "school": "XX大学",
      "degree": "本科",
      "major": "计算机科学与技术",
      "start_date": "2018-09",
      "end_date": "2022-06"
    }
  ],
  "work_experience": [
    {
      "company": "XX科技",
      "title": "后端开发工程师",
      "start_date": "2022-07",
      "end_date": "至今",
      "responsibilities": [
        "负责用户中心模块开发",
        "参与接口性能优化"
      ],
      "achievements": [
        "接口响应时间降低30%"
      ]
    }
  ],
  "projects": [
    {
      "name": "推荐系统项目",
      "role": "后端开发",
      "description": [
        "负责推荐服务接口开发",
        "参与召回策略优化"
      ],
      "results": [
        "CTR 提升12%"
      ]
    }
  ],
  "skills": [
    "Java",
    "Spring Boot",
    "MySQL",
    "Redis"
  ],
  "certificates": []
}
```

---

## 2. JD 结构化 JSON 示例

```json
{
  "job_title": "数据分析师",
  "required_skills": ["Python", "SQL", "数据分析", "A/B Test", "Tableau"],
  "preferred_skills": ["机器学习", "埋点设计"],
  "soft_skills": ["沟通能力", "跨团队协作"],
  "education_requirement": "本科及以上",
  "experience_requirement": "2年以上",
  "keywords": ["Python", "SQL", "分析", "实验设计", "可视化"]
}
```

---

# 九、接口设计

接口设计基本延续原方案，但在前后端分离场景下要明确：
- 前端通过 Axios 调用
- Backend 要开启 CORS
- 文件上传使用 `multipart/form-data`

---

## 1. 上传简历

### `POST /api/v1/resumes/upload`

#### 请求方式
`multipart/form-data`

#### 参数
- `file`: 简历文件（pdf/docx/txt）

#### 返回
```json
{
  "resume_id": "resume_001",
  "file_name": "zhangsan_resume.pdf",
  "raw_text": "提取后的简历文本..."
}
```

---

## 2. 粘贴简历文本

### `POST /api/v1/resumes/text`

#### 请求体
```json
{
  "text": "张三 ... 简历全文"
}
```

#### 返回
```json
{
  "resume_id": "resume_002",
  "raw_text": "张三 ... 简历全文"
}
```

---

## 3. 解析简历

### `POST /api/v1/resumes/{resume_id}/parse`

#### 返回
```json
{
  "resume_id": "resume_001",
  "parsed_resume": {
    "basic_info": {},
    "education": [],
    "work_experience": [],
    "projects": [],
    "skills": []
  }
}
```

---

## 4. 提交 JD

### `POST /api/v1/jds`

#### 请求体
```json
{
  "resume_id": "resume_001",
  "title": "后端开发工程师",
  "jd_text": "岗位职责：负责后端服务开发..."
}
```

#### 返回
```json
{
  "jd_id": "jd_001",
  "parsed_jd": {
    "job_title": "后端开发工程师",
    "required_skills": ["Java", "Spring Boot", "MySQL"],
    "keywords": ["高并发", "微服务", "接口设计"]
  }
}
```

---

## 5. 分析简历与 JD 匹配度

### `POST /api/v1/analysis`

#### 请求体
```json
{
  "resume_id": "resume_001",
  "jd_id": "jd_001"
}
```

#### 返回
```json
{
  "analysis_id": "analysis_001",
  "scores": {
    "total": 78,
    "completeness": 85,
    "expression": 74,
    "quantification": 60,
    "match": 82,
    "ats": 88
  },
  "problems": [
    "项目经历中量化成果较少",
    "JD中要求的微服务经验体现不足",
    "技能区提到 Redis，但工作经历中缺少实际应用描述"
  ],
  "suggestions": [
    "补充高并发场景下的优化经验",
    "增强项目结果描述，如响应时间、吞吐量、成本节省等",
    "在工作经历中体现 Spring Cloud / 微服务相关实践"
  ]
}
```

---

## 6. 生成优化版简历

### `POST /api/v1/rewrites`

#### 请求体
```json
{
  "resume_id": "resume_001",
  "jd_id": "jd_001",
  "rewrite_mode": "full"
}
```

#### `rewrite_mode` 可选值
- `full`
- `summary`
- `work_experience`
- `projects`

#### 返回
```json
{
  "rewrite_id": "rw_001",
  "content": {
    "summary": "3年后端开发经验，熟悉 Java、Spring Boot、MySQL、Redis，具备高并发系统接口设计与性能优化实践经验。",
    "work_experience": [
      {
        "company": "XX科技",
        "title": "后端开发工程师",
        "optimized_descriptions": [
          "负责用户中心核心模块开发与维护，基于 Spring Boot 完成接口设计、权限控制及异常治理。",
          "针对高频接口进行 SQL 与缓存优化，接口平均响应时间降低 30%。"
        ]
      }
    ]
  }
}
```

---

## 7. 获取历史结果

### `GET /api/v1/resumes/{resume_id}/result`

#### 返回
```json
{
  "resume_id": "resume_001",
  "parsed_resume": {},
  "jd": {},
  "analysis": {},
  "rewrite": {}
}
```

---

# 十、前后端联调约定

这是改成 Vite + React 之后特别需要加的一节。

## 1. API Base URL
开发环境建议：

- Frontend: `http://localhost:5173`
- Backend: `http://localhost:8000`

前端统一通过环境变量调用：

```env
VITE_API_BASE_URL=http://localhost:8000
```

---

## 2. CORS 设置
FastAPI 需要允许前端域名访问：

```python
from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

---

## 3. 错误响应格式建议

前后端约定统一错误格式，便于 React 展示：

```json
{
  "error": {
    "code": "INVALID_FILE_TYPE",
    "message": "Unsupported file type"
  }
}
```

---

## 4. Loading / Empty / Error 状态
前端页面要统一处理：
- `loading`
- `success`
- `empty`
- `error`

否则用户体验会很差。

---

# 十一、评分逻辑设计

评分逻辑保持原思路：  
**规则引擎为主，LLM 做解释与补充建议。**

## 评分公式示例

```text
总分 = 完整度*0.2 + 表达质量*0.2 + 成果量化*0.2 + 岗位匹配度*0.3 + ATS友好度*0.1
```

---

## 1. 完整度评分
检查是否包含：
- 基本信息
- 教育经历
- 工作经历 / 项目经历
- 技能

---

## 2. 表达质量评分
检查：
- 是否有大量空泛动词
- 是否表述模糊
- 是否重复

---

## 3. 成果量化评分
检测数字、百分比、规模、时间、成本等表达：

```python
r"\d+%|\d+万|\d+天|\d+小时|\d+个"
```

---

## 4. 岗位匹配度评分
比较：
- JD 关键词
- 简历技能词
- 工作经历和项目描述中的关键词覆盖

---

## 5. ATS 友好度评分
检查：
- 联系方式是否清晰
- 标题是否标准
- 技能区是否明确
- 是否过多特殊符号
- 文本是否可提取

---

# 十二、Prompt 设计示例

这一部分可以基本沿用原方案，前后端分离不会影响 Prompt。

## 1. 简历结构化解析 Prompt

```text
你是一名专业的简历解析助手。

任务：
请将下面的简历文本解析为结构化 JSON。

要求：
1. 严格基于原文提取，不得虚构信息。
2. 如果某项信息不存在，返回空字符串或空数组。
3. 输出字段包括：
   - basic_info: name, phone, email, location
   - summary
   - education[]
   - work_experience[]
   - projects[]
   - skills[]
   - certificates[]
4. 只输出 JSON，不要输出任何解释。

简历文本如下：
{{resume_text}}
```

---

## 2. JD 解析 Prompt

```text
你是一名资深招聘顾问。

任务：
请从以下职位描述中提取结构化岗位要求信息。

输出字段：
- job_title
- required_skills[]
- preferred_skills[]
- soft_skills[]
- education_requirement
- experience_requirement
- keywords[]

要求：
1. 不要遗漏关键技能词。
2. 关键词尽量简洁、标准化。
3. 只输出 JSON，不要输出解释。

职位描述如下：
{{jd_text}}
```

---

## 3.