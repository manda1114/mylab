# coding-agent-hands-on

- コーディングエージェント codexを使ってweb appを作成するハンズオン用リポジトリです。
- FastAPI + Vite + React で frontend / backend 構成の web app を作成します。
- Azure OpenAIアクセス用、FastAPIのapiは作成済

## ローカル開発

1. kbtt環境の個人VMで実施する
2. リポジトリクローン
```
git clone https://github.com/JPXITBusiness/coding-agent-hands-on.git
cd coding-agent-hands-on
# 個人作業用ブランチ作成
git branch <個人名>
git switch <個人名>
# 作業branch確認
git branch
```
## codex agent環境設定
- kbtt環境の個人VMで実施する

```
# nodeバージョン確認
$ node -v # 22.12以上
# nodeがインストールされていない場合は別途インストールが必要
[最新版nodeインストール手順](https://qiita.com/nouernet/items/d6ad4d5f4f08857644de)

sudo npm install -g @openai/codex mkdir ~/.codex
.codex/config.toml
export AZURE_OPENAI_API_KEY='xxxxx' # config.toml endpointのkeyを使用する
# Project DIRで
cd coding-agent-hands-on
code .
# 新しいVSCodeのwindowで接続チェック
codex "hello"
# VSCodeのショートカット Ctr + J 無効化

Ctr+ shift+p でコマンドパレットを開く。
ctrl+jを検索=>無効化
```
## uv インストール
```
# 確認
uv --version
# install
curl -LsSf https://astral.sh/uv/install.sh | sh
uv --version
```
## taskfile インストール
```
# 確認
task --version
# install
sh -c "$(curl --location https://taskfile.dev/install.sh)" -- -d -b ~/.local/bin
# path設定、path反映
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc
```

## 環境構成
- backend: FastAPI
- frontend: Vite + React + Tailwind
- サンプル実装:
  - Azure OpenAI チャット API
  - Azure Blob Storage テキスト Blob API
- 本番想定: frontend をビルドして FastAPI から同一コンテナ配信

## ディレクトリ構成

- `backend/`: FastAPI API
- `frontend/`: Vite + React UI
- `Taskfile.yml`: 開発 / ビルド / 実行タスク
- `Dockerfile`: 1コンテナ配信用のマルチステージビルド

## 前提ツール

- `task`
- `uv`
- `node` / `npm`
- `docker`（Docker 利用時）


3.  `.env` を作成（メンバーは配布された.envを使用すること）

3. frontend 用 `.env` を作成

```bash
cp frontend/.env.example frontend/.env
```

4. frontend 依存をインストール

```bash
task frontend:install
```

5. backend を起動

```bash
task serve
```

6. 別ターミナルで frontend 開発サーバーを起動

```bash
task frontend:dev
```

利用先:

- frontend: `http://localhost:5173`
- backend: `http://localhost:8000`
- FastAPI docs: `http://localhost:8000/docs`

## 環境変数

### 共通

- `APP_NAME`: 任意
- `ENV`: 既定 `local`
- `FRONTEND_ORIGIN`: 既定 `http://localhost:5173`

### Azure OpenAI サンプル API 用

- `AZURE_OPENAI_API_KEY`
- `AZURE_OPENAI_ENDPOINT`
- `AZURE_OPENAI_DEPLOYMENT`
- `AZURE_OPENAI_API_VERSION`: 既定 `2024-02-01`


### frontend/.env

- `VITE_API_BASE_URL`
  - 空文字または未設定時:
    - 開発時は Vite proxy で `/api` を `http://localhost:8000` へ転送
    - 本番時は同一オリジンの `/api/...` を利用

## サンプル API

- `GET /api/health`
- `POST /api/v1/chat/completions`

## 主なタスク

- `task ruff`: backend の format / lint
- `task test`: backend テスト
- `task serve`: backend 起動
- `task frontend:install`: frontend 依存をインストール
- `task frontend:dev`: frontend 開発サーバー起動
- `task frontend:build`: frontend ビルド
