# Frontend

この frontend は、FastAPI backend と連携する Vite + React + Tailwind の最小テンプレート UI です。  
技術構成は Vite + React + Tailwind です。

## 現在の画面でできること

- backend のヘルスチェック
- Azure OpenAI チャット API のサンプル呼び出し
- Azure Blob Storage テキスト API の一覧取得 / 読み込み / 保存 / 削除

## 開発手順

プロジェクトルートで実行します。

1. frontend 依存インストール

```bash
task frontend:install
```

2. frontend 開発サーバー起動

```bash
task frontend:dev
```

3. backend 起動（別ターミナル）

```bash
task serve
```

## frontend から呼ぶ API

`frontend/src/App.tsx` では主に次を呼びます。

- `GET /api/health`
- `POST /api/v1/chat/completions`
- `GET /api/v1/storage/blobs`
- `GET /api/v1/storage/blobs/text`
- `PUT /api/v1/storage/blobs/text`
- `DELETE /api/v1/storage/blobs/text`

## 環境変数（frontend/.env）

`.env.example` をコピーして `.env` を作成します。

```bash
cp frontend/.env.example frontend/.env
```

### `VITE_API_BASE_URL`

- 1コンテナ運用のため、基本は空文字運用
- 空文字時の挙動:
  - 開発時: Vite proxy（`/api` → `http://localhost:8000`）
  - 本番時: 同一オリジンの `/api/...`

## ビルド

```bash
task frontend:build
```

または

```bash
cd frontend
npm run build
```

ビルド結果は `frontend/dist` に出力されます。

## Docker / 本番運用の注意

- Docker ビルド時に `frontend/dist` が runtime コンテナへコピーされます。
- frontend の表示/設定（`VITE_*`）を変更した場合は、Docker イメージ再ビルドと再デプロイが必要です。
