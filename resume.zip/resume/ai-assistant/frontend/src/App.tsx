import { ChangeEvent, useRef, useState } from 'react';

const API_BASE = (import.meta.env.VITE_API_BASE_URL || '').replace(/\/$/, '');
const RESUME_TEXT_ERROR = '履歴書テキストを入力してください（10文字以上）。';

type Step = 'input' | 'loading' | 'result';
type Tab = 'scores' | 'keywords' | 'suggestions' | 'resume';

type Keyword = { label: string; status: 'match' | 'partial' | 'missing' | 'extra' };
type Suggestion = { title: string; detail: string };
type Issue = { title: string; detail: string };
type SummaryImprovement = { title: string; text: string };
type HeroScores = { completeness: number; match: number; ats: number; quant: number };
type Scores = { total: number; completeness: number; expression: number; quantification: number; ats: number; hero: HeroScores };
type ExperienceItem = { company: string; title: string; period: string; items: string[] };
type ProjectItem = { name: string; role: string; items: string[] };
type OptimizedResume = {
  name: string; role: string;
  contact: { phone: string; email: string; location: string };
  sections: { summary: string; experiences: ExperienceItem[]; projects: ProjectItem[]; skills: string[] };
};
type AnalysisResult = {
  scores: Scores;
  keywords: Keyword[];
  suggestions: Suggestion[];
  issues: Issue[];
  summaryImprovements: SummaryImprovement[];
  optimizedResume: OptimizedResume;
};

async function readError(res: Response) {
  try { return ((await res.json()) as { detail?: string }).detail || 'エラーが発生しました。'; }
  catch { return 'エラーが発生しました。'; }
}

const KW_COLORS: Record<Keyword['status'], string> = {
  match: 'kw-match', partial: 'kw-partial', missing: 'kw-missing', extra: 'kw-extra',
};
const KW_LABELS: Record<Keyword['status'], string> = {
  match: '一致', partial: '部分', missing: '不足', extra: '関連',
};

const C = 2 * Math.PI * 28;
function ScoreRing({ value, label }: { value: number; label: string }) {
  const dash = (value / 100) * C;
  return (
    <div className="score-ring">
      <svg width="72" height="72" viewBox="0 0 72 72">
        <defs>
          <linearGradient id={`g-${label}`} x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#4f46e5" />
            <stop offset="100%" stopColor="#7c3aed" />
          </linearGradient>
        </defs>
        <circle cx="36" cy="36" r="28" fill="none" stroke="rgba(79,70,229,0.12)" strokeWidth="6" />
        <circle cx="36" cy="36" r="28" fill="none" stroke={`url(#g-${label})`} strokeWidth="6"
          strokeDasharray={`${dash} ${C}`} strokeLinecap="round"
          transform="rotate(-90 36 36)" />
      </svg>
      <div className="score-ring-inner"><span className="score-val">{value}</span></div>
      <p className="score-label">{label}</p>
    </div>
  );
}

const HERO_LABELS: { key: keyof HeroScores; label: string }[] = [
  { key: 'completeness', label: '完成度' },
  { key: 'match', label: 'マッチ度' },
  { key: 'ats', label: 'ATS適合' },
  { key: 'quant', label: '定量化' },
];

function HeroScoresCard({ hero }: { hero: HeroScores }) {
  return (
    <div className="card hero-scores-card">
      <p className="section-label">ヒーロースコア</p>
      <div className="hero-scores-grid">
        {HERO_LABELS.map(({ key, label }) => (
          <div key={key} className="hero-score-item">
            <div className="hero-score-bar-wrap">
              <div className="hero-score-bar" style={{ width: `${hero[key]}%` }} />
            </div>
            <div className="hero-score-row">
              <span className="hero-score-label">{label}</span>
              <span className="hero-score-val">{hero[key]}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function App() {
  const [step, setStep] = useState<Step>('input');
  const [tab, setTab] = useState<Tab>('scores');
  const [resumeText, setResumeText] = useState('');
  const [jobTitle, setJobTitle] = useState('');
  const [jobDescription, setJobDescription] = useState('');
  const [error, setError] = useState('');
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleFile = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const form = new FormData();
    form.append('file', file);
    setError('');
    try {
      const res = await fetch(`${API_BASE}/api/upload-resume`, { method: 'POST', body: form });
      if (!res.ok) throw new Error(await readError(res));
      const data = (await res.json()) as { extractedText: string };
      if (data.extractedText.trim().length < 10) {
        setResumeText(data.extractedText);
        setError('アップロードしたファイルから十分なテキストを抽出できませんでした。別のファイルをお試しください。');
        return;
      }
      setResumeText(data.extractedText);
      setError('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'アップロード失敗');
    } finally {
      e.target.value = '';
    }
  };

  const handleAnalyze = async () => {
    setError('');
    if (resumeText.trim().length < 10) { setError(RESUME_TEXT_ERROR); return; }
    if (!jobTitle.trim()) { setError('目標職種を入力してください。'); return; }
    if (jobDescription.trim().length < 10) { setError('求人票を入力してください（10文字以上）。'); return; }
    setStep('loading');
    try {
      const res = await fetch(`${API_BASE}/api/analyze`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ resumeText, jobTitle, jobDescription }),
      });
      if (!res.ok) throw new Error(await readError(res));
      setResult((await res.json()) as AnalysisResult);
      setTab('scores');
      setStep('result');
    } catch (err) {
      setError(err instanceof Error ? err.message : '分析失敗');
      setStep('input');
    }
  };

  // Loading
  if (step === 'loading') return (
    <div className="center-screen">
      <div className="loading-dots"><span /><span /><span /></div>
      <p className="loading-text">AIが履歴書を分析中です…</p>
    </div>
  );

  // Result page
  if (step === 'result' && result) {
    const { scores, keywords, suggestions, issues, summaryImprovements, optimizedResume } = result;
    return (
      <div className="shell">
        <header className="hero result-hero">
          <div>
            <p className="eyebrow">ResumePilot</p>
            <h1>分析結果</h1>
          </div>
          <button className="ghost-button" onClick={() => { setStep('input'); setResult(null); }}>
            ← 最初に戻る
          </button>
        </header>

        <div className="tab-bar">
          {(['scores', 'keywords', 'suggestions', 'resume'] as Tab[]).map(t => (
            <button key={t} className={`tab-btn${tab === t ? ' active' : ''}`} onClick={() => setTab(t)}>
              {{ scores: 'スコア', keywords: 'キーワード', suggestions: '改善提案', resume: '最適化履歴書' }[t]}
            </button>
          ))}
        </div>

        {tab === 'scores' && (
          <div className="tab-panel active">
            <div className="card score-total-card">
              <p className="section-label">総合スコア</p>
              <div className="score-total-num">{scores.total}</div>
              <div className="score-bar-wrap"><div className="score-bar" style={{ width: `${scores.total}%` }} /></div>
            </div>
            <div className="score-grid">
              <ScoreRing value={scores.completeness} label="完成度" />
              <ScoreRing value={scores.expression} label="表現力" />
              <ScoreRing value={scores.quantification} label="定量化" />
              <ScoreRing value={scores.ats} label="ATS適合" />
            </div>
            {scores.hero && <HeroScoresCard hero={scores.hero} />}
            {issues.length > 0 && (
              <div className="card">
                <p className="section-label">課題</p>
                {issues.map((iss, i) => (
                  <div key={i} className="issue-item">
                    <strong>{iss.title}</strong>
                    <p>{iss.detail}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {tab === 'keywords' && (
          <div className="tab-panel active">
            <div className="card" style={{ padding: '24px' }}>
              <p className="section-label">キーワード一致状況</p>
              <div className="kw-legend">
                {(['match', 'partial', 'missing', 'extra'] as const).map(s => (
                  <span key={s} className={`kw-tag ${KW_COLORS[s]}`}>{KW_LABELS[s]}</span>
                ))}
              </div>
              <div className="kw-list">
                {keywords.map((kw, i) => (
                  <span key={i} className={`kw-tag ${KW_COLORS[kw.status]}`}>{kw.label}</span>
                ))}
              </div>
            </div>
          </div>
        )}

        {tab === 'suggestions' && (
          <div className="tab-panel active">
            {suggestions.map((s, i) => (
              <div key={i} className="card suggestion-card">
                <p className="suggestion-title">💡 {s.title}</p>
                <p className="suggestion-detail">{s.detail}</p>
              </div>
            ))}
            {summaryImprovements.length > 0 && (
              <div className="card" style={{ padding: '24px' }}>
                <p className="section-label">推奨改善例</p>
                {summaryImprovements.map((si, i) => (
                  <div key={i} className="improvement-item">
                    <strong>{si.title}</strong>
                    <p className="improvement-text">{si.text}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {tab === 'resume' && (
          <div className="tab-panel active">
            <div className="card resume-card">
              <div className="resume-header">
                <h2>{optimizedResume.name || '（氏名未記載）'}</h2>
                <p className="resume-role">{optimizedResume.role}</p>
                <p className="resume-contact">
                  {[optimizedResume.contact.email, optimizedResume.contact.phone, optimizedResume.contact.location].filter(Boolean).join(' · ')}
                </p>
              </div>
              {optimizedResume.sections.summary && (
                <div className="resume-section">
                  <h3>職務要約</h3>
                  <p>{optimizedResume.sections.summary}</p>
                </div>
              )}
              {optimizedResume.sections.experiences.length > 0 && (
                <div className="resume-section">
                  <h3>職務経歴</h3>
                  {optimizedResume.sections.experiences.map((exp, i) => (
                    <div key={i} className="resume-exp">
                      <div className="resume-exp-head">
                        <strong>{exp.company}</strong>
                        <span>{exp.title} · {exp.period}</span>
                      </div>
                      <ul>{exp.items.map((it, j) => <li key={j}>{it}</li>)}</ul>
                    </div>
                  ))}
                </div>
              )}
              {optimizedResume.sections.projects.length > 0 && (
                <div className="resume-section">
                  <h3>プロジェクト</h3>
                  {optimizedResume.sections.projects.map((p, i) => (
                    <div key={i} className="resume-exp">
                      <div className="resume-exp-head">
                        <strong>{p.name}</strong><span>{p.role}</span>
                      </div>
                      <ul>{p.items.map((it, j) => <li key={j}>{it}</li>)}</ul>
                    </div>
                  ))}
                </div>
              )}
              {optimizedResume.sections.skills.length > 0 && (
                <div className="resume-section">
                  <h3>スキル</h3>
                  <div className="skill-list">
                    {optimizedResume.sections.skills.map((sk, i) => (
                      <span key={i} className="skill-tag">{sk}</span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    );
  }

  // Input page
  return (
    <div className="shell">
      <header className="hero">
        <p className="eyebrow">ResumePilot</p>
        <h1>AI 履歴書<br />最適化ツール</h1>
        <p className="hero-copy">履歴書と求人票を入力するだけで、AIがマッチ度を分析し改善案を提示します。</p>
      </header>

      <main className="input-grid">
        <section className="card">
          <p className="section-label">ステップ 1 — 履歴書</p>
          <h2 className="card-title">履歴書を入力</h2>
          <div className="stack">
            <div className="upload-zone" onClick={() => fileRef.current?.click()}>
              📄 PDF / DOCX / TXT をアップロード
              <input ref={fileRef} type="file" accept=".pdf,.docx,.txt" hidden onChange={handleFile} />
            </div>
            <label className="field">
              <span>または直接テキストを貼り付け</span>
              <textarea rows={10} value={resumeText} onChange={e => {
                const nextValue = e.target.value;
                setResumeText(nextValue);
                if (error === RESUME_TEXT_ERROR && nextValue.trim().length >= 10) setError('');
              }}
                placeholder="氏名、職務経歴、スキルなどを入力…" />
            </label>
          </div>
        </section>

        <section className="card">
          <p className="section-label">ステップ 2 — 求人情報</p>
          <h2 className="card-title">目標求人を入力</h2>
          <div className="stack">
            <label className="field">
              <span>目標職種</span>
              <input type="text" value={jobTitle} onChange={e => setJobTitle(e.target.value)}
                placeholder="例：バックエンドエンジニア" />
            </label>
            <label className="field">
              <span>求人票テキスト</span>
              <textarea rows={10} value={jobDescription} onChange={e => setJobDescription(e.target.value)}
                placeholder="求人票の本文を貼り付け…" />
            </label>
          </div>
        </section>

        <div className="card--wide analyze-row">
          {error && <p className="error-text">{error}</p>}
          <button className="analyze-btn" onClick={handleAnalyze}>🔍 AIで分析する</button>
        </div>
      </main>
    </div>
  );
}
