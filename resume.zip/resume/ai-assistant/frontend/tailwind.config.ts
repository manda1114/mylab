import type { Config } from 'tailwindcss';

export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          DEFAULT: '#4f46e5',
          light: '#818cf8',
          dark: '#3730a3',
        },
        accent: '#7c3aed',
        surface: '#f1f3f9',
      },
      fontFamily: {
        sans: ['Inter', 'Noto Sans JP', 'Hiragino Sans', 'Yu Gothic', 'sans-serif'],
      },
      borderRadius: {
        card: '20px',
        'card-lg': '24px',
        input: '14px',
      },
    },
  },
  plugins: [],
} satisfies Config;
