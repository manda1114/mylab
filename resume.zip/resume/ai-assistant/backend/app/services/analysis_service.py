from __future__ import annotations

from app.models.requests import AnalyzeRequest
from app.models.responses import AnalysisResult
from app.services.openai_service import call_openai


async def analyze(req: AnalyzeRequest) -> AnalysisResult:
    raw = await call_openai(req.resumeText, req.jobTitle, req.jobDescription)
    return AnalysisResult.model_validate(raw)
