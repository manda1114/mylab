from __future__ import annotations

import json
import logging

from openai import AsyncAzureOpenAI

from app.core.config import get_settings

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """\
あなたは日本語のキャリアアドバイザー兼採用担当者です。
これから渡す「履歴書テキスト」と「求人票テキスト」を分析し、
候補者の職務経歴が求人にどれくらいマッチしているかを評価し、
スコアリング・キーワード一致・課題・改善提案・最適化後の履歴書案を生成してください。

必ず以下の制約を守ってください：
- 出力は有効な JSON のみを返してください。
- JSON 以外のテキスト（説明文、コメント、マークダウン、余計な文字列）は一切出力してはいけません。
- 数値フィールド（スコアなど）は 0〜100 の整数で返してください。
- 文字列はすべて日本語で記述してください（変数名・キー名は英語）。

出力する JSON の構造：
{
  "scores": {"total":int,"completeness":int,"expression":int,"quantification":int,"ats":int,
             "hero":{"completeness":int,"match":int,"ats":int,"quant":int}},
  "keywords": [{"label":string,"status":"match"|"partial"|"missing"|"extra"}],
  "suggestions": [{"title":string,"detail":string}],
  "issues": [{"title":string,"detail":string}],
  "summaryImprovements": [{"title":string,"text":string}],
  "optimizedResume": {
    "name":string,"role":string,
    "contact":{"phone":string,"email":string,"location":string},
    "sections":{
      "summary":string,
      "experiences":[{"company":string,"title":string,"period":string,"items":[string]}],
      "projects":[{"name":string,"role":string,"items":[string]}],
      "skills":[string]
    }
  }
}
"""

USER_TEMPLATE = """\
以下の情報に基づいて AnalysisResult の JSON を生成してください。

【目標職種】
{job_title}

【履歴書テキスト】
{resume_text}

【求人票テキスト】
{job_description}

出力は JSON のみ。余計な文字列を含めないでください。
"""


def _make_client() -> AsyncAzureOpenAI:
    s = get_settings()
    return AsyncAzureOpenAI(
        api_key=s.azure_openai_api_key,
        azure_endpoint=s.azure_openai_endpoint,
        api_version=s.azure_openai_api_version,
    )


async def call_openai(resume_text: str, job_title: str, job_description: str) -> dict:
    client = _make_client()
    settings = get_settings()

    user_msg = USER_TEMPLATE.format(
        job_title=job_title,
        resume_text=resume_text[:4000],
        job_description=job_description[:2000],
    )

    for attempt in range(2):
        try:
            response = await client.chat.completions.create(
                model=settings.azure_openai_deployment,
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": user_msg},
                ],
                temperature=0.4,
                max_tokens=2500,
            )
            raw = response.choices[0].message.content or ""
            # strip markdown code fences if present
            raw = raw.strip()
            if raw.startswith("```"):
                raw = raw.split("\n", 1)[-1].rsplit("```", 1)[0]
            return json.loads(raw)
        except json.JSONDecodeError:
            if attempt == 0:
                logger.warning("JSON parse failed on attempt 1, retrying")
                continue
            logger.error("JSON parse failed on attempt 2")
            raise
