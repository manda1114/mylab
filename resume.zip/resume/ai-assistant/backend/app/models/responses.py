from __future__ import annotations

from typing import Literal

from pydantic import BaseModel


class HeroScores(BaseModel):
    completeness: int
    match: int
    ats: int
    quant: int


class Scores(BaseModel):
    total: int
    completeness: int
    expression: int
    quantification: int
    ats: int
    hero: HeroScores


KeywordStatus = Literal["match", "partial", "missing", "extra"]


class Keyword(BaseModel):
    label: str
    status: KeywordStatus


class Suggestion(BaseModel):
    title: str
    detail: str


class Issue(BaseModel):
    title: str
    detail: str


class SummaryImprovement(BaseModel):
    title: str
    text: str


class Contact(BaseModel):
    phone: str = ""
    email: str = ""
    location: str = ""


class ExperienceItem(BaseModel):
    company: str
    title: str
    period: str
    items: list[str]


class ProjectItem(BaseModel):
    name: str
    role: str
    items: list[str]


class ResumeSections(BaseModel):
    summary: str
    experiences: list[ExperienceItem]
    projects: list[ProjectItem]
    skills: list[str]


class OptimizedResume(BaseModel):
    name: str = ""
    role: str = ""
    contact: Contact = Contact()
    sections: ResumeSections


class AnalysisResult(BaseModel):
    scores: Scores
    keywords: list[Keyword]
    suggestions: list[Suggestion]
    issues: list[Issue]
    summaryImprovements: list[SummaryImprovement]
    optimizedResume: OptimizedResume


class UploadResponse(BaseModel):
    success: bool
    extractedText: str
    fileId: str = ""
