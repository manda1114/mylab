from __future__ import annotations

from pydantic import BaseModel, Field


class AnalyzeOptions(BaseModel):
    language: str = "ja"


class AnalyzeRequest(BaseModel):
    resumeText: str = Field(..., min_length=10)
    jobTitle: str = Field(..., min_length=1)
    jobDescription: str = Field(..., min_length=10)
    options: AnalyzeOptions = Field(default_factory=AnalyzeOptions)
