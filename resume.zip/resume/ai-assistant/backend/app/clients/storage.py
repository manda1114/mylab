from __future__ import annotations

import logging

from azure.storage.blob import BlobServiceClient

from app.core.config import StorageSettings

try:
    from azure.identity import DefaultAzureCredential  # type: ignore
except Exception:  # pragma: no cover
    DefaultAzureCredential = None  # type: ignore

logger = logging.getLogger(__name__)


class StorageClient:
    def __init__(self, settings: StorageSettings) -> None:
        self.settings = settings
        self._validate_settings()
        self._service = BlobServiceClient(
            account_url=self.settings.account_url,
            credential=self._resolve_credential(),
        )

    def _validate_settings(self) -> None:
        missing: list[str] = []
        if not self.settings.account_url:
            missing.append("AZURE_STORAGE_ACCOUNT_URL")
        if not self.settings.container_name:
            missing.append("AZURE_STORAGE_CONTAINER_NAME")
        if missing:
            raise ValueError("ストレージ設定が不足しています: " + ", ".join(missing))

    def _resolve_credential(self):
        if self.settings.access_key:
            return self.settings.access_key
        if DefaultAzureCredential is not None:
            try:
                return DefaultAzureCredential()
            except Exception as exc:  # pragma: no cover
                logger.warning("DefaultAzureCredential の取得に失敗しました: %s", exc)
        raise ValueError(
            "ストレージ資格情報が不足しています。AZURE_STORAGE_ACCESS_KEY を設定するか、"
            "Managed Identity を利用できる環境で実行してください。"
        )

    def _container(self):
        return self._service.get_container_client(self.settings.container_name)

    def download_bytes(self, blob_path: str) -> bytes:
        blob_client = self._container().get_blob_client(blob_path)
        data = blob_client.download_blob(timeout=60, logging_enable=False).readall()
        return bytes(data)

    def download_text(self, blob_path: str) -> str:
        return self.download_bytes(blob_path).decode("utf-8", errors="ignore")

    def upload_text(self, blob_path: str, text: str) -> None:
        blob_client = self._container().get_blob_client(blob_path)
        blob_client.upload_blob(
            text.encode("utf-8"),
            overwrite=True,
            timeout=60,
            logging_enable=False,
        )

    def delete_text(self, blob_path: str) -> None:
        blob_client = self._container().get_blob_client(blob_path)
        blob_client.delete_blob(
            timeout=60,
            logging_enable=False,
        )

    def list_blob_names(self, prefix: str | None = None) -> list[str]:
        container = self._container()
        blobs = container.list_blobs(name_starts_with=(prefix or None))
        return sorted(blob.name for blob in blobs)


def get_storage_client(settings: StorageSettings) -> StorageClient:
    return StorageClient(settings)
