from __future__ import annotations

from typing import Sequence

from openai import OpenAI

from app.core.config import AzureOpenAISettings


class AOAIClient:
    def __init__(self, settings: AzureOpenAISettings) -> None:
        self.settings = settings

    def _azure_v1_client(self) -> OpenAI:
        if not self.settings.api_key:
            raise ValueError("AZURE_OPENAI_API_KEY が設定されていません。")
        if not self.settings.endpoint:
            raise ValueError("AZURE_OPENAI_ENDPOINT が設定されていません。")

        endpoint = (self.settings.endpoint or "").rstrip("/")
        return OpenAI(
            api_key=self.settings.api_key,
            base_url=f"{endpoint}/openai/v1/",
        )

    def chat_completion(
        self,
        *,
        messages: Sequence[dict[str, str]],
        deployment: str | None = None,
    ):
        resolved_deployment = deployment or self.settings.deployment
        if not resolved_deployment:
            raise ValueError("AZURE_OPENAI_DEPLOYMENT が設定されていません。")

        client = self._azure_v1_client()
        return client.chat.completions.create(
            model=resolved_deployment,
            messages=list(messages),
        )


def get_aoai_client(settings: AzureOpenAISettings) -> AOAIClient:
    return AOAIClient(settings=settings)
