from __future__ import annotations

from typing import Literal

from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel, Field

from app.clients.aoai import get_aoai_client
from app.core.config import get_settings

router = APIRouter(prefix="/chat", tags=["chat"])


class ChatMessage(BaseModel):
    role: Literal["system", "user", "assistant"] = Field(
        ...,
        description="チャットメッセージの role",
    )
    content: str = Field(..., min_length=1, description="メッセージ本文")

    model_config = {
        "json_schema_extra": {
            "example": {
                "role": "user",
                "content": "FastAPI と React の構成を簡潔に説明してください。",
            }
        }
    }


class ChatCompletionRequest(BaseModel):
    messages: list[ChatMessage] = Field(
        ...,
        min_length=1,
        description="Azure OpenAI に渡す会話履歴",
    )
    deployment: str | None = Field(
        default=None,
        description="このリクエストでのみ使うデプロイ名。未指定時は環境変数を利用します。",
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "messages": [
                    {
                        "role": "system",
                        "content": "You are a concise assistant.",
                    },
                    {
                        "role": "user",
                        "content": "FastAPI と React の責務を一言ずつ教えてください。",
                    },
                ]
            }
        }
    }


class ChatResponse(BaseModel):
    reply: str = Field(..., description="LLM応答本文")
    deployment: str = Field(..., description="今回利用したデプロイ名")

    model_config = {
        "json_schema_extra": {
            "example": {
                "reply": "FastAPI は API を提供し、React は UI を担当します。",
                "deployment": "gpt-4o-mini",
            }
        }
    }


def _extract_reply(completion) -> str:
    try:
        message = completion.choices[0].message  # type: ignore[index]
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail="Azure OpenAI の応答形式が想定と異なります。",
        ) from exc

    content = getattr(message, "content", None)
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        parts: list[str] = []
        for part in content:
            if isinstance(part, dict):
                text = part.get("text")
            else:
                text = getattr(part, "text", None)
            if isinstance(text, str) and text.strip():
                parts.append(text.strip())
        return "\n".join(parts).strip()
    return ""


@router.post(
    "/completions",
    response_model=ChatResponse,
    summary="Azure OpenAI へチャット補完を送信",
    description=(
        "指定されたメッセージ配列を Azure OpenAI に送信し、"
        "先頭の応答メッセージ本文を返します。"
    ),
)
def create_chat_completion(
    payload: ChatCompletionRequest,
) -> ChatResponse:
    settings = get_settings()
    client = get_aoai_client(settings.azure_openai)

    try:
        completion = client.chat_completion(
            messages=[message.model_dump() for message in payload.messages],
            deployment=payload.deployment,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(exc),
        )
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=(
                "Azure OpenAI からの応答取得に失敗しました。"
                "設定とネットワークを確認してください。"
            ),
        ) from exc

    reply = _extract_reply(completion)
    if not reply:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail="Azure OpenAI から応答が取得できませんでした。",
        )

    return ChatResponse(
        reply=reply,
        deployment=payload.deployment or settings.azure_openai.deployment or "",
    )
