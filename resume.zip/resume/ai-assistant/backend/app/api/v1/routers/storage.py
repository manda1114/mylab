from __future__ import annotations

from pathlib import Path

from azure.core.exceptions import ResourceNotFoundError
from fastapi import APIRouter, HTTPException, Query, status
from pydantic import BaseModel, Field

from app.clients.storage import get_storage_client
from app.core.config import Settings, get_settings

router = APIRouter(prefix="/storage", tags=["storage"])


class BlobTextResponse(BaseModel):
    blob_path: str = Field(..., description="対象の Blob パス")
    content: str = Field(..., description="テキスト内容")

    model_config = {
        "json_schema_extra": {
            "example": {
                "blob_path": "samples/template.txt",
                "content": "# Notes\nThis is a sample blob payload.",
            }
        }
    }


class BlobUploadTextRequest(BaseModel):
    blob_path: str | None = Field(
        default=None, description="アップロード先の Blob パス"
    )
    content: str = Field(..., description="保存するテキストデータ")

    model_config = {
        "json_schema_extra": {
            "example": {
                "blob_path": "samples/template.txt",
                "content": "# Notes\nThis is a sample blob payload.",
            }
        }
    }


class BlobOperationResult(BaseModel):
    blob_path: str = Field(..., description="対象の Blob パス")
    message: str = Field(..., description="処理結果メッセージ")


class BlobListResponse(BaseModel):
    blobs: list[str] = Field(..., description="Blob パス一覧")


def _client():
    settings = get_settings()
    try:
        return get_storage_client(settings.storage)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(exc),
        ) from exc


def _validate_blob_path(blob_path: str) -> None:
    resolved = blob_path.strip()
    if not resolved:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Blob パスが空です。",
        )
    if Path(resolved).is_absolute() or resolved.startswith("\\"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="絶対パス形式の Blob パスは指定できません。",
        )
    if ".." in resolved.split("/"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=".. を含むパスは許可されません。",
        )


def _resolve_blob_path(settings: Settings, blob_path: str | None) -> str:
    resolved = (blob_path or settings.storage.default_text_blob_path).strip()
    _validate_blob_path(resolved)
    return resolved


@router.get(
    "/blobs",
    summary="Blob 一覧を取得",
    response_model=BlobListResponse,
)
def list_blobs(
    prefix: str | None = Query(default=None, description="Blob 名のプレフィックス"),
) -> BlobListResponse:
    client = _client()
    try:
        blobs = client.list_blob_names(prefix=prefix)
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail="Blob 一覧の取得に失敗しました。設定とネットワークを確認してください。",
        ) from exc
    return BlobListResponse(blobs=blobs)


@router.get(
    "/blobs/text",
    summary="Blob をテキストで取得",
    response_model=BlobTextResponse,
)
def download_text(
    blob_path: str | None = Query(default=None, description="取得する Blob のパス"),
) -> BlobTextResponse:
    settings = get_settings()
    resolved_path = _resolve_blob_path(settings, blob_path)
    client = _client()
    try:
        content = client.download_text(resolved_path)
    except ResourceNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Blob が見つかりません: {resolved_path}",
        ) from exc
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail="Blob の取得に失敗しました。設定とネットワークを確認してください。",
        ) from exc
    return BlobTextResponse(blob_path=resolved_path, content=content)


@router.put(
    "/blobs/text",
    summary="テキストをアップロード",
    response_model=BlobOperationResult,
)
def upload_text(payload: BlobUploadTextRequest) -> BlobOperationResult:
    settings = get_settings()
    resolved_path = _resolve_blob_path(settings, payload.blob_path)
    client = _client()
    try:
        client.upload_text(resolved_path, payload.content)
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail="Blob のアップロードに失敗しました。設定とネットワークを確認してください。",
        ) from exc
    return BlobOperationResult(
        blob_path=resolved_path,
        message="アップロードが完了しました。",
    )


@router.delete(
    "/blobs/text",
    summary="Blob テキストを削除",
    response_model=BlobOperationResult,
)
def delete_text(
    blob_path: str | None = Query(default=None, description="削除する Blob のパス"),
) -> BlobOperationResult:
    settings = get_settings()
    resolved_path = _resolve_blob_path(settings, blob_path)
    client = _client()
    try:
        client.delete_text(resolved_path)
    except ResourceNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Blob が見つかりません: {resolved_path}",
        ) from exc
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail="Blob の削除に失敗しました。設定とネットワークを確認してください。",
        ) from exc
    return BlobOperationResult(
        blob_path=resolved_path,
        message="削除が完了しました。",
    )
