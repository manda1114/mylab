from __future__ import annotations

import logging

from fastapi import APIRouter, HTTPException

from app.models.requests import AnalyzeRequest
from app.models.responses import AnalysisResult
from app.services.analysis_service import analyze

logger = logging.getLogger(__name__)
router = APIRouter()


@router.post("/analyze", response_model=AnalysisResult)
async def analyze_resume(req: AnalyzeRequest) -> AnalysisResult:
    try:
        return await analyze(req)
    except Exception:
        logger.exception("Analysis failed")
        raise HTTPException(
            status_code=500,
            detail="分析処理で問題が発生しました。しばらく時間をおいて再度お試しください。",
        )
