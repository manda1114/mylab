"""EDINET extraction package."""
