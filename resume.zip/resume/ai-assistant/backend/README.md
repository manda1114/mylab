# Backend API

この backend は、FastAPI をベースにした web app テンプレートの API 層です。
サンプルとして次の Azure 連携を含みます。

- Azure OpenAI を使うチャット補完 API
- Azure Blob Storage を使うテキスト Blob 操作 API

## 起動

プロジェクトルートで実行します。

```bash
task serve
```

既定の URL は `http://localhost:8000` です。

## 主な環境変数

- `APP_NAME` 既定: `fastapi-vite-react-template`
- `ENV` 既定: `local`
- `FRONTEND_ORIGIN` 既定: `http://localhost:5173`
- `AZURE_OPENAI_API_KEY` Azure OpenAI 利用時に必要
- `AZURE_OPENAI_ENDPOINT` Azure OpenAI 利用時に必要
- `AZURE_OPENAI_DEPLOYMENT` Azure OpenAI 利用時に必要
- `AZURE_OPENAI_API_VERSION` 既定: `2024-02-01`
- `AZURE_STORAGE_ACCOUNT_URL` Blob Storage 利用時に必要
- `AZURE_STORAGE_CONTAINER_NAME` Blob Storage 利用時に必要
- `AZURE_STORAGE_ACCESS_KEY` Blob Storage 利用時に必要
- `AZURE_STORAGE_DEFAULT_TEXT_BLOB_PATH` 既定: `samples/template.txt`

## API

### `GET /api/health`

ヘルスチェックです。

### `POST /api/v1/chat/completions`

Azure OpenAI の chat completions を呼び出します。

### `GET /api/v1/storage/blobs`

Blob 一覧を取得します。

### `GET /api/v1/storage/blobs/text`

指定した Blob のテキスト内容を取得します。

### `PUT /api/v1/storage/blobs/text`

指定した Blob にテキストを保存します。

### `DELETE /api/v1/storage/blobs/text`

指定した Blob を削除します。
