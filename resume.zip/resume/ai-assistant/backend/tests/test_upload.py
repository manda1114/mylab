from __future__ import annotations

import io

from fastapi.testclient import TestClient


def test_upload_txt_happy(client: TestClient) -> None:
    content = "山田太郎\nバックエンドエンジニア\nJava Spring Boot MySQL"
    response = client.post(
        "/api/upload-resume",
        files={"file": ("resume.txt", io.BytesIO(content.encode()), "text/plain")},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert "山田太郎" in data["extractedText"]


def test_upload_unsupported_format(client: TestClient) -> None:
    response = client.post(
        "/api/upload-resume",
        files={"file": ("resume.png", io.BytesIO(b"fake"), "image/png")},
    )
    assert response.status_code == 415


def test_upload_too_large(client: TestClient) -> None:
    big = b"a" * (1 * 1024 * 1024 + 1)
    response = client.post(
        "/api/upload-resume",
        files={"file": ("resume.txt", io.BytesIO(big), "text/plain")},
    )
    assert response.status_code == 413
