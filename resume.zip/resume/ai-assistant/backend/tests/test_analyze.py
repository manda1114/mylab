from __future__ import annotations

from unittest.mock import AsyncMock, patch

from fastapi.testclient import TestClient

MOCK_RESULT = {
    "scores": {
        "total": 80,
        "completeness": 85,
        "expression": 75,
        "quantification": 70,
        "ats": 88,
        "hero": {"completeness": 85, "match": 80, "ats": 88, "quant": 70},
    },
    "keywords": [{"label": "Java", "status": "match"}],
    "suggestions": [{"title": "スキル強調", "detail": "Java を前面に出してください。"}],
    "issues": [{"title": "定量化不足", "detail": "数値実績を追加してください。"}],
    "summaryImprovements": [{"title": "推奨改善例", "text": "バックエンドエンジニアとして3年の経験があります。"}],
    "optimizedResume": {
        "name": "山田太郎",
        "role": "バックエンドエンジニア",
        "contact": {"phone": "", "email": "", "location": ""},
        "sections": {
            "summary": "バックエンドエンジニアとして3年の経験があります。",
            "experiences": [
                {
                    "company": "XX社",
                    "title": "エンジニア",
                    "period": "2022-現在",
                    "items": ["Spring Boot 開発"],
                }
            ],
            "projects": [],
            "skills": ["Java", "Spring Boot"],
        },
    },
}


def test_analyze_happy(client: TestClient) -> None:
    with patch(
        "app.services.analysis_service.call_openai",
        new=AsyncMock(return_value=MOCK_RESULT),
    ):
        response = client.post(
            "/api/analyze",
            json={
                "resumeText": "Java Spring Boot MySQL 3年経験",
                "jobTitle": "バックエンドエンジニア",
                "jobDescription": "Java Spring Boot を使ったバックエンド開発",
            },
        )
    assert response.status_code == 200
    data = response.json()
    assert data["scores"]["total"] == 80
    assert data["keywords"][0]["label"] == "Java"


def test_analyze_validation_error(client: TestClient) -> None:
    response = client.post(
        "/api/analyze",
        json={"resumeText": "", "jobTitle": "エンジニア", "jobDescription": ""},
    )
    assert response.status_code == 422


def test_analyze_empty_resume(client: TestClient) -> None:
    response = client.post(
        "/api/analyze",
        json={"resumeText": "short", "jobTitle": "エンジニア", "jobDescription": "short"},
    )
    assert response.status_code == 422
