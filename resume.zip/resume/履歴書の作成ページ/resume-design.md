# 自定义简历生成器 Web App — 设计文档（design.md）

版本：v1.2  
日期：  

---

## 1. 架构概览

### 1.1 当前系统构成

本系统从目标上采用典型的三层架构设计，但 **v1.2 实际实现为纯前端 Demo**，仅落地了表示层，应用层和数据层在本版本中尚未真正接入（为未来扩展预留）。

1. **表示层（前端）**
   - 职责：
     - 提供简约风的简历生成 Web 界面
     - 支持中文 / 日文 / 英文三种系统语言切换（UI 语言）
     - 收集用户输入（基础信息、教育、工作/实习、项目、技能、自定义模块等）
     - 提供结构设置（模块勾选、模块标题修改），并本地生成简历预览
     - 调用浏览器打印导出 PDF，隐藏所有编辑 UI，只保留简历内容
   - 当前 v1.2 实现：
     - 纯 HTML + CSS + 原生 JavaScript（单文件）
     - 使用内存状态 + DOM 操作，无后端调用

2. **应用层（后端）**（本版本未实现，作为架构预留）
   - 预期职责：
     - 对外提供 REST API：
       - `POST /api/resume/generate`：接入 Kiro + LLM，根据输入与布局生成简历
       - `POST /api/resume`：保存简历
       - `GET /api/resume/:id`：读取历史简历
     - 使用 Kiro SDK 调用 LLM，支持中/日/英生成
     - 处理业务逻辑（权限校验、参数校验、错误处理、重试）
   - 与数据层交互：
     - 通过 ORM（如 Prisma/TypeORM）读写数据库

3. **数据层**（本版本未实现，作为架构预留）
   - 预期职责：
     - 持久化存储用户、简历内容、结构配置、模板、审计日志等数据
     - 支持按用户、多语言、时间维度的查询
   - 数据示例：
     - `users`：用户登录信息、偏好语言
     - `resumes`：简历输入 JSON、生成结果 JSON、语言/布局配置
     - `templates`：简历模板及模块默认配置
     - `logs`：LLM 调用日志（脱敏）、错误日志

### 1.2 未来扩展架构（预留）

- 当接入后端与数据库后：
  - 当前前端表单结构、布局配置、预览结构可直接映射为 `ResumeInput` / `LayoutConfig` 等后端 DTO。
  - 前端 `mockGenerate()` 将替换为：
    - 组装 JSON 请求体 → 调用 `/api/resume/generate` → 根据返回结构更新预览。
- 当前 v1.2 的 HTML / JS 设计已经尽量贴近未来的结构化数据模型，方便后续迁移。

---

## 2. 技术栈与关键点

> 说明：当前 v1.2 为纯前端实现（单一 HTML + 原生 JavaScript + 内联 CSS）。  
> 本节所述 React / NestJS / 数据库为后续工程化重构时的推荐方案。

### 2.1 前端

- 当前实现：
  - 原生 HTML + CSS + JavaScript（无构建步骤）
  - 简单 i18n 字典对象 + `data-i18n` 属性驱动多语言
  - 使用 `window.print()` + `@media print` 实现 PDF 导出效果
- 未来推荐栈：
  - 框架：React + TypeScript（或 Next.js）
  - UI：Tailwind CSS / 自定义 CSS
  - 多语言：`react-i18next` / `next-i18next`（zh / ja / en）
  - 状态管理：React 状态或轻量状态库（Zustand / Jotai）

### 2.2 后端（规划）

- 运行时：Node.js（LTS）
- 框架：NestJS / Express（建议 NestJS 做模块化分层）
- 模块：
  - API 层：`/api/resume/generate` 等 REST 接口
  - Service 层：简历生成/保存业务逻辑
  - AI 集成层：通过 Kiro 调用 LLM（GPT 系列等）

### 2.3 数据库（规划）

- 类型：关系型数据库（PostgreSQL / MySQL）
- 访问方式：Prisma / TypeORM
- 模型：
  - `User`, `Resume`, `Template`, `AiLog` 等
- 扩展：
  - 对 PDF 快照等静态资源使用对象存储（S3/OSS）
  - 使用 Redis 缓存公共模板、系统配置

---

## 3. 前端模块设计

### 3.1 布局结构（Layout）

- 主体结构：

```text
<div class="app">
  <header class="topbar"> 标题 + 语言切换 </header>
  <main class="main">
    <div class="grid">
      <section class="panel"> 左侧配置 (Content / Layout / Settings Tabs) </section>
      <section class="panel"> 右侧预览 (Preview) </section>
    </div>
  </main>
</div>
```

- 左侧 Panel：
  - Tabs：
    - Content：内容填写
    - Layout：结构设置（模块开关、标题）
    - Settings：AI 设置（目前为占位）
  - 每个 Tab 对应一个 `.tab-panel`，通过 JS 切换 `display`。

- 右侧 Panel：
  - `preview-header`：
    - 预览标题（多语言）
    - 状态提示（如 “预览已更新”、“布局已保存”等）
  - `preview-paper`：
    - 简历主体区域（A4 宽度风格）
    - 打印/PDF 时仅保留此区域

### 3.2 i18n 设计

- 使用一个全局字典对象 `dict`：

```js
const dict = {
  en: {
    appTitle: "...",
    nav: { form: "...", layout: "...", settings: "..." },
    section: { ... },
    fields: { ... },
    module: { ... },
    row: {
      school: "School",
      degree: "Degree",
      major: "Major",
      company: "Company",
      position: "Position",
      project: "Project",
      industry: "Industry",
      duties: "Duties",
      start: "Start",
      end: "End"
    },
    buttons: { ... },
    preview: { ... }
  },
  zh: { ... },
  ja: { ... }
};
```

- 文案分类：
  - `appTitle`, `label.uiLanguage` → 顶部标题和“界面语言”标签
  - `nav.*` → Tab 名称
  - `section.*` → 各区域标题 & 提示文案
  - `fields.*` → 基础字段标签（姓名、邮箱等）
  - `module.*` → Layout 模块名 & 提示
  - `row.*` → 动态行标签（教育/工作/项目），包括：
    - School / Degree / Major / Company / Position / Project / Industry / Duties / Start / End
  - `buttons.*` → 按钮文案（生成、导出 PDF、复制文本、保存布局）
  - `preview.*` → 预览区相关文案

- 应用方式：
  - 所有需要多语言的 DOM 元素使用 `data-i18n="xxx"`。
  - `applyLanguage(lang)` 中遍历所有 `[data-i18n]` 元素，将 `textContent` 替换为 `dict[lang]` 中对应值。
  - 动态创建的条目（教育/工作/项目行）在创建后调用一次 `applyLanguage(currentLang)`，保证标签语言与当前 UI 语言一致。

### 3.3 语言检测与切换

- 初始语言检测 `detectInitialLang()`：
  - 先读 `localStorage.getItem("resumeApp.uiLanguage")`；
  - 若没有，使用 `navigator.language`：
    - 以 `zh` 开头 → zh
    - 以 `ja` 开头 → ja
    - 其他 → en

- 语言应用 `applyLanguage(lang)`：
  - 更新全局 `currentLang`；
  - 调整所有 `data-i18n` 文本；
  - 更新语言切换按钮 `.lang-btn` 的 active 样式；
  - 将语言持久化到 localStorage；
  - 调用 `syncLayoutToFormAndPreview()`，让布局内“默认标题”在新语言下刷新。

---

## 4. 表单设计

### 4.1 基础信息 & Summary

- 基础信息区域（`data-section="basic"`）：
  - 输入：
    - `#name`：姓名
    - `#title`：期望职位/头衔
    - `#city`：城市
    - `#email`：邮箱
    - `#phone`：电话

- Summary 区域（`data-section="summary"`）：
  - 原始输入：`#summary-input`（多行 textarea）
  - 预览中的 Summary：`#cv-summary-content`（textarea，可微调）

### 4.2 教育 / 工作 / 项目行结构

#### 4.2.1 教育经历行 DOM 结构

```html
<div class="row-group edu-item">
  <div class="row-group-header">
    <div class="field">
      <label data-i18n="row.school">School</label>
      <input type="text" class="edu-school" />
    </div>
    <div class="field">
      <label data-i18n="row.degree">Degree</label>
      <input type="text" class="edu-degree" />
    </div>
    <div class="field">
      <label data-i18n="row.major">Major</label>
      <input type="text" class="edu-major" />
    </div>
    <button type="button" class="remove-row-btn">&times;</button>
  </div>
  <div class="date-row">
    <span data-i18n="row.start">Start</span>
    <div class="date-select-group">
      <select class="year-select edu-start-year"><option value="">YYYY</option>...</select>
      <select class="month-select edu-start-month"><option value="">MM</option>...</select>
      <select class="day-select edu-start-day"><option value="">DD</option>...</select>
    </div>
    <span>~</span>
    <span data-i18n="row.end">End</span>
    <div class="date-select-group">
      <select class="year-select edu-end-year"><option value="">YYYY</option>...</select>
      <select class="month-select edu-end-month"><option value="">MM</option>...</select>
      <select class="day-select edu-end-day"><option value="">DD</option>...</select>
    </div>
  </div>
</div>
```

- 标签 `School/Degree/Major/Start/End` 通过 i18n 切换中/日/英文本。

#### 4.2.2 工作/实习经历行 DOM 结构

```html
<div class="row-group exp-item">
  <div class="row-group-header">
    <div class="field">
      <label data-i18n="row.company">Company</label>
      <input type="text" class="exp-company" />
    </div>
    <div class="field">
      <label data-i18n="row.position">Position</label>
      <input type="text" class="exp-position" />
    </div>
    <button type="button" class="remove-row-btn">&times;</button>
  </div>
  <div class="date-row">
    <span data-i18n="row.start">Start</span>
    <div class="date-select-group">
      <select class="year-select exp-start-year"><option value="">YYYY</option>...</select>
      <select class="month-select exp-start-month"><option value="">MM</option>...</select>
      <select class="day-select exp-start-day"><option value="">DD</option>...</select>
    </div>
    <span>~</span>
    <span data-i18n="row.end">End</span>
    <div class="date-select-group">
      <select class="year-select exp-end-year"><option value="">YYYY</option>...</select>
      <select class="month-select exp-end-month"><option value="">MM</option>...</select>
      <select class="day-select exp-end-day"><option value="">DD</option>...</select>
    </div>
  </div>
</div>
```

- 行标签 Company/Position/Start/End 同样由 i18n 控制。

#### 4.2.3 项目经历行 DOM 结构（Project + Industry + Duties）

```html
<div class="row-group proj-item">
  <div class="row-group-header">
    <div class="field">
      <label data-i18n="row.project">Project</label>
      <input type="text" class="proj-name" />
    </div>
    <div class="field">
      <label data-i18n="row.industry">Industry</label>
      <input type="text" class="proj-industry" />
    </div>
    <div class="field">
      <label data-i18n="row.duties">Duties</label>
      <input type="text" class="proj-duties" />
    </div>
    <button type="button" class="remove-row-btn">&times;</button>
  </div>
  <div class="date-row">
    <span data-i18n="row.start">Start</span>
    <div class="date-select-group">
      <select class="year-select proj-start-year"><option value="">YYYY</option>...</select>
      <select class="month-select proj-start-month"><option value="">MM</option>...</select>
      <select class="day-select proj-start-day"><option value="">DD</option>...</select>
    </div>
    <span>~</span>
    <span data-i18n="row.end">End</span>
    <div class="date-select-group">
      <select class="year-select proj-end-year"><option value="">YYYY</option>...</select>
      <select class="month-select proj-end-month"><option value="">MM</option>...</select>
      <select class="day-select proj-end-day"><option value="">DD</option>...</select>
    </div>
  </div>
</div>
```

- 三个字段：
  - `proj-name`：项目名称
  - `proj-industry`：所属业界
  - `proj-duties`：担当内容
- 标签 Project/Industry/Duties/Start/End 均由 i18n 控制。

#### 4.2.4 行生成函数

- 教育：`createEducationRow()`
- 工作：`createExperienceRow()`
- 项目：`createProjectRow()`（已更新为 Project + Industry + Duties）

共同逻辑：

1. 创建 `.row-group` 容器，注入对应 HTML 模板。
2. 调用 `fillDateSelects(container)` 填充年/月/日下拉：
   - 年：1980 ~ 当前年份 + 2
   - 月：01 ~ 12
   - 日：01 ~ 31
3. 设置删除按钮行为：
   - 删除当前行，但至少保留 1 行（若只剩一行则阻止删除）。
4. 调用 `applyLanguage(currentLang)`：
   - 确保新添加行的标签与当前系统语言一致（满足“点击 + 号添加下一条的内容要和现在选择的系统语言保持一致”的需求）。

#### 4.2.5 列表初始化

- `initRowLists()`：
  - 获取容器：
    - `#education-list`
    - `#experience-list`
    - `#projects-list`
  - 各追加一条默认行：
    - `createEducationRow()`
    - `createExperienceRow()`
    - `createProjectRow()`
  - 为「+」按钮绑定事件：
    - `#add-education` → append `createEducationRow()`
    - `#add-experience` → append `createExperienceRow()`
    - `#add-project` → append `createProjectRow()`

### 4.3 技能（Skills）

- 使用一个简单文本输入 `#skills-input`：
  - 用户以逗号分隔：`React, TypeScript, Node.js`
- 生成预览时拆分为数组，并渲染为 `<ul><li>...</li></ul>`。

---

## 5. Layout（结构设置）设计

### 5.1 Layout 与 Form/Preview 同步函数

核心函数：`syncLayoutToFormAndPreview()`，职责：

1. 配置简历模块列表（除 Header）：

```js
const configs = [
  {
    id: "summary",
    formKey: "summary",
    previewSectionId: "cv-summary-section",
    previewTitleId: "cv-summary-title",
    defaults: { zh: "个人简介", ja: "自己紹介", en: "SUMMARY" }
  },
  {
    id: "experience",
    formKey: "experience",
    previewSectionId: "cv-experience-section",
    previewTitleId: "cv-experience-title",
    defaults: { zh: "工作/实习经历", ja: "職務経歴", en: "EXPERIENCE" }
  },
  {
    id: "projects",
    formKey: "projects",
    previewSectionId: "cv-projects-section",
    previewTitleId: "cv-projects-title",
    defaults: { zh: "项目经历", ja: "プロジェクト", en: "PROJECTS" }
  },
  {
    id: "skills",
    formKey: "skills",
    previewSectionId: "cv-skills-section",
    previewTitleId: "cv-skills-title",
    defaults: { zh: "技能", ja: "スキル", en: "SKILLS" }
  },
  {
    id: "education",
    formKey: "education",
    previewSectionId: "cv-education-section",
    previewTitleId: "cv-education-title",
    defaults: { zh: "教育经历", ja: "学歴", en: "EDUCATION" }
  }
];
```

2. 对每个模块执行：
   - 读取 `#module-{id}` 勾选状态；
   - 控制内容表单显示/隐藏：
     - 遍历 `.section[data-section="{formKey}"]`；
   - 控制预览区对应模块显示/隐藏：
     - `#cv-{id}-section`；
   - 处理标题覆盖：
     - 读取输入框 `#title-{id}`；
     - 若非空 → 使用此值作为预览模块标题；
     - 否则使用 `defaults[currentLang]`。

3. 自定义模块（custom1/custom2）：
   - 勾选框：`#module-custom1/2`
   - 标题输入：`#title-custom1/2`
   - 控制预览区显示：
     - `#cv-custom1-section` / `#cv-custom2-section`
   - 标题逻辑：
     - 若 `title-custom1/2` 有值 → 用该值；
     - 否则按语言使用默认：
       - zh：自定义模块一 / 自定义模块二
       - ja：カスタムセクション 1 / 2
       - en：CUSTOM SECTION 1 / 2
   - 说明：
     - Layout 保存仅控制**显示/标题**，**不会覆盖**预览中 `textarea` 内用户正在编辑的具体内容。

### 5.2 Layout 事件绑定

- `initLayoutBindings()`：
  - 为每个模块的勾选框 `#module-{id}` 绑定 `change`（为保存准备状态）。
  - 为标题输入 `#title-{id}` 绑定 `input`。
  - 为自定义模块勾选 `#module-custom1/2`、标题 `#title-custom1/2` 绑定事件。
  - 这些事件本身不直接更新预览，而是配合「保存」按钮统一应用。

### 5.3 Layout 保存按钮

- 在 Layout Tab 中设置 `id="btn-layout-save"` 按钮。
- 在 `initToolbar()` 中绑定点击事件：
  - 调用 `syncLayoutToFormAndPreview()`；
  - 更新预览状态栏 `#preview-status` 提示：
    - zh：已保存结构设置，并同步到内容和预览。
    - ja：構成設定を保存し、入力フォームとプレビューに反映しました。
    - en：Layout settings saved and applied to form & preview.

---

## 6. 生成与预览逻辑

### 6.1 mockGenerate()

当前版本的 “Generate (Mock)” 不调用后端，仅在前端根据表单数据更新预览。

流程：

1. 调用 `syncLayoutToFormAndPreview()`：
   - 确保模块显示/隐藏及标题与最新 Layout 设置一致。

2. 收集基础信息：
   - 姓名 / 标题 / 城市 / 邮箱 / 电话
   - 填入预览头部：
     - `#cv-name`
     - `#cv-title`
     - `#cv-contact`（用 “ · ” 拼接 city/email/phone）

3. Summary：
   - 若 Summary 模块启用：
     - 将 `#summary-input` 内容写入 `#cv-summary-content`；
     - 若为空，则用默认提示文案（多语言）。

4. Helper：构造日期字符串

```js
function buildDate(prefix, item) {
  const y = item.querySelector("." + prefix + "-year").value;
  const m = item.querySelector("." + prefix + "-month").value;
  const d = item.querySelector("." + prefix + "-day").value;
  if (!y) return "";
  return [y, m || "01", d || "01"].join("-");
}
```

5. 教育经历：
   - 遍历 `.edu-item`：
     - 读取 school / degree / major / start / end；
     - 若行完全为空，则跳过；
     - 组装为：
       - `"{start || ?} ~ {end || ?} · {school} / {degree} / {major}"`
   - 将若干行 join 为 `\n` 写入 `#cv-education-placeholder`。
   - 若全为空，则写入一行多语言占位提示。

6. 工作/实习经历：
   - 遍历 `.exp-item`：
     - 读取 company / position / start / end；
     - 组成类似：
       - `"{start || ?} ~ {end || ?} · {company} / {position}"`
   - 同样写入 `#cv-experience-placeholder`（多行）。

7. 项目经历（Project + Industry + Duties）：
   - 遍历 `.proj-item`：
     - 读取：
       - `proj-name`（Project 名称）
       - `proj-industry`（Industry）
       - `proj-duties`（Duties）
       - `proj-start-*` / `proj-end-*`
     - 跳过完全空行；
     - 文本格式示例：
       - `"{start || ?} ~ {end || ?} · {project} / {industry} / {duties}"`
   - 多行 join 后写入 `#cv-projects-placeholder`。
   - 若全为空，则用默认占位提示（多语言）。

8. Skills：
   - 将 `#skills-input` 按逗号拆分，trim & 过滤空字符串；
   - 每个技能生成一个 `<li>`，写入 `#cv-skills-list`；
   - 若为空，填一个多语言提示。

9. 自定义模块：
   - 若 `module-custom1/2` 勾选：
     - 显示对应 `#cv-custom1-section` / `#cv-custom2-section`；
     - 将 Layout 中 `content-custom1/2` 的原始文本写入预览的 `textarea`；
   - 若未勾选则隐藏对应 section。

10. 更新状态栏：
    - 多语言提示“预览已根据当前输入更新（示例生成）”。

---

## 7. 打印 / PDF 设计

### 7.1 打印样式控制

- 使用 `@page` 指定打印纸张：

```css
@page {
  size: A4;
  margin: 10mm 12mm;
}
```

- 使用 `@media print` 隐藏所有非简历内容：

```css
@media print {
  .topbar,
  .main .panel:first-child,  /* 左侧配置面板 */
  .preview-header,
  .toolbar {
    display: none !important;
  }

  .main {
    padding: 0;
  }

  .grid {
    grid-template-columns: 1fr;
  }

  .panel {
    box-shadow: none;
    border-radius: 0;
    padding: 0;
  }

  .preview-paper {
    border: none;
    border-radius: 0;
    padding: 0;
    margin: 0;
  }
}
```

- 确保导出的 PDF：
  - 不展示 “Custom Resume Builder” 顶部栏、语言切换按钮、操作按钮、预览状态文字等；
  - 只呈现简历正文内容，看起来像一份正式简历。

### 7.2 预览尺寸

- 屏幕预览：
  - `preview-paper` 使用适中的宽度（模拟 A4 宽度），但 **不缩小字号**；
  - 保证在普通桌面浏览器中阅读体验良好。

- PDF 导出：
  - 浏览器打印引擎根据 `@page` 自行缩放；
  - 各模块使用 `page-break-inside: avoid` 尽量减少断页时的割裂感。

---

## 8. 扩展建议

1. **引入前端框架**
   - 将当前的 DOM + JS 重构为 React/Next.js 组件：
     - Form 组件、Layout 组件、Preview 组件、LanguageSwitcher 组件等。
   - 使用 `react-i18next` 管理多语言。

2. **接入后端与 Kiro**
   - 定义 `ResumeInput` / `LayoutConfig` / `ResumeGenerated` 等 DTO；
   - 将 `mockGenerate()` 替换为：
     - `fetch('/api/resume/generate', { method: 'POST', body: JSON.stringify(...) })`
   - 后端通过 Kiro 调用 LLM，返回结构化 JSON 供前端渲染。

3. **模板系统**
   - 引入 `templateId` 概念，在 Preview 中按模板渲染不同版式；
   - 数据结构不变，只换展示方式（CSS + HTML 结构）。

4. **账号与多份简历管理**
   - 在需求中增加登录注册；
   - 数据库中维护多份简历记录与版本；
   - 前端增加“简历管理”页面。

---